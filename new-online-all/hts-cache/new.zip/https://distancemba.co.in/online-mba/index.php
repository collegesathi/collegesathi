<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="facebook-domain-verification" content="mqixxix3lrdt2d8owhjcgx2ccez2r6" />
  
    <title>Online MBA Degree Courses from India's Top B-schools</title> 
    
    <meta name="description" content="Get all details on Online MBA, Distance MBA & Online PGDM courses, fees, admissions, programs, exams, careers, eligibility & degree in India.">
    <meta name="keywords" content="online mba, online mba programs, best online mba programs, online mba courses, best online mba, top online mba programs, mba degree online, distance mba, top online mba, distance mba colleges, online mba schools, online mba colleges, distance mba course, best online mba schools, best online mba courses, online mba university, best colleges for distance mba, best university for online mba, mba online degree programs, best online university for mba, online distance mba, best online mba degrees, top mba online degree programs, online mba top universities, top ranked online mba, online mba programme, distance mba program, mba degree distance learning, distance mba university, top online mba courses, distance mba degree, online mba best colleges, online mba degree courses, top distance mba, best mba online degree programs, amity online mba, manipal online mba, online manipal mba, symbiosis online mba, dy patil online mba, jain online mba, lpu online mba, symbiosis distance mba">

    <!-- FAVICON LINK -->
    <link rel="shortcut icon" type="image/x-icon" size="16x16 32x32" href="images/lpfavfav.png">
    <!-- BOOTSTRAP -->
    <link rel="stylesheet" type="text/css" href=" https://mbaonlinecourse.com/css/bootstrap.min.css">
    <!-- FONT AWESOME LINK -->
   <link rel="stylesheet" type="text/css" href=" https://mbaonlinecourse.com/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/assets/owl.carousel.min.css"/>
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">


    <!-- CUSTOM CSS -->
   <link rel="stylesheet" type="text/css" href=" https://mbaonlinecourse.com/css/style_blue.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
 
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
    <!--LeadSquared Tracking Code Start-->
    <script type="text/javascript" src="https://web-in21.mxradon.com/t/Tracker.js"></script>
    <script type="text/javascript">
          pidTracker('55601');
    </script>
  <!--  <link rel='stylesheet' href='css/css.php' type='text/css' media='all'>-->

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11121534560"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11121534560');
</script>


<!--LSQ chat bot 12-04-2024 17:34pm-->
<style>
      #lsq-chatbot {
        position: fixed;
        z-index: 99999;
        border: none;
      }
      .chatbot-opened {
        height: min(85vh, 586px) !important;
      }
      @media only screen and (max-width: 768px) {
        .chatbot-opened {
          /*position: fixed;*/
          /*height: 100% !important;*/
          /*width: 100% !important;*/
          /*max-width: 100% !important;*/
          /*bottom: 0 !important;*/
          /*right: 0 !important;*/
          /*left: 0 !important;*/
          /*top: 0 !important;*/
          position: fixed;
        height: 52% !important;
        width: 81% !important;
        max-width: 100% !important;
        bottom: 0 !important;
        right: 0px !important;
        left: 53px !important;
        top: 343px !important;
        }
      }
    </style>
  <style>
    .faq-item {
      margin-bottom: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    .faq-header {
      display: flex;
      justify-content: space-between;
      cursor: pointer;
      padding: 10px;
     
      border-radius: 5px;
    }
    .faq-icon {
      font-weight: bold;
    }
    .faq-content {
      padding: 10px;
      display: none;
    }
    @media (max-width: 767px) {
      .faq-header {
        flex-direction: column;
      }
    }
  </style>
  
  <Style>
      @media only screen and (max-width: 736px) {
    .round-button {
        display: inline-block;
        padding: 11px;
        font-size: 10px;
        color: white;
        background-color: #01458E;
        border: none;
        border-radius: 100%;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        outline: none;
        transition: background-color 0.3s;
        position: fixed;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
    }
}
.round-button {
    display: inline-block;
    padding: 11px;
    font-size: 10px;
    color: white;
    background-color: #01458E;
    border: none;
    border-radius: 100%;
    cursor: pointer;
    text-align: center;
    text-decoration: none;
    outline: none;
    transition: background-color 0.3s;
    position: fixed;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    z-index: 9999;
}
  </Style>


</head><style>
        .topbanner{
            Margin-top:97px;
            margin-bottom:26px;
            
        }
        .topbannerunilogos{
            width:200px;
            height:auto;
        }
        
        .contentsection{
                border-right: 1px solid #fff; 
                border-radius: 41px; 
                z-index: 10; 
                background-color: #fff; 
                margin-right: -53px;
        }
        
        .contentimg{
            position: relative; 
            z-index: 0; 
            border-radius: 0px 45px 45px 0px;
        }

        #customcard-card {
            border-radius: 15px;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        #customcard-card-img-overlay {
            display: flex;
            align-items: center;
            justify-content: start;
        }

       #customcard-logo {
    position: absolute;
    left: 36px;
    top: 50%;
    transform: translateY(-50%);
    height: 60px;
    width: 60px;
    background-color: white;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 5px;
}

        #customcard-logo img {
            border-radius: 15px;
        }

        #customcard-university-name {
            background-color: #1a066e2b;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            color: #012146;
            font-size: 14px;
        }

        #customcard-card-body {
            padding: 15px;
        }

        .headingg {
            font-size: 17px;
            font-weight: 600;
        }

        #customcard-icon-text {
            display: flex;
            align-items: center;
        }

        #customcard-icon-text img {
            margin-right: 8px;
        }

        .btn-custom {
            width: 100%;
            font-size: 15px;
        }
        .btn-custom1{
               padding: 8px 0px 8px 0px; 
               font-weight:600; 
               background-color: #fff!important; 
               width: 100%!important; 
               color: black; 
               border-color: #002049;
               border-radius:15px;
           }
           
           .btn-custom2{
                padding: 10px 0px 10px 0px;
                font-weight: 600;
                background-color: #002049 !important;
                width: 110% !important;
                color: rgb(255, 255, 255);
                border-radius: 15px;
                font-size: 14px!important;
           }
           
           .btn-custom3{
               padding: 10px 0px 10px 0px;
    font-weight: 600;
    background-color: #002049 !important;
    width: 19% !important;
    color: rgb(255, 255, 255);
    border-radius: 15px;
    font-size: 14px !important;
    margin: 0 auto;
           }
           
           .btn-custom4{
               padding: 10px 0px 10px 0px;
    font-weight: 600;
    background-color: white !important;
    width: 14% !important;
    color: #002049;
    border-radius: 15px;
    font-size: 14px !important;
    margin: 0 auto;
    margin-top:15px!important;
           }
           
            .btn-customtop{
                padding: 10px 0px 10px 0px;
                font-weight: 600;
                background-color: #002049 !important;
                width: 150% !important;
                color: rgb(255, 255, 255);
                border-radius: 15px;
                font-size: 14px!important;
           }
   

        .rahul,
        .abhi {
            border-radius: 5px;
            width: 100%;
            margin-top: 10px;
            border: 0.2px solid!important;
        }

        @media (min-width: 576px) {

            .rahul,
            .abhi {
                width: auto;
                margin-top: 0;
            }
        }
    </style>
<style>
/* all cards button */
.btn {
  background: #05375B;
  background-image: -webkit-linear-gradient(top, #05375B, #05375B);
  background-image: -moz-linear-gradient(top, #05375B, #05375B);
  background-image: -ms-linear-gradient(top, #05375B, #05375B);
  background-image: -o-linear-gradient(top, #05375B, #05375B);
  background-image: linear-gradient(to bottom, #05375B, #05375B);
  -webkit-border-radius: 28;
  -moz-border-radius: 28;
  border-radius: 28px;
  font-family: Arial;
  color: #ffffff;
  font-size: 13px;
  padding: 10px 20px 10px 20px;
  text-decoration: none;
}
/*header button*/
    .btnn {
  background: #05375B;
  background-image: -webkit-linear-gradient(top, #05375B, #05375B);
  background-image: -moz-linear-gradient(top, #05375B, #05375B);
  background-image: -ms-linear-gradient(top, #05375B, #05375B);
  background-image: -o-linear-gradient(top, #05375B, #05375B);
  background-image: linear-gradient(to bottom, #05375B, #05375B);
  -webkit-border-radius: 28;
  -moz-border-radius: 28;
  border-radius: 28px;
  font-family: Arial;
  color: #ffffff;
  font-size: 20px;
  padding: 10px 20px 10px 20px;
  text-decoration: none;
}




.dro_141{
width: 50px;
height:50px;
align-item:center;
justify-content:center;
padding-top:13px;
display:row;
background:rgba(255,87,34,0.11);
border:1px dashed;
border-radius:50%;
color: #ff5722;
font-size:20px;
}
/*--------------------- List View Cources -----------------*/
.crs_grid_list {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    background: #ffffff;
    box-shadow: 0 0 20px 0 rgb(62 28 131 / 15%);
    -webkit-box-shadow: 0 0 20px 0 rgb(62 28 131 / 15%);
    border-radius: 0.4rem;
    overflow: hidden;
    margin-bottom:30px;
}

@media only screen and (max-width: 600px){
    
  .part_rcp ul {
    flex-wrap: wrap;
    background-color:Red!important;
}
.header-form-bgimage-1{
    padding-bottom:5px!important;
}
   .nomb{
       display:none;
   }
   .cssmobflex{
       display: flex;
    flex-wrap: wrap;
   }
   
   .custcont{
       padding:20px!important; 
       width:100%!important; 
       margin: 0 auto;
   }
   .btn-custom1{
       padding: 8px 0px 8px 0px; 
       font-weight:600; 
       background-color: #fff!important; 
       width: 100%; 
       color: black; 
       border-color: #002049;
       border-radius:15px;
   }
   
   .btn-custom2{
       padding: 8px 0px 8px 0px; 
       font-weight:600; 
       background-color: #002049!important; 
       width: 100%!important; 
       color: rgb(255, 255, 255);
       border-radius:15px;
   }
   #customcard-card {
    border-radius: 15px;
    display: flex;
    flex-direction: column;
    height: 100%;
    margin-bottom: 25px!important;
}

}

/* Medium devices (landscape tablets, 768px and up) */
@media only screen and (min-width: 768px) {
    .ondexk{
        display:none;
    }
    .onlymob{
        display:none;
    }
    
}

/* Large devices (laptops/desktops, 992px and up) */
@media only screen and (min-width: 992px) {
    
       .ondexk{
        display:none;
    }
    .onlymob{
        display:none;
    }
    .custcont{
    padding:30px; 
    width:80%!important; 
    margin: 0 auto;
    }
}

/* Extra large devices (large laptops and desktops, 1200px and up) */
@media only screen and (min-width: 1200px) {
    
       .ondexk{
        display:none;
    }
    .onlymob{
        display:none;
    }
    .custcont{
    padding:30px; 
    width:80%!important; 
    margin: 0 auto;
    }
}


@media only screen and (max-width: 600px) {
    .topbanner {
    Margin-top: 90px!important;
    margin-bottom: 50px!important;
}
    .crs_grid_list {
		display: flex;
		flex-wrap: wrap;
	}
	.crs_grid_list_thumb {
		width: 100%;
		height: auto;
		padding: 10px;
		position: relative;
	}
	.crs_grid_list_caption {
		flex: auto;
		padding: 1rem;
	}
	.crs_lt_103 .crs_info_detail ul li {
		font-size: 13px;
		font-weight: 600;
	}
	.crs_grid_list_thumb img {
    width: 60%;
    height: 60%;
    margin: 0px 60px 0px 60px;
}
.crs_grid_list_caption {
    flex: auto;
    padding: 1rem!important;
}
.part_rcp ul {
    padding-left:1rempx!important;
    flex-wrap: wrap;
}
}
.crs_lt_2{
    position: relative;
    width: 100%;
    align-items: center;
    background: #ffffff;
    box-shadow: 0 0 20px 0 rgb(62 28 131 / 20%);
    -webkit-box-shadow: 0 0 20px 0 rgb(62 28 131 / 30%);
    border-radius: 0.4rem;
    overflow: hidden;
    margin-bottom:30px;
}
.crs_lt_boxes{
    overflow: hidden;
    position: relative;
    width: 100%;
    display: flex;
        align-items: center;
}
.crs_grid_list_thumb {
    width:180px;
    height: 180px; 
    padding: 10px;
    position:relative;
}
a.text-light:focus, a.text-light:hover {
    color: #ffffff!important;
}
.crs_grid_list_thumb a {
    display: block;
    height: 100%;
}
.crs_grid_list_thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.crs_grid_list_caption {
    flex: 1;
    padding:0 0.8rem;
    padding-left:0;
    position: relative;
    display: block;
}
.crs_lt_101 .est {
    display: inline-flex;
    align-items: center;
    height: 26px;
    justify-content: flex-start;
    background: #03b97c;
    padding: 0 10px;
    font-size: 13px;
    font-weight: 600;
    color: #ffffff;
    border-radius: 4px;
}
.crs_lt_102 .crs_tit {
    font-size: 19px;
    font-weight: 800;
    text-transform: uppercase;
    line-height: 1.4;
    margin: 0;
}
span.crs_auth {
    font-size: 14px;
    line-height: 1;
    font-weight: 700;
    color: #e23a31;
}
span.crs_auth i {
    color: #262b38;
}
.crs_lt_103 {
    padding: 1rem 0;
    position: relative;
    display: block;
}
.crs_lt_101 {
    position: relative;
    display: block;
    margin-bottom: 4px;
}
.btn.btn_view_detail.dark_bg {
    background: #2f323a;
    color: #ffffff;
}
.crs_lt_103 .crs_info_detail ul li {
    font-size: 13px;
    font-weight: 600;
}
.crs_lt_101 .est.st_1{
    background: rgba(226, 58, 49,0.11);
    color: #e23a31;
}
.crs_lt_101 .est.st_2 {
    background: rgba(139, 195, 74,0.11);
    color: #8bc34a;
}
.crs_lt_101 .est.st_3 {
    background: rgba(3, 169, 244,0.11);
    color: #03a9f4;
}
.crs_lt_101 .est.st_4 {
    background: rgba(189, 43, 214,0.11);
    color: #bd2bd6;
}
.crs_lt_101 .est.st_5 {
    background: rgba(130, 79, 60,0.11);
    color: #824f3c;
}
.crs_lt_101 .est.st_6 {
    background: rgba(255, 87, 34,0.11);
    color: #ff5722;
}
.crs_lt_101 .est.st_7 {
    background: rgba(134, 95, 255,0.11);
    color: #865fff;
}
.crs_lt_101 .est.st_8 {
    background: rgba(76, 175, 80,0.11);
    color: #4caf50;
}
.lt_cr_footer {
    padding: 1rem;
    border-top: 1px solid #eff3f7;
    display: flex;
    align-items: center;
    max-height: 60px;
}
.lt_cr_footer_first {
    flex: 1;
}
ul.lt_cr_list {
    margin: 0;
    padding: 0;
}
ul.lt_cr_list li {
    display: inline-block;
    list-style: none;
    font-weight: 600;
    font-size: 14px;
    color:#4e6579;
    margin-right:15px;
}
ul.lt_cr_list li:last-child{
    margin:0;
}
ul.lt_cr_list li i{
    margin-right:5px;
}

/* Removes the default 20px margin and creates some padding space for the indicators and controls */
.carousel {
    margin-bottom: 0;
	padding: 0 0px 0px 0px;
}
/* Reposition the controls slightly */
.carousel-control {
	left: -12px;
}
.carousel-control.right {
	right: -12px;
}
/* Changes the position of the indicators */
.carousel-indicators {
	right: 50%;
	top: auto;
	bottom: -25px;
	margin-right: -19px;
}
/* Changes the colour of the indicators */
.carousel-indicators li {
	background: #c0c0c0;
}
.carousel-indicators .active {
background: #333333;
}


input:checked {
border: none;
}
.error-view {
  color: red;
  font-size: 14px;
  padding-left:5px;
}
#errorMsg {
  color: red;
  font-size: 14px;
}
ul {
	list-style-type: none;
	font-size: 15px;
	font-weight: 500;
	line-height: 26px;
}
option:after {
    content: " ";
    height: 5px;
    width: 5px;
    background: #c00;
    border-radius: 5px;
    display: inline-block;
}
input[type="file"] {
    display: none;
}
.custom-file-upload {
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
	background: url("https://mbaonlinecourse.com/images/upload-icon.jpg") no-repeat fixed left; 
	
}

.join-distance{
	box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
	mar-top: 20px;
	margin-top: -32px;
	padding: 20px;
	font-size: 16px;
	min-height: 200px;
	text-align:left;
	width:100%;
}

.image-bottom-join-distance {
  margin: 0 0 20px 0;
  padding-left: 10px;
}
h4 {
  font-size: 13px!important;
  color:#000!important;
}
.graident-color{
    background: linear-gradient(132deg, #ee2c3c 14.58%, #c5135d 65.1%, #6a11b0); 
    background-clip: text; -webkit-background-clip: text; 
    color: transparent;
}
       
       /*degree*/
         .custom-list {
            padding: 0;
            display: flex;
            flex-direction: column;
        }

        .custom-item {
            list-style: none;
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .custom-icon::before {
            content: url('https://mbaonlinecourse.com/images/star.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 16px; /* Set the width of your SVG icon */
            height: 16px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }
        
        .custom-text {
            flex: 1;
        }
       
       /*calender*/
         .custom-list {
            padding: 0;
            display: flex;
            flex-direction: column;
        }

        .custom-item {
            list-style: none;
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .custom-icon::before {
            content: url('https://mbaonlinecourse.com/images/star.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 16px; /* Set the width of your SVG icon */
            height: 16px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }
        
        .custom-text {
            flex: 1;
        }
       
       
       
       /*star*/
       .custom-list {
            padding: 0;
            display: flex;
            flex-direction: column;
        }

        .custom-item {
            list-style: none;
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .custom-icon::before {
            content: url('https://mbaonlinecourse.com/images/star.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 16px; /* Set the width of your SVG icon */
            height: 16px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }
        
        .custom-text {
            flex: 1;
        }
        
        
       
.dec {
  font-size: 13px!important;
  color:#000!important;
}
.thumbnail{padding: 10px!important;min-height: 405px;}
.eligibility-distance {
			font-family: 'Inter';
			font-style: normal;
			font-weight: 500;
			font-size: 20px;
			line-height: 30px;
			text-align: left;
            color: #000000;
       }
.version_text {
				padding-bottom: 10px;
				height: 72px;
				font-family: 'Poppins', sans-serif;
				font-style: normal;
				font-weight: 800;
				font-size: 40px;
				line-height: 72px;
				color: #FFFFFF;
				margin-top: -52px;
              }
.yescls{
	position: absolute;
	padding-top: -27px;
	margin-top: -27px;
	width: 37px;
    padding-left: 7px;
}
.selectcls{margin: 10px 15px; width: 92%;}

	#showdesktop{display:block;}
	#showmobile{display:none;}

	@media (max-width: 480px) {

	#showdesktop{display:none;}
	#showmobile{display:block;}
	

.carousel {
  margin-bottom: 0;
  padding: 0 0px 0px 0px!important;
}
.selectcls{margin: 10px 11px!important;width: 91%!important;}	

.mobwidth{width:100%;}

.contact-form1{margin-top: -140px!important;}

.banner_txy {
			position: absolute!important;
			margin-left: 0px!important;
}

.version_text {
  padding-bottom: 10px;
  height: 137px;
  font-family: 'Poppins', sans-serif;
  font-style: normal;
  font-weight: 800;
  font-size: 38.574px;
  line-height: 72px;
  color: #FFFFFF;
  margin-top: -19px;
}

.pricig-uline-white {
	margin: -46px -15px !important;
	width: 100%;
}

.top-buffer{margin-top: 0px;
            font-size: 59px;
           }
.homebanner {
  padding-left: 0px;
}
.join-distance {
  box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
  mar-top: 20px;
  margin-top: -32px;
  padding: 20px;
    padding-top: 20px;
  font-size: 16px;
  min-height: 189px;
  text-align: left;
  width: 100%;
  height: 200px;
}
}

#deskbanner{display:block;}
#mobilebanner{display:none;}

@media only screen and (min-width: 335px) and (max-width: 767px)  {

.section-space-mobile{margin-top:-70px;}

.h3-bottom {
  font-size: 13px;
}

#deskbanner{display:none;}
#mobilebanner{display:block;}

	 .getyourdreamjob{font-size: 20px;}
	 .homebanner{padding-left: 0px;}
	.top-buffer {
		margin-top: 0px;
		font-size: 40px;
		text-align:center;
	}
	
	.version_text {
		margin-top:-65px;
		font-size: 31px;
		text-align: center;
	}
	
.pricig-uline-white {
	margin: -46px 0px !important;
	width: 100%;
}
.homebanner{padding-left: 0px!important;}





}
.lp-img{width: 180px;}

@media only screen and (min-width: 340px) and (max-width: 335px)  {
.top-buffer {
  margin-top: 0px;
  font-size: 40px;
}

.version_text {
  font-size: 28px;
}
	
}

.colr{color:#045692;
	  color: #045692;
	  font-weight: 800;
	  font-size: 33px;
	}

.50per{
      border-right:1px solid #045692!important;
      border-left:1px solid #045692!important;
	  }
	.downbrochure{
				color: #fff !important;
				background: #045692;
				padding: 6px;
				font-weight: 700;
				width: 100%;
				margin-bottom:10px;
	}
	
	
.row.promo-content {
    background: #ffffff none repeat scroll 0 0;
    -webkit-box-shadow: 0 9px 9px 0 #c7c7c7;
    box-shadow: 0 9px 9px 0 #c7c7c7;
    margin-top: -40px;
	padding-top: 40px;
    position: relative;
	z-index: 1;
	border-radius: 5px;
   }

 .homebanner{
	padding-left: 50px;
  }	  
  
  .banner_txy{
		position: absolute;
		margin-left: 44%;
		z-index: 0;
	}
  .bannerimg{ z-index: 1;}
  
/* #showdesktop{display:block;}
#showmobile{display:none;}

#showdesktop{display:none;}
	#showmobile{display:block;}*/
	
	
@media only screen and (min-width: 481px) and (max-width: 1200px)  {
	.col-sm-3 {
		width: 48%;
	}
	
   .join-distance {margin-bottom: 37px;}
	.form-bottom-1 {
	 margin-bottom: 27px;
	}
	
	
	.form-bottom-2{width:104%;}
	
	.row-fluid .span3 {
		width: 46.928%;
		*width: 22.87498530621841%;
	}

}

.container-fluid > .navbar-collapse, .container-fluid > .navbar-header, .container > .navbar-collapse, .container > .navbar-header {
  margin-right: -13px;
  margin-left: -50px;
}

.feeheader{
    font-weight:600; 
    font-size:18px!important; 
    border-bottom:1px solid grey; 
    color:#002049!important;text-align:center;
}

    @media only screen and (max-width: 767px) {
        .btntop {
            width: 90%; /* Make the button 100% width on small screens */
            font-size: 21px; /* Increase the font size on small screens */
        }
        .feetomobile{
           /* margin-top:53px;*/
        }
         .btn-top-mobile{
            position: absolute;
            top: -289px;
            transform: translateX(60%);
        }
        /*Manipal*/
        .btn-top-mobile1{
            position: absolute;
            top: -289px;
            transform: translateX(60%);
        }
        
        /*Amity*/
        .btn-top-mobile2{
            position: absolute;
            top: -262px;
            transform: translateX(60%);
        }
        
        /*LPU*/
        .btn-top-mobile3{
            position: absolute;
            top: -289px;
            transform: translateX(60%);
        }
        
        /*Symbisosi*/
        .btn-top-mobile4{
            position: absolute;
            top: -268px;
            transform: translateX(60%);
        }
        
        /*DPU*/
        .btn-top-mobile5{
            position: absolute;
            top: -290px;
            transform: translateX(60%);
        }
        
        /*jain*/
        .btn-top-mobile6{
            position: absolute;
            top: -265px;
            transform: translateX(60%);
        }
        
        /*Chandigarh University*/
        .btn-top-mobile7{
            position: absolute;
            top: -290px;
            transform: translateX(60%);
        }
        
        /*Alliance*/
        .btn-top-mobile8{
            position: absolute;
            top: -260px;
            transform: translateX(60%);
        }
        
        /*SRM*/
        .btn-top-mobile9{
            position: absolute;
            top: -289px;
            transform: translateX(60%);
        }
        
        /*BIMTECH*/
        .btn-top-mobile10{
            position: absolute;
            top: -264px;
            transform: translateX(60%);
        }
        
        /*ICFAI*/
        .btn-top-mobile11{
           position: absolute;
            top: -263px;
            transform: translateX(60%); 
        }
        
        /*IMT*/
        .btn-top-mobile12{
            position: absolute;
            top: -261px;
            transform: translateX(60%);
        }
        
        /*NMIMS*/
        .btn-top-mobile13{
            position: absolute;
            top: -265px;
            transform: translateX(60%);
        }
        
        /*welingker*/
        .btn-top-mobile{
            position: absolute;
            top: -261px;
            transform: translateX(60%);
        }
        
        /*Panjab*/
        .btn-top-mobile15{
            position: absolute;
            top: -263px;
            transform: translateX(60%);
        }
        
        /*Anna*/
        .btn-top-mobile121{
            position: absolute;
            top: -262px;
            transform: translateX(60%);
        }
        
        
        
        .bothbutton{
            /*transform: translateX(50px);*/
        }
        .notdesktop{
            display:none;
        }
        .btnn-1{
         
            width: 67%;
            font-size: 13px;
            padding: 9px 72px 7px 7px;
            position: relative;
            right: 13px;
            font-size:13px
        }
        .btnn-2{
           
            width: 62%;
            position: absolute;
            top: -44px;
            left: 143px;
            padding: 8px 10px 7px 9px;
        }
        .mb-30 {
    margin-bottom: -21px;
}
.leftpaddmob{
    margin-left:-41px!important;
}
.mobleftmar{
           margin-left:-39px;
           
       }
       .sec-two-lp {
    background-color: #f9f9f9;
    padding-bottom: 12px;
}
.ondexk button#enquire{display:none;}
.gradientmobb{
    font-size:26px!important;text-align:center;
}
.gradienthead{
    font-size:19px!important;text-align:center;
}
        
    }
    
        #container {
            max-width: 1200px;
            margin: 0 auto;
            overflow: hidden;
        }

        #row {
            display: flex;
            flex-wrap: wrap;
        }

        #mainheader {

            flex: 1;
          /* background-color: white;*/
            border-radius: 0px 20px 20px 0;
            padding: 49px 1px 1px 1px;
            position: relative;
            z-index: 1;
            top: 0px;
            border: 1px;
            left: 30px;

        }

        #mainheader h2 {
            margin: 0;
            padding: 0;
        }

        #mainheader p {
            margin: 10px 0;
        }

        #img-container {
            flex: 1;
            max-width: 400px;
            position: relative;
        }

        #img-container img {
            width: 100%;
            border-radius: 20px 20px 0 0;
        }

        .gradient-text {
            background: linear-gradient(132deg, #ee2c3c 14.58%, #c5135d 65.1%, #6a11b0);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
        }

        @media (max-width: 767px) {
            .bothbutton, .ondexk{text-align:center;}
            .lp-ul ul{list-style-position: inside;}
            #row {
                flex-direction: column-reverse;
            }

            #mainheader {
                flex: 1;
               /* background-color: white;*/
                border-radius: 0px 20px 20px 0;
               /* padding: 20px;*/
                position: relative;
                z-index: 1;
                top: 3px;
                border: 1px;
                left: 0px;
                margin-top: -25px;
            }

            #mainheader,
            #img-container {
                border-radius: 20px 20px 0 0;
                top: 0;
            }

            .mainhederconte {
                padding: 20px !important;
            }
             .bttncenter {
                text-align: center;
                width:100%;
            }
            .mobileheader{
                font-size:30px!important;line-height:normal;
            }
            .pmobile{
                       font-size: 18px !important;
        text-align: justify !important;
        margin-top: 15px;
        line-height: 27px;
            }
            
            .nowshow{
                display:none;
            }
            
            .contentimg{
                display:none;
            }
            .btn-custom4 {
                padding: 10px 0px 10px 0px;
                font-weight: 600;
                background-color: white !important;
                width: 39% !important;
                color: #002049;
                border-radius: 15px;
                font-size: 14px !important;
                margin: 0 auto;
                margin-top: 15px !important;
            }
            .btn-custom3 {
                padding: 10px 0px 10px 0px;
                font-weight: 600;
                background-color: #002049 !important;
                width: 43% !important;
                color: rgb(255, 255, 255);
                border-radius: 15px;
                font-size: 14px !important;
                margin: 0 auto;
            }
            .faq-icon{
                display:none;
            }
            .logophone{
                width:66%!important;
            }
            .secondbtn{
                    background-color: #002049!important;
                    color: rgb(255, 255, 255)!important;
                    border-radius: 10px!important;
                    font-size: 17px!important;
                    margin-left: 0px!important;
                        margin-top: 10px;

            }
            .uparwaliline{
                font-size:40px!important;
                line-height:normal;
            }
            
        }
        
        .custom-icon::before {
            content: url('https://mbaonlinecourse.com/images/star.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 16px; /* Set the width of your SVG icon */
            height: 16px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            vertical-align: middle; /* Align the icon vertically in the middle of the line height */
            fill: #002049; /* Set the color of the SVG icon */
        }

        .custom-text {
            vertical-align: middle; /* Align the text vertically in the middle of the line height */
            margin-bottom: 10px; /* Adjust the spacing between list items */
        }
        
         .custom-list {
            padding: 0;
            list-style: none;
        }

        .custom-itemmmmm {
            display: flex;
            align-items: center;
            margin-bottom: -8px;
        }
        
        .custom-iconm::before {
            content: url('https://mbaonlinecourse.com/images/degree.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 32px; /* Set the width of your SVG icon */
            height: 32px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }

        .custom-iconc::before {
            content: url('https://mbaonlinecourse.com/images/calender.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 32px; /* Set the width of your SVG icon */
            height: 32px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }
        
        .custom-icons::before {
            content: url('https://mbaonlinecourse.com/images/startt.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 32px; /* Set the width of your SVG icon */
            height: 32px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }
        
        .custom-icon-inr::before {
            content: url('https://mbaonlinecourse.com/images/Groupinr.svg'); /* Replace 'path/to/your/icon.svg' with the actual path to your SVG icon */
            display: inline-block;
            width: 32px; /* Set the width of your SVG icon */
            height: 32px; /* Set the height of your SVG icon */
            margin-right: 8px; /* Adjust the spacing between the icon and the text */
            fill: #002049; /* Set the color of the SVG icon */
        }

        .custom-text {
            flex: 1;
        }
        
        @media only screen and (max-width: 767px)
#btnSubmit {
    width: 100%!important;
    max-width: 100%!important;
    height: 34px!important;
    border-radius: 15px!important;
    margin: 0px 0px 0px 0px;
}
        
        
</style>




<!--India's leading courese-->
    <!-- Modal Form-->
    <style>
    input[type="text"], textarea {
    background-color: #fff0;
}
    .form-error-top {
    padding-top: 0px;
    padding-bottom: 0px;
}
        @media screen and (max-width: 767px){
            div#lp-enquire-sticky-button {
    display: none;
}
            .modal-content{
                margin:auto !important;
            }
            input#fname{
                width:100%!important;
            }
            input#phoneno{
                    width: 100% !important;

            }
            input#email {
    width: 100% !important;
}
input#city {
    width: 100% !important;
}
select#university {
   /*width: 90% !important;*/
        margin: 0 0 0 14px !important;
}
.form-bottom-1 {
    margin-bottom: 0px !important;
}
        }
        
        @media screen and (min-width: 767px){
           .submit-btn {
     width: 220% !important;
     margin-top: -20px;}
        
            }
                .imgg {
        width: auto;
        height: 50px;
        animation: scroll 60s linear infinite;
    }

    .slide-track {
        width: 100%;
        display: flex;
        gap: 2em;
        overflow: hidden;
    }

    .slider {
        margin-top: 0px;

        /* padding: 8em 2em; */
    }

    @keyframes scroll {
        0% {
            transform: translateX(0);
        }

        100% {
            transform: translatex(-1000%)
        }
    }
    </style>
                                        <div class="modal " id="mymodel" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true" >
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content" style="margin: 0px 90px 0 70px;">
                                                    <div class="modal-header">
                                                        <img src="https://mbaonlinecourse.com/images/main site logo.png" height="50px" width="auto" alt="distance-mba">
                                                        <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                            
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="contact-div header-contact-form header-contact-bg padding-top-xs"
                                                            id="get_free_counselling">

                                                            <form class="contact-form1" method="POST"
                                                                action="lp-verify_mob.php" name="frmid"
                                                                enctype="multipart/form-data" onsubmit="return validateForm();">
                                                                <input type="hidden" name="pageurl" id="pageurl" value='https://distancemba.co.in/online-mba/index.php'>
                                                                <input type="hidden" name="entryform" id="entryform" value>
                                                                <div class="clearfix">
                                                                    <div class="header-contact-bg-pad"><br>
                                                                        <!--<h3 id="heading" class="text-left"-->
                                                                        <!--    style="padding-left:16px;text-align: center;"></h3>-->
                                                                        <!--Slider-->
                                                                        
                                                                              <div class="slider">
                                    <div class="slide-track">
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/Amity.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/Symbiosis.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/NMIMS-1.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/DPU.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/MUJ.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/Jain.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/LPU.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/OP JIndal.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/CU.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/SHarda.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/Parul.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/online UU.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/SRM.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/VIgnan.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/Bharati Vidyapeeth Institute (1).png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/GLA.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/IIMR.png" alt="">
                                        </div>
                                        <div class="slide">
                                            <img class="imgg" src="https://mbaonlinecourse.com/images/logosuni/Ignou.png" alt="">
                                        </div>
                                    </div>
                                </div>
                                                                        <br>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important; width: 100%;" class="form-control" type="text"
                                                                                    name="fname" id="fname"
                                                                                    placeholder="Full Name*"
                                                                                    required>
                                                                                    <span class="errormsg" id="errname"></span>
                                                                            </div>
                                                                            <!--<div class="form-group col-md-6 col-12 unit">-->
                                                                            <!--    <input style="border-radius:10px!important;" class="form-control" type="text"-->
                                                                            <!--        name="lname" id="lname"-->
                                                                            <!--        placeholder="Last Name*"-->
                                                                            <!--        required>-->
                                                                            <!--</div>-->
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="phoneno" id="phoneno"
                                                                                    placeholder="Mobile Number*"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10"  onkeydown="return valid_entry_num(event.key)" required>
                                                                            <span class="errormsg" id="errp"></span>
                                                                            </div>
                                                                        </div>


                                                                        <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important; width: 100%;" class="form-control form-text"
                                                                                    type="email" name="email" id="email"
                                                                                    placeholder="Email*" required >
                                                                            <span class="errormsg" id="erre"></span>
                                                                            </div>
                                                                            <div class="form-group col-md-12 unit">
                                                                                <input style="border-radius:10px!important; width: 100%;" class="form-control form-text"
                                                                                    type="text" name="city" id="city"
                                                                                    placeholder="City*" onkeydown="return valid_entry_char(event.key)"
                                                                                    required>
                                                                                     <span class="errormsg" id="errc"></span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <!-- <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls" id="mx_Course_interested_In" name="mx_Course_interested_In" onchange="updateSpecialization()">
                                                                                <option value="">Select a Program</option>
                                                                                <option value="MBA">Online MBA</option>
                                                                                <option value="Master">Master Program</option>
                                                                                <option value="Bachelor">Bachelor's</option>
                                                                                <option value="Certificate">Certificate</option>
                                                                                <option value="Executive">Executive MBA</option>
                                                                            </select>
                                                                        </div>
    
                                                                         <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
										                                    <select style="border-radius:10px!important;" class="form-control selectcls" name="mx_Interested_in_Specialization" id="mx_Interested_in_Specialization" required>
                                                                                <option value="">Select a Course</option>
                                                                            </select>
                                                                                <script>
                                                                                    
                                                                                    const specializations = {
                                                                                        "MBA": ["MBA"],
                                                                                        "Master": ["Select a Course", "MA", "M.Com", "MSC", "MCA", "Master of Journalism and Mass Communication (MJMC)"],
                                                                                        "Bachelor" : ["Select a Course", "BA", "B.Com", "BCA", "BBA", "Bachelor of Journalism and Mass Communication (BJMC)"],
                                                                                        "Certificate": ["Select a Course", "Data Analyst", "Digital Marketing", "Hospital & Health Care"],
                                                                                        "Executive" : ["Select a Course", "1 Year Executive MBA", "15 Months Executive MBA"]
                                                                                    };
                                                                            
                                                                                    
                                                                                    function updateSpecialization() {
                                                                                         
                                                                                        const courseSelect = document.getElementById("mx_Course_interested_In");
                                                                                        const selectedCourse = courseSelect.value;
                                                                            
                                                                                        
                                                                                        const specializationSelect = document.getElementById("mx_Interested_in_Specialization");
                                                                            
                                                                                         
                                                                                        specializationSelect.innerHTML = "";
                                                                            
                                                                                         
                                                                                        if (selectedCourse in specializations) {
                                                                                            
                                                                                            specializations[selectedCourse].forEach(function(specialization) {
                                                                                                const option = document.createElement("option");
                                                                                                option.value = specialization;
                                                                                                option.textContent = specialization;
                                                                                                specializationSelect.appendChild(option);
                                                                                            });
                                                                                        }
                                                                                    }
                                                                                </script>
                                                                        </div>-->
                                                                        
                                                                    
                                                                        <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius: 10px !important; margin: 6px -16px; width: 107%;" class="form-control selectcls"
                                                                                name="university" id="university" required>
                                                                                <option value="">Select University
                                                                                </option>
                                                                                
                                                                                <!--Amity-->
                                                                                <option value="Amity University">
                                                                                    Amity University
                                                                                </option>
                                                                                
                                                                                
                                                                                <!--Manipal-->
                                                                                <option value="Manipal University">
                                                                                    Manipal University
                                                                                </option>
                                                                                
                                                                                 <!--NMIMS-->
                                                                                <option value="NMIMS University"> 
                                                                                   NMIMS University
                                                                                </option>
                                                                                
                                                                                <!--O.P. Jindal Gloabl University-->
                                                                                <option value="O.P. Jindal Global University">
                                                                                    O.P. Jindal Global University
                                                                                </option>
                                                                                
                                                                                <!--Jain-->
                                                                                <option value="Jain University">
                                                                                    Jain University
                                                                                </option>
                                                                                
                                                                                <!--Dy Patil-->
                                                                                <option value="Dr. DY. Patil Vidyapeeth University">
                                                                                    Dr. DY. Patil Vidyapeeth University
                                                                                </option>
                                                                                
                                                                                <!--LPU-->
                                                                                <option value="Lovely Professional University">
                                                                                    Lovely Professional University
                                                                                </option>
                                                                                
                                                                                <!--Uttaranchal University-->
                                                                                <option value="Uttaranchal University">
                                                                                    Uttaranchal University
                                                                                </option>
                                                                                
                                                                                <!--Symbiosis-->
                                                                                <option value="Symbiosis Centre of Distance Learning (SCDL)"> 
                                                                                    Symbiosis Centre of Distance Learning (SCDL)
                                                                                </option>
                                                                                
                                                                                <!--Institute of Management Technology, Ghaziabad-->
                                                                                <option value="Institute of Management Technology, Ghaziabad">
                                                                                    Institute of Management Technology, Ghaziabad (IMT)
                                                                                </option>
                                                                                
                                                                                <!--Sharda University-->
                                                                                <option value="Sharda University">
                                                                                    Sharda University
                                                                                </option>
                                                                                
                                                                                <option  value=" Shoolini University">
                                                                                    Shoolini University</option>
                                                                                    
                                                                                 <option

                                                                                    value="GLA University">

                                                                                    GLA University</option>

                                                                                 <option

                                                                                    value="Amrita University">

                                                                                    Amrita University</option>
                                                                                
                                                                                   <option

                                                                                    value=" Parul University">

                                                                                    Parul University</option>

                                                                                 <option

                                                                                    value="UPES University">

                                                                                    UPES University</option>

                                                                                 <option

                                                                                    value="SP Jain University">

                                                                                    SP Jain University</option>
                                                                                
                                                                                 <option

                                                                                    value="SP Jain University">

                                                                                    Chandigarh University</option>
                                                                                    
                                                                                     <option

                                                                                    value="SP Jain University">

                                                                                    Bhartiya Vidya Peeth University</option>
                                                                    
                                                                                <option value="Others">
                                                                                   Others
                                                                                </option>
                                                                                
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        
                                                                        <!--Whatsapp number-->
                                                                        <div class="form-row form-div form-bottom-1" style="display:none;">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="mx_Whatsapp_Number" id="mx_Whatsapp_Number"
                                                                                    placeholder="WhatsApp Number Optional"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10" onkeydown="return valid_entry_numw(event.key)">
                                                                           <span class="errormsg" id="errw"></span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        <div style="display:none;">
                                                                            <label for="honeypot">Leave this field blank:</label>
                                                                            <input type="text" id="honeypot" name="honeypot">
                                                                        </div>



                                                                        <div
                                                                            class="form-div phoneno-bottom error-div unit">
                                                                            <input class="header-contact-form"
                                                                                type="checkbox" name="tnc" id="tnc"
                                                                                checked="checked"> I agree to get updates from counsellor
                                                                        </div>

                                                                        <!--============= SUCESSS AND FAILURE MESSAGE DISPLAY HERE ========-->
                                                                        <div class="left form-error-top"> <span
                                                                                class="form-success sucessMessage">
                                                                            </span>
                                                                            <span class="form-failure failMessage">
                                                                            </span>
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1"
                                                                            id="verify_id1" style="display:none11;">
                                                                            <!--  <div class="form-group col-md-6">-->
                                                                            <!-- <input type="text" class="form-control form-text" name="verify_otp" id="verify_otp" placeholder="Verify OTP" autocomplete="off">-->
                                                                            <!--</div> -->
                                                                            <!-- <div class="form-group col-md-6">-->
                                                                            <!-- <input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="btnVerifyPhone" id="btnVerifyPhone" value="Verify OTP">-->
                                                                            <!--</div>-->
                                                                        </div>


                                                                        <!-- <div class="form-group col-md-6" id="sendotp_div">-->
                                                                        <!--<input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="sendotp" id="sendotp" value="Send OTP">-->
                                                                        <!--</div> -->


                                                                        <div class="form-group col-md-6"
                                                                            id="form_data_div1" style="display:none1;">
                                                                             
                                                                            <input type="submit" class="submit-btn contact-form-submit text-center "
                                                                                style="color:#fff!important; height: 46px !important;border-radius: 35px !important;"
                                                                                name="btnSubmit" id="btnSubmit"
                                                                                value="Submit">
                                                                        </div>

                                                                        <span id="loader"></span>
                                                                        <br>
                                                                        <!--<br>-->
                                                                    </div>
                                                                </div>
                                                               	 <input type="hidden" name="utm_campaign" id="utm_campaign" value="" >
								 
								 <input type="hidden" name="utm_content" id="utm_content" value="" >
								 
								 <input type="hidden" name="SourceIPAddress" id="SourceIPAddress" value="" >
								 
								 <input type="hidden" name="utm_medium" id="utm_medium" value="" >
								 
								 <input type="hidden" name="SourceReferrerURL" id="SourceReferrerURL" value="" >
								 
								  <input type="hidden" name="utm_keyword" id="utm_keyword" value="" >
                                                            </form>
                                                        </div>
                                                    </div>
                                                  <!--  <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                     
                                                    </div>-->
                                                </div>
                                            </div>
                                        </div>

<script>
function validateForm() {

 var x=jQuery('#fname').val().trim();
 if(x=="")
 {
  
    jQuery('#errname').text("Enter Valid Name");
    return false;
 }
 
 
var x= jQuery('#email').val().trim();

 var validRegex = /\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (validRegex.test(x)) {
  }
  else
  {
     
      jQuery('#erre').text("Enter Valid Email Address");
       return false;
   
  }
 var x=jQuery('#city').val().trim();
 if(x=="")
 {
    jQuery('#errc').text("Enter Valid City");
     return false;
    
 }
 
  var x= jQuery('phoneno').val().trim();
  if ( (x.length>=10)  &&  (x.length<=15)) {
  }
  else
      {
      jQuery('#errp').text("Enter Valid Contact Details");
       return false;
    
  }
 
      return true;
 
}

 

  

</script>
<script>        
 function valid_entry_num(key) {
var plen =jQuery("#phoneno").val();


  if (plen.length <=10)
  {
  return (key >= '0' && key <= '9') || key == '+' ||  key == '-' ||
   key == 'ArrowLeft' || key == 'ArrowRight'  || key == 'Tab' || key == 'Delete' || key == 'Backspace';
  }
  else
    {return false; }
}
 function valid_entry_numw(key) {
 var plen = jQuery("#mx_Whatsapp_Number").val();

 
  if (plen.length <=15)
  {
  return (key >= '0' && key <= '9') || key == '+' ||  key == '-' ||
   key == 'ArrowLeft' || key == 'ArrowRight'  || key == 'Tab' || key == 'Delete' || key == 'Backspace';
  }
  else
    {return false; }
}
function valid_entry_char(key) {
  var plen = document.getElementById("city1");
    return (key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z') || key == ' ' ||
    key == 'ArrowLeft' || key == 'ArrowRight' || key == 'Delete' || key == 'Backspace';

}
</script>
 
<body id="lp-page">
    



    
<div class="containter-fluid visible-desktop fixed-top" style="background-color: white; border-bottom:1px solid grey">
        <div class="container" style="padding: 10px;">
            <div class="row">
                <div class="col-md-2">
                    <!--<img src=" https://mbaonlinecourse.com/images/Newlogo.png" class="img-responsive" height="auto" width="100%" alt="distancemba" srcset="">-->
                     <img src=" https://mbaonlinecourse.com/images/main site logo.png" class="img-fluid mt-2" height="auto" width="80%" alt="distancemba" srcset="">
                </div>
                <div class="col-md-10" style="margin-top: 8px;display:flex;justify-content:end">
                     <div class="row">
                            <div class="col-12">
                                <button type="button" class=" abhi btn-custom btn-customtop" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                        </div>
                </div>
            </div>
        </div>
</div>

<div class="container-fluid hidden-desktop visible-phone" style="background-color: white; position: fixed; top: 0; width: 100%; z-index: 1000; padding: 0; margin-bottom:20px;">
    <div class="container" style="padding: 10px; max-width: 100%; border-bottom: 1px solid #05375b4f;">
        <div class="row" style="display: flex; align-items: center;">
            <div class="col-md-6" style="flex: 1;">
                <img src="https://mbaonlinecourse.com/images/main site logo.png" class="img-responsive logophone" alt="distancemba" style="max-width: 100%; height: auto;">
            </div>
            <div class="col-md-6" style="flex: 1; text-align: right;">
                <button type="button" class="rahul btn-custom btn-custom1" data-rahul="1" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1" style="width: auto;     padding: 5px 0px 5px 0px;
    margin-top: 1px;">
                    Enquire now
                </button>
            </div>
        </div>
    </div>
</div>


    
<!-- old nav bar -->
<nav class="navbar" style="display: none;">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"><img src=" https://mbaonlinecourse.com/images/newlogo.png" alt="distancemba" class="img-responsive"></a>
            </div>
        </div>
</nav>
    
<!--<div id="lp-enquire-sticky-button" data-id="Enquire Now" ><a data-toggle="modal" href="#exampleModal1"  data-target="#exampleModal1" style="cursor: pointer;">Enquire Now</a></div>-->

<!--Form On top header only on phone-->
<div class="container-fluid onlymob" style="display:none;">
     <h2 style="font-size:15px!important; padding-bottom:10px!important; color:#000;" > Enter your details and get free career counselling in top B-Schools.</h2>
     <div class="contact-div header-contact-form header-contact-bg padding-top-xs onlymob"
                                                            id="get_free_counselling">

                                                            <form class="contact-form1" method="POST"
                                                                action="lp-verify_mob.php" name="frmid"
                                                                enctype="multipart/form-data">
                                                                <input type="hidden" name="pageurl" id="pageurl" value='https://distancemba.co.in/online-mba/index.php'>
                                                                <input type="hidden" name="entryform" id="entryform" value>
                                                                <div class="clearfix">
                                                                    <div class="header-contact-bg-pad"><br>
                                                                        <h3 id="heading" class="text-left"
                                                                            style="padding-left:16px;"></h3>
                                                                        <br>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control" type="text"
                                                                                    name="fname" id="fname"
                                                                                    placeholder="Full Name*"
                                                                                    required>
                                                                            </div>
                                                                            <!--<div class="form-group col-md-6 col-12 unit">-->
                                                                            <!--    <input style="border-radius:10px!important;" class="form-control" type="text"-->
                                                                            <!--        name="lname" id="lname"-->
                                                                            <!--        placeholder="Last Name*"-->
                                                                            <!--        required>-->
                                                                            <!--</div>-->
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="phoneno" id="phoneno"
                                                                                    placeholder="Mobile Number*"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10" pattern="^\d{10}$" oninvalid="this.setCustomValidity('Please enter correct phone')" oninput="this.setCustomValidity('')" required>
                                                                            </div>
                                                                        </div>


                                                                        <div class="form-row form-div form-bottom-1">
                                                                            <div class="form-group col-md-6 col-12 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control form-text"
                                                                                    type="text" name="email" id="email"
                                                                                    placeholder="Email*" required required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" oninvalid="this.setCustomValidity('Please enter correct email')" oninput="this.setCustomValidity('')">
                                                                            </div>
                                                                            <div class="form-group col-md-6 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control form-text"
                                                                                    type="text" name="city" id="city"
                                                                                    placeholder="Enter City*"
                                                                                    required>
                                                                            </div>
                                                                        </div>
    
                                                                         <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="mx_Interested_In_Speclization" id="mx_Interested_In_Speclization" required>
                                    											<option value="">Select Specialization</option>
                                    											<option value="MBA (Banking and Finance Management)">MBA (Banking and Finance Management)</option>
                                    											<option value="MBA (Business Management)">MBA (Business Management)</option>
                                    											<option value="MBA (Financial Management)">MBA (Financial Management)</option>
                                    											<option value="MBA (Human Resource Management)">MBA (Human Resource Management)</option>
                                    											<option value="MBA (International Trade Management)">MBA (International Trade Management)</option>
                                    											<option value="MBA (Information Technology and Systems Mangement)">MBA (Information Technology and Systems Mangement)</option>
                                    											<option value="MBA (Marketing Management)">MBA (Marketing Management)</option>
                                    											<option value="MBA (Operations Management)">MBA (Operations Management)</option>
                                    											<option value="MBA (Retail Management)">MBA (Retail Management)</option>
                                    											<option value="MBA (Supply Chain Management)">MBA (Supply Chain Management)</option>
                                    											<option value="Master of Business Administration (Executive MBA)">Master of Business Administration (Executive MBA)</option>
                                    											<option value="MBA (X) in Business Analytics">MBA (X) in Business Analytics</option>
											
										                                    </select>
                                                                        </div>

                                                                        <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="university" id="university" required>
                                                                                <option value="">Select University
                                                                                </option>
                                                                                <option
                                                                                    value="Manipal University">
                                                                                    Manipal University</option>
                                                                                <option value="Symbiosis University">
                                                                                    Symbiosis University</option>
                                                                                <option
                                                                                    value="Dr. D. Y. Patil Vidyapeeth University">
                                                                                    Dr. D. Y. Patil
                                                                                    Vidyapeeth University</option>
                                                                                <option value="Jain University">Jain
                                                                                    University</option>
                                                                                <option
                                                                                    value="Amity University, distance and Distance Learning (ODL)">
                                                                                    Amity
                                                                                    University, distance and Distance
                                                                                    Learning (ODL)</option>
                                                                                <option
                                                                                    value="Lovely Professional University Distance Learning">
                                                                                    Lovely
                                                                                    Professional University Distance
                                                                                    Learning</option>
                                                                                <option value="Chandigarh University">
                                                                                    Chandigarh University</option>
                                                                              <!--  <option
                                                                                    value="Indira Gandhi National Open University (IGNOU)">
                                                                                    Indira Gandhi
                                                                                    National Open University (IGNOU)
                                                                                </option>-->
                                                                                <option
                                                                                    value="Welingkar Institute of Management Development & Research">
                                                                                    Welingkar Institute of Management
                                                                                    Development & Research</option>
                                                                                <!--<option value="Manipal University">-->
                                                                                <!--    Manipal University</option>-->
                                                                                <option value="Other">Other</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div style="display:none;">
                                                                            <label for="honeypot">Leave this field blank:</label>
                                                                            <input type="text" id="honeypot" name="honeypot">
                                                                        </div>



                                                                        <div
                                                                            class="form-div phoneno-bottom error-div unit">
                                                                            <input class="header-contact-form"
                                                                                type="checkbox" name="tnc" id="tnc"
                                                                                checked="checked"> I agree to get
                                                                            updates from Distance-MBA
                                                                        </div>

                                                                        <!--============= SUCESSS AND FAILURE MESSAGE DISPLAY HERE ========-->
                                                                        <div class="left form-error-top"> <span
                                                                                class="form-success sucessMessage">
                                                                            </span>
                                                                            <span class="form-failure failMessage">
                                                                            </span>
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1"
                                                                            id="verify_id1" style="display:none11;">
                                                                            <!--  <div class="form-group col-md-6">-->
                                                                            <!-- <input type="text" class="form-control form-text" name="verify_otp" id="verify_otp" placeholder="Verify OTP" autocomplete="off">-->
                                                                            <!--</div> -->
                                                                            <!-- <div class="form-group col-md-6">-->
                                                                            <!-- <input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="btnVerifyPhone" id="btnVerifyPhone" value="Verify OTP">-->
                                                                            <!--</div>-->
                                                                        </div>


                                                                        <!-- <div class="form-group col-md-6" id="sendotp_div">-->
                                                                        <!--<input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="sendotp" id="sendotp" value="Send OTP">-->
                                                                        <!--</div> -->


                                                                        <div class="form-group col-md-6"
                                                                            id="form_data_div1" style="display:none1;">
                                                                            
                                                                            <input type="submit" class="submit-btn contact-form-submit text-center "
                                                                                style="color:#fff!important; height: 46px !important;border-radius: 35px !important;width: 100% !important;"
                                                                                name="btnSubmit" id="btnSubmit"
                                                                                value="Submit">
                                                                        </div>

                                                                        <span id="loader"></span>
                                                                        <br><br>
                                                                    </div>
                                                                </div>
                                                               	 <input type="hidden" name="utm_campaign" id="utm_campaign" value="" >
								 
								                                <input type="hidden" name="utm_content" id="utm_content" value="" >
								 
                                								 <input type="hidden" name="SourceIPAddress" id="SourceIPAddress" value="" >
                                								 
                                								 <input type="hidden" name="utm_medium" id="utm_medium" value="" >
                                								 
                                								 <input type="hidden" name="SourceReferrerURL" id="SourceReferrerURL" value="" >
                                								 <input type="hidden" name="utm_keyword" id="utm_keyword" value="" >
                                                            </form>
                                                        </div>
</div>
  
  <!--Top Banner-->
  
<!--<div class="container-fluid visible-desktop" id="enquire" data-toggle="modal" data-id="Get Free Counselling" data-target="#exampleModal1"  style="cursor:pointer; background: url('https://mbaonlinecourse.com/images/mainbannergn.png') no-repeat;-->
<!--      background-size: contain; height:600px;">-->
<!--</div>-->

<!--<div class="visible-phone">-->
<!--    <img class="img-fluid" alt="Online-Distance-MBA" id="enquire" data-toggle="modal" data-id="Get Free Counselling" data-target="#exampleModal1" style="cursor:pointer; width:100%; margin-top:81px;"  src="https://mbaonlinecourse.com/images/mainbannergn.png">-->
<!--</div>-->


    <!--Test-->
<div class="container topbanner" style="">
    <div class="row">
        <div class="col-md-7 contentsection" style="">
             <div id="smainheader" class=""><!-- removed class bg-white-->
                <h2 style="font-size:46px; margin-bottom:10px; padding-bottom:11px;" class="gradient-text mobileheader uparwaliline">Online MBA Degree Programs</h2>
                <h2 class="mobileheader">from India's Top B-schools</h2>
                <p class="pmobile">Move up the management ladder with the best Online MBA Courses from <Span class="nowshow"><br></Span> top B-schools in India.</p>
                    
                <div class="custom-list" style="margin-top:30px; margin-left:19px;">
                    <!--<div class="custom-item">-->
                    <!--    <span class="custom-icon"></span>-->
                    <!--        UGC Entitled, AICTE Approved, AACSB Accredited Programs -->
                    <!--</div>-->
                    <!--<div class="custom-item">-->
                    <!--    <span class="custom-icon"></span>-->
                    <!--    Continuous Learning Opportunities-->
                    <!--</div>-->
                    <!--<div class="custom-item">-->
                    <!--    <span class="custom-icon"></span>-->
                    <!--    Career Focused Programs-->
                    <!--</div>-->
                    <!--<div class="custom-item">-->
                    <!--    <span class="custom-icon"></span>-->
                    <!--    50% Average Hike across MBA courses-->
                    <!--</div>-->
                    
                    <div class="row">
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="Amity Online MBA" src="https://mbaonlinecourse.com/images/logosuni/Amity.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="Symbiosis Online MBA" src="https://mbaonlinecourse.com/images/logosuni/Symbiosis.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="Manipal Online MBA" src="https://mbaonlinecourse.com/images/logosuni/MUJ.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="DY Patil Online MBA" src="https://mbaonlinecourse.com/images/logosuni/DPU.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="Online MBA Manipal University" src="https://mbaonlinecourse.com/images/logosuni/NMIMS-1.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="Jain Online MBA" src="https://mbaonlinecourse.com/images/logosuni/Jain.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="LPU Online MBA" src="https://mbaonlinecourse.com/images/logosuni/LPU.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>
                        <div class="col-md-3 col-6 custom-item">
                            <img class="abhi topbannerunilogos img-fluid" alt="OP Jindal Online MBA"  src="https://mbaonlinecourse.com/images/logosuni/OP JIndal.png" data-abhishek="1" style="cursor: pointer; border:none!important;" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        </div>

                    </div>
                    
                </div>
                
                <div class="row mt-3 no-gutters" style=" margin-left:3px; margin-top:19px;" id="buttons-row">
                    <div class="col-md-3 col-12">
                        <div class="bttncenter">
                            <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                      Find Best University
                                </button>
                            
                        </div>
                    </div>
                    
                    <!--<div class="col-md-3 col-12">-->
                    <!--    <div class="bttncenter">-->
                    <!--        <button type="button" class="btn btntop secondbtn" id="enquire1" data-toggle="modal"-->
                    <!--                    style="background-color: #002049!important; color: rgb(255, 255, 255); border-radius: 10px!important; font-size:17px; margin-left: 60px;"-->
                    <!--                        data-id="Download Brochure" data-target="#exampleModal1">-->
                    <!--                        Download Brochure-->
                    <!--                    </button>-->
                    <!--    </div>-->
                    <!--</div>-->
                
                </div>
        </div>
        
</div>
        <div class="col-md-5">
            <img class="img-fluid contentimg" style="" src="https://mbaonlinecourse.com/images/newban.webp">
        </div>
        </div>
</div>
<!-----------------------------------------------------------------------Top Banner------------------------------------------------------------------------->
    <div id="home" style="display:none;" class="header-form-bgimage-lp">
        <div  class="container-fluid">
            <div class="row d-flex text-center">
                <div class="vertically-middle">
                <h1>Top Distance / Online MBA Institutes In India</h1>
                <p> Powering Education. Empowering Professionals.</p>
                </div>
            </div>
        </div>
    </div>
    <!--================================= HEADER-FORM-1 END =============================================-->
    
<!--online MBA Degree Courses-->
<div class="container-fluid bg-img" style="display:none;">
    <div class="container mainhederconte" style="padding-bottom:30px;" id="container">
        
        <div id="row">
            <div id="mainheader" class=""><!-- removed class bg-white-->
                <h2 style="font-size:46px;margin-bottom:10px" class="gradient-text mobileheader uparwaliline">Online MBA Degree Programs</h2>
                <h2 class="mobileheader">from India Top B-schools</h2>
                <p class="pmobile">Move up the management ladder with the best Online MBA Courses from top B-schools in India and abroad.</p>
                    
                <div class="custom-list">
                    <div class="custom-item">
                        <span class="custom-icon"></span>
                            UGC Entitled, AICTE Approved, AACSB Accredited Programs 
                    </div>
                    <div class="custom-item">
                        <span class="custom-icon"></span>
                        Continuous Learning Opportunities
                    </div>
                    <div class="custom-item">
                        <span class="custom-icon"></span>
                        Career Focused Programs
                    </div>
                    <div class="custom-item">
                        <span class="custom-icon"></span>
                        50% Average Hike across MBA courses
                    </div>
                    
                </div>
                
                <div class="row mt-3 no-gutters" style=" margin-left:-17px; margin-top:19px;" id="buttons-row">
                    <div class="col-md-3 col-12">
                        <div class="bttncenter">
                            <button type="button" class="btn btntop" id="enquire" data-toggle="modal" style="background-color: #002049!important; color: rgb(255, 255, 255); border-radius: 10px!important; font-size:17px"   
                            data-id="Get Free Counselling" data-target="#exampleModal1">
                                Get Free Counselling
                            </button>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-12">
                        <div class="bttncenter">
                            <button type="button" class="btn btntop secondbtn" id="enquire1" data-toggle="modal"
                                        style="background-color: #002049!important; color: rgb(255, 255, 255); border-radius: 10px!important; font-size:17px; margin-left: 35px;"
                                            data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                        </div>
                    </div>
                
                </div>
            </div>
            <div id="img-container">
                <!--<img src="https://mbaonlinecourse.com/images/top-disc.webp"  alt="Online MBA">-->
            </div>
        </div>
    </div>
</div>







<div class="sec-two-lp" style="display:none;">
    <div class="container-fluid">
            <div class="row d-flex text-center ">
                <div class="vertically-middle mb-30">
                <img src=" https://mbaonlinecourse.com/images/newlogo.png" alt="distancemba" />
                </div>
            </div>
             <div class="row d-flex text-center ">
                <div class="vertically-middle w-60">
                <h2 class="mt-30 mb-30">Admissions Open For Online MBA 2024</h2>
                <p class="mt-30 mb-30">Explore Top Online MBA Institutes In India. Select and choose the most suitable course for you. UGC / AICTE / NAAC Recognized programs.</p>
                </div>
            </div>
             <div class="row d-flex text-center mt-30 ">
                <div class="vertically-middle">
                       <button type="button" class="btn btntop" id="enquire" data-toggle="modal" style="background-color: #002049!important; color: rgb(255, 255, 255);" data-id="Enquire Now" data-target="#exampleModal1"> Enquire Now </button>
                </div>
            </div>
        </div>
</div>

<div class="sec-three-lp">
        <div class="container-fluid">
             <div class="row d-flex text-center ">
                <div class="vertically-middle w-80">
                <h2 class="mt-30 mb-30">Top Online MBA Colleges In India</h2>
                <p class="mt-30 mb-30">Compare and select the most suitable course from top-rated Online MBA institutes from India.</p>
                </div>
            </div>
        </div>
</div>




    <!--Top Online Learning Insitutes-->
<div class="containeriuytre mt-20">
   
    <div class="Container custcont" >
         <p class="graident-color gradienthead">Best Online, Distance & PGDM</p>
    <h2 class="gradientmobb">Programs from <span class="graident-color ">Top Universities</span></h2> 
    <hr>
        
        <div class="row" style="margin-top:25px!important;">
            
            <!--Amity-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Amity University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/Amity.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                      Amity University, Noida
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">AICTE,UGC, NIRF, NAAC A+</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,79,400/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong> Marketing, Human Resources, Accounting and Financial, IT, Insurance, Hospitality,etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Symbiosis-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/SCDL.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/SCDL.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                     Symbiosis Center of Distance Learning, Pune
                    </div>
                        <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online PGDM</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">AICTE</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Stars 60,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Banking and Financial Services, IT, Business Administration, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Manipal-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Manipal.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/MUJ.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Manipal University, Jaipur
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-7 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-7 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">AICTE,UGC, NIRF, NAAC A+</span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,57,500/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>HR, Finance, Marketing, Operations, International Business, and Analytics & Data Science etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--DPU-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/DPU.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/DPU.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Dr. DY Patil University, Pune
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                         <div class="row p-3">
                            <div class="col-md-7 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-7 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, NAAC A, NIRF, AICTE</span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,59,200/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Hospital and Healthcare, Marketing, Internationl Business, Entrepreneurship,  etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Mahe-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/NMIMS.jpg" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/NMIMS-1.jpg" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        NMIMS CDOE, Mumbai
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                         <div class="row p-3">
                            <div class="col-md-7 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-7 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">NIRF, NAAC A+, UGC, AICTE</span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,96,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Human Resources, Finance, Marketing, Operations etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Jain-->
             <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Jain University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/Jain.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Jain University, Bangalore
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                         <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">NAAC, AICTE, QS Ranking</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,60,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong> HR, Finance, Marketing, General Mgmt., Systems and Operations, International Finance etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--LPU-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Lovely Professional University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/LPU.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                       Lovely Professional University, Punjab
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">NAAC A+, AICTE, NIRF, UGC</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,24,100</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Finance, Human Resource Management, Marketing, Information Technology, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--OPJ-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/OP Jindal Global University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/Frame 493.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                       O.P Jindal Global University, Harayana
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">1 Year</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">QS Ranking, Memeber of AACSB</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,50,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Operations, Strategic Management, Marketing, Finance etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Bharti Vidyapeeth-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Bharati Vidyapeeth Institute.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/pngwing.com (1) 1.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Bharati Vidyapeeth Institute, Pune
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                          <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">AICTE, NAAC A+, UGC</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,30,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Finance, Human Resource Management, Marketing, Information Technology, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            <!--Chandigarh University-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Chandigarh University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/Chandigarh_University_Seal 1.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Chandigarh University, Punjab
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">NAAC A+, UGC, QS Ranking, NIRF</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,50,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Marketing, HRM, IBs, Entrepreneurship, Finance, Hospital Management,  IT, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Parul University-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Parul university.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/Frame 527.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Parul University, Gujrat
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, NAAC A++, NIRF, QS Ranking</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 90,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Banking and Finance, HRM Finance Marketing, International Trade, Operations etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Uttranchal Univeristy-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Uttaranchal University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/logo/uu.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                       Uttaranchal University, Uttarakhand
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, AICTE, NAAC A+, <br>QCI </span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 80,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Marketing Management, Financial Management, Human Resource Management, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
            
                <!--Chandigarh University-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Shoolni.jpg" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/university/Shoolni-1.jpg" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Shoolini University, Himachal
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, QS Ranking, NIRF</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,20,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Marketing, HRM, Bio-Tech, Finance, Health care Management,  IT, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Parul University-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/UPES.jpg" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/university/UPES-1.jpg" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        UPES University, Uttarakhand
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, NAAC A, NIRF, QS Ranking</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 175,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Oil & Gas Mgmt, Power Mgmt, Infra Mgmt,HRM Finance Marketing, Operations Mgmt, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Uttranchal Univeristy-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/SP Jain (1).jpg" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/university/SP Jain-1 (1).jpg" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                       SP Jain University, Mumbai
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Executive MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">18 Months</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">AACA, TEQSA, CPE </span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 14,86,800/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Marketing Management, Financial Management, Human Resource Management, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
               <!--Chandigarh University-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Amrita Vishwa Vidyapeetham.jpg" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/university/Amrita Vishwa Vidyapeetham-1.jpg" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        Online Amrita, Coimbatore
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">NAAC A++, UGC, WES, NIRF</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 1,70,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Marketing, HRM, IBs, Entrepreneurship, Finance, Hospital Management,  IT, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Parul University-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/GLA.jpg" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/university/GLA-1.jpg" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                        GLA University, Mathura
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, NAAC A+, NIRF</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 96,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Banking and Finance, HRM Finance Marketing, Operations etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Uttranchal Univeristy-->
            <div class="col-md-4 col-12 mb-3">
                <div id="customcard-card" class="card" style=" border: 1px solid #d1d1d1; border-radius: 18px; padding: 0px; box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 8%); transition: background .3s, border .3s, border-radius .3s, box-shadow .3s;">
                    <div class="position-relative">
                        <img style="width:100%!important; border-radius: 14px 14px 0px 0px;" src="https://mbaonlinecourse.com/images/university/Sharda University.png" id="customcard-card-img-top" class="card-img-top" alt="Image">
                        <div id="customcard-card-img-overlay" class="card-img-overlay">
                            <div id="customcard-logo">
                                <img style="height:60px; width:60px;" src="https://mbaonlinecourse.com/images/university/Sharda University-1.png" alt="Logo" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div id="customcard-university-name" style="padding:13px">
                       Sharda University, Noida
                    </div>
                    <div id="customcard-card-body" class="card-body" style="padding: 18px 18px 0px 18px;">
                        <div class="row p-3">
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text" >
                                    <span class="custom-iconm"></span>
                                    <span class="custom-text">Online MBA</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-iconc"></span>
                                    <span class="custom-text">2 Years</span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <span class="custom-icons"></span>
                                    <span class="custom-text">UGC, NIRF, NAAC A+ </span>
                                </div>
                            </div>
                            
                            <div class="col-md-6 col-6">
                                <div id="customcard-icon-text">
                                    <i class="custom-icon-inr" aria-hidden="true"></i>
                                    <span class="custom-text">Fee Starts 100,000/-</span>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <hr style="border:0; height:2px; background-color:black;">
                                <p style="font-size:12px;"><strong>Specialisation :</strong>Marketing Management, Financial Management, Human Resource Management, etc...</p>
                                
                            </div>
                             <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" rahul btn-custom btn-custom1" data-rahul="1" style="" data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                    Enquire Now
                                </button>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <button type="button" class=" abhi btn-custom btn-custom2" data-abhishek="1" style="" data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                                    Download Brochure
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
            
            
            
            
        </div> 
        
    </div>   
        
     
    
    <div class="container">
            
          
        
        <div style="display:none;" class="row justify-content-center">
                <!--Colleges-->
                
                <!--Manipal University Jaipur-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/muju.jpg" class="img-fluid rounded" alt="manipal" />
                                <h3>Manipal University Online</h3>
                            </div>
                            <div class="col-sm-8 col-12">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From Manipal University</h4>
                                    <ul>
                                        <li style="font-size:14px;">Manipal University Jaipur UGC-Recognized University</li>
                                        <li style="font-size:14px;">Eligibility: Bachelor’s degree with a minimum of 50% aggregate marks.</li>
                                    </ul>
                                     <div class="ondexk"><div>                                     </div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">UGC-entitled, NAAC A++ accredited</span>
                                                </li>
                                        </ul>
                                    </div>
                                    
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12">
                                            <div class="bothbutton">
                                           <button type="button" class="btn rahul" data-rahul="1"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div>
                                        </div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                             <button type="button" class="btn abhi" data-abhishek="1"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                        </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
                <!--Amity University Online-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 col-12 my-auto text-center">
                                <img class="lp-img img-fluid rounded" src="/https://mbaonlinecourse.com/images/lp/logos/amity.jpg" alt="amity" />
                                <h3>Amity University Online</h3>
                            </div>
                            <div class="col-sm-8 col-12">
                                <div class="lp-ul f-16 mb-20">
                                     <h4 class="feeheader">MBA From Amity University</h4>
                                    <ul>
                                        <li style="font-size:14px;">Approved by UGC, AICTE, AIU, ACU, NAAC</li>
                                        <li style="font-size:14px;">It offers various UG, PG and PhD programmes, including BA, BBA, BTech.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">UGC-entitled, EOCCS certified</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="2"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                             <button type="button" class="btn abhi" data-abhishek="2"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                        </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Lovely Professional University Online-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 col-12 my-auto text-center">
                                <img class="lp-img img-fluid rounded" src=" https://mbaonlinecourse.com/images/lp/logos/lpu.jpg" alt="LPU" />
                                <h3>Lovely Professional University Online</h3>
                            </div>
                            <div class="col-sm-8 col-12">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From Lovely Professional University</h4>
                                    <ul>
                                        <li style="font-size:14px;">Recognized by UGC and offers various management programs</li>
                                       
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                   <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">UGC Accredited, NAAC A++ University</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="3"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="3"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Symbiosis Center of Distance Learning-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                               <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/scdl.jpg" class="img-fluid rounded" alt="scol" />
                                      <h3>Symbiosis Center of Distance Learning</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">PG Diploma in Business Administration</h4>
                                    <ul>
                                        <li style="font-size:14px;">International / SAARC Graduate from a recognised / accredited University / Institution.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">PG Diploma</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">AICTE Approved</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="4"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="4"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Form On top header only on phone-->
<div class=" onlymob" style="display:none;">
     <h2 style="font-size:15px!important; padding-bottom:10px!important; color:#000;" > Enter your details and get free career counselling in top B-Schools.</h2>
     <div class="contact-div header-contact-form header-contact-bg padding-top-xs onlymob"
                                                            id="get_free_counselling">

                                                            <form class="contact-form1" method="POST"
                                                                action="lp-verify_mob.php" name="frmid"
                                                                enctype="multipart/form-data">
                                                                <input type="hidden" name="pageurl" id="pageurl" value='https://distancemba.co.in/online-mba/index.php'>
                                                                <input type="hidden" name="entryform" id="entryform" value>
                                                                <div class="clearfix">
                                                                    <div class="header-contact-bg-pad"><br>
                                                                        <h3 id="heading" class="text-left"
                                                                            style="padding-left:16px;"></h3>
                                                                        <br>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control" type="text"
                                                                                    name="fname" id="fname"
                                                                                    placeholder="Full Name*"
                                                                                    required>
                                                                            </div>
                                                                            <!--<div class="form-group col-md-6 col-12 unit">-->
                                                                            <!--    <input style="border-radius:10px!important;" class="form-control" type="text"-->
                                                                            <!--        name="lname" id="lname"-->
                                                                            <!--        placeholder="Last Name*"-->
                                                                            <!--        required>-->
                                                                            <!--</div>-->
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="phoneno" id="phoneno"
                                                                                    placeholder="Mobile Number*"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10" pattern="^\d{10}$" oninvalid="this.setCustomValidity('Please enter correct phone')" oninput="this.setCustomValidity('')" required>
                                                                            </div>
                                                                        </div>


                                                                        <div class="form-row form-div form-bottom-1">
                                                                            <div class="form-group col-md-6 col-12 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control form-text"
                                                                                    type="text" name="email" id="email"
                                                                                    placeholder="Email*" required required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" oninvalid="this.setCustomValidity('Please enter correct email')" oninput="this.setCustomValidity('')">
                                                                            </div>
                                                                            <div class="form-group col-md-6 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control form-text"
                                                                                    type="text" name="city" id="city"
                                                                                    placeholder="Enter City*"
                                                                                    required>
                                                                            </div>
                                                                        </div>
    
                                                                         <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="mx_Interested_In_Speclization" id="mx_Interested_In_Speclization" required>
                                    											<option value="">Select Specialization</option>
                                    											<option value="MBA (Banking and Finance Management)">MBA (Banking and Finance Management)</option>
                                    											<option value="MBA (Business Management)">MBA (Business Management)</option>
                                    											<option value="MBA (Financial Management)">MBA (Financial Management)</option>
                                    											<option value="MBA (Human Resource Management)">MBA (Human Resource Management)</option>
                                    											<option value="MBA (International Trade Management)">MBA (International Trade Management)</option>
                                    											<option value="MBA (Information Technology and Systems Mangement)">MBA (Information Technology and Systems Mangement)</option>
                                    											<option value="MBA (Marketing Management)">MBA (Marketing Management)</option>
                                    											<option value="MBA (Operations Management)">MBA (Operations Management)</option>
                                    											<option value="MBA (Retail Management)">MBA (Retail Management)</option>
                                    											<option value="MBA (Supply Chain Management)">MBA (Supply Chain Management)</option>
                                    											<option value="Master of Business Administration (Executive MBA)">Master of Business Administration (Executive MBA)</option>
                                    											<option value="MBA (X) in Business Analytics">MBA (X) in Business Analytics</option>
											
										                                    </select>
                                                                        </div>

                                                                        <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="university" id="university" required>
                                                                                <option value="">Select University
                                                                                </option>
                                                                                <option
                                                                                    value="Manipal University">
                                                                                    Manipal University</option>
                                                                                <option value="Symbiosis University">
                                                                                    Symbiosis University</option>
                                                                                <option
                                                                                    value="Dr. D. Y. Patil Vidyapeeth University">
                                                                                    Dr. D. Y. Patil
                                                                                    Vidyapeeth University</option>
                                                                                <option value="Jain University">Jain
                                                                                    University</option>
                                                                                <option
                                                                                    value="Amity University, distance and Distance Learning (ODL)">
                                                                                    Amity
                                                                                    University, distance and Distance
                                                                                    Learning (ODL)</option>
                                                                                <option
                                                                                    value="Lovely Professional University Distance Learning">
                                                                                    Lovely
                                                                                    Professional University Distance
                                                                                    Learning</option>
                                                                                <option value="Chandigarh University">
                                                                                    Chandigarh University</option>
                                                                              <!--  <option
                                                                                    value="Indira Gandhi National Open University (IGNOU)">
                                                                                    Indira Gandhi
                                                                                    National Open University (IGNOU)
                                                                                </option>-->
                                                                                <option
                                                                                    value="Welingkar Institute of Management Development & Research">
                                                                                    Welingkar Institute of Management
                                                                                    Development & Research</option>
                                                                                <!--<option value="Manipal University">-->
                                                                                <!--    Manipal University</option>-->
                                                                                <option value="Other">Other</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div style="display:none;">
                                                                            <label for="honeypot">Leave this field blank:</label>
                                                                            <input type="text" id="honeypot" name="honeypot">
                                                                        </div>



                                                                        <div
                                                                            class="form-div phoneno-bottom error-div unit">
                                                                            <input class="header-contact-form"
                                                                                type="checkbox" name="tnc" id="tnc"
                                                                                checked="checked"> I agree to get
                                                                            updates from Distance-MBA
                                                                        </div>

                                                                        <!--============= SUCESSS AND FAILURE MESSAGE DISPLAY HERE ========-->
                                                                        <div class="left form-error-top"> <span
                                                                                class="form-success sucessMessage">
                                                                            </span>
                                                                            <span class="form-failure failMessage">
                                                                            </span>
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1"
                                                                            id="verify_id1" style="display:none11;">
                                                                            <!--  <div class="form-group col-md-6">-->
                                                                            <!-- <input type="text" class="form-control form-text" name="verify_otp" id="verify_otp" placeholder="Verify OTP" autocomplete="off">-->
                                                                            <!--</div> -->
                                                                            <!-- <div class="form-group col-md-6">-->
                                                                            <!-- <input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="btnVerifyPhone" id="btnVerifyPhone" value="Verify OTP">-->
                                                                            <!--</div>-->
                                                                        </div>


                                                                        <!-- <div class="form-group col-md-6" id="sendotp_div">-->
                                                                        <!--<input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="sendotp" id="sendotp" value="Send OTP">-->
                                                                        <!--</div> -->


                                                                        <div class="form-group col-md-6"
                                                                            id="form_data_div1" style="display:none1;">
                                                                             <style>
                                                                                @media only screen and (max-width: 767px) {
                                                                                    #btnSubmit {
                                                                                        width: 100%!important;
                                                                                        max-width: 100%!important;
                                                                                        height: 30px!important;
                                                                                        border-radius: 15px!important;
                                                                                        margin: 0px 0px 0px 0px;
                                                                                    }
                                                                                }
                                                                            </style>
                                                                            <input type="submit" class="submit-btn contact-form-submit text-center "
                                                                                style="color:#fff!important; width:100%; height:30px; border-radius:21px;"
                                                                                name="btnSubmit" id="btnSubmit"
                                                                                value="Submit">
                                                                        </div>

                                                                        <span id="loader"></span>
                                                                        <br><br>
                                                                    </div>
                                                                </div>
                                                               	 <input type="hidden" name="utm_campaign" id="utm_campaign" value="" >
								 
								 <input type="hidden" name="utm_content" id="utm_content" value="" >
								 
								 <input type="hidden" name="SourceIPAddress" id="SourceIPAddress" value="" >
								 
								 <input type="hidden" name="utm_medium" id="utm_medium" value="" >
								 
								 <input type="hidden" name="SourceReferrerURL" id="SourceReferrerURL" value="" >
								 <input type="hidden" name="utm_keyword" id="utm_keyword" value="" >
                                                            </form>
                                                        </div>
</div>
                
                <!--DY Patil University Online-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/dpu.jpg" class="img-fluid rounded" alt="dpu" />
                                <h3>DY Patil University Online </h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                     <h4 class="feeheader">MBA From DY Patil University</h4>
                                    <ul>
                                        <li>DY Patil Pune has also been accredited with an A++ grade by (NAAC). </li>
                                        <li>The Institute has been approved UGC , AICTE</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">AICTE Approved, NIRF Top Rank</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="5"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="5"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Jain University-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/jain.jpg" class="img-fluid rounded" alt="dpu" />
                                <h3>Jain University Online</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Jain Online MBA Program</h4>
                                    <ul>
                                        <li style="font-size:14px;">Jain University (Deemed-to-be-Univeristy) is awarded Graded Autonomy by UGC.  </li>
                                        <li style="font-size:14px;">(NAAC) rated A++ grade with a CGPA of 3.71 </li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">UGC-entitled, EOCCS certified</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="6"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="6"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Chandigarh University Online-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/cu.jpg" class="img-fluid rounded" alt="cu" />
                                <h3>Chandigarh University Online MBA</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From Chandigarh University</h4>
                                    <ul>
                                        <li style="font-size:14px;">Graduates of recognized professional programmes like CA/ ICWA etc. are also eligible.</li>
                                        <li style="font-size:14px;">Some of the popular courses include B.Tech, BBA, M.Tech, MCA and M.Pharm courses.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">Internationally Recognized Program</span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="7"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="7"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                <!--Allince University Online MBA-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/alliance.jpg" class="img-fluid rounded" alt="ALLIANCE" />
                                <h3>Alliance University Online MBA</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From Alliance University</h4>
                                    <ul>
                                        <li style="font-size:14px;">1st Private University in South India</li>
                                        <li style="font-size:14px;">216 World-Class Faculty from India and abroad</li>
                                        <li style="font-size:14px;">55 Study Abroad Options in Global Universities</li>
                                        <li style="font-size:14px;">21,000+ Global Alumni in 45+ Countries</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">Accredited by IAC</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="8"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="8"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--SRM Online-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/srm.jpg" class="img-fluid rounded" alt="SRM" />
                                <h3>SRM Online</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From SRM University</h4>
                                    <ul>
                                        <li style="font-size:14px;">Recognized by AICTE and UGC Entitled</li>
                                        <li style="font-size:14px;">SRM Institute of Science and Technology (SRM IST Chennai) has been accredited by NAAC with a grade of 'A++'</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">AICTE Recognized · UGC Entitled</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="9"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="9"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Form On top header only on phone-->
<div class="container-fluid onlymob" style="display:none;" >
     <h2 style="font-size:15px!important; padding-bottom:10px!important; color:#000;" > Enter your details and get free career counselling in top B-Schools.</h2>
     <div class="contact-div header-contact-form header-contact-bg padding-top-xs onlymob"
                                                            id="get_free_counselling">

                                                            <form class="contact-form1" method="POST"
                                                                action="lp-verify_mob.php" name="frmid"
                                                                enctype="multipart/form-data">
                                                                <input type="hidden" name="pageurl" id="pageurl" value='https://distancemba.co.in/online-mba/index.php'>
                                                                <input type="hidden" name="entryform" id="entryform" value>
                                                                <div class="clearfix">
                                                                    <div class="header-contact-bg-pad"><br>
                                                                        <h3 id="heading" class="text-left"
                                                                            style="padding-left:16px;"></h3>
                                                                        <br>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control" type="text"
                                                                                    name="fname" id="fname"
                                                                                    placeholder="Full Name*"
                                                                                    required>
                                                                            </div>
                                                                            <!--<div class="form-group col-md-6 col-12 unit">-->
                                                                            <!--    <input style="border-radius:10px!important;" class="form-control" type="text"-->
                                                                            <!--        name="lname" id="lname"-->
                                                                            <!--        placeholder="Last Name*"-->
                                                                            <!--        required>-->
                                                                            <!--</div>-->
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="phoneno" id="phoneno"
                                                                                    placeholder="Mobile Number*"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10" pattern="^\d{10}$" oninvalid="this.setCustomValidity('Please enter correct phone')" oninput="this.setCustomValidity('')" required>
                                                                            </div>
                                                                        </div>


                                                                        <div class="form-row form-div form-bottom-1">
                                                                            <div class="form-group col-md-6 col-12 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control form-text"
                                                                                    type="text" name="email" id="email"
                                                                                    placeholder="Email*" required required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" oninvalid="this.setCustomValidity('Please enter correct email')" oninput="this.setCustomValidity('')">
                                                                            </div>
                                                                            <div class="form-group col-md-6 unit">
                                                                                <input style="border-radius:10px!important;" class="form-control form-text"
                                                                                    type="text" name="city" id="city"
                                                                                    placeholder="Enter City*"
                                                                                    required>
                                                                            </div>
                                                                        </div>
    
                                                                         <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="mx_Interested_In_Speclization" id="mx_Interested_In_Speclization" required>
                                    											<option value="">Select Specialization</option>
                                    											<option value="MBA (Banking and Finance Management)">MBA (Banking and Finance Management)</option>
                                    											<option value="MBA (Business Management)">MBA (Business Management)</option>
                                    											<option value="MBA (Financial Management)">MBA (Financial Management)</option>
                                    											<option value="MBA (Human Resource Management)">MBA (Human Resource Management)</option>
                                    											<option value="MBA (International Trade Management)">MBA (International Trade Management)</option>
                                    											<option value="MBA (Information Technology and Systems Mangement)">MBA (Information Technology and Systems Mangement)</option>
                                    											<option value="MBA (Marketing Management)">MBA (Marketing Management)</option>
                                    											<option value="MBA (Operations Management)">MBA (Operations Management)</option>
                                    											<option value="MBA (Retail Management)">MBA (Retail Management)</option>
                                    											<option value="MBA (Supply Chain Management)">MBA (Supply Chain Management)</option>
                                    											<option value="Master of Business Administration (Executive MBA)">Master of Business Administration (Executive MBA)</option>
                                    											<option value="MBA (X) in Business Analytics">MBA (X) in Business Analytics</option>
											
										                                    </select>
                                                                        </div>

                                                                        <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="university" id="university" required>
                                                                                <option value="">Select University
                                                                                </option>
                                                                                <option
                                                                                    value="Manipal University">
                                                                                    Manipal University</option>
                                                                                <option value="Symbiosis University">
                                                                                    Symbiosis University</option>
                                                                                <option
                                                                                    value="Dr. D. Y. Patil Vidyapeeth University">
                                                                                    Dr. D. Y. Patil
                                                                                    Vidyapeeth University</option>
                                                                                <option value="Jain University">Jain
                                                                                    University</option>
                                                                                <option
                                                                                    value="Amity University, distance and Distance Learning (ODL)">
                                                                                    Amity
                                                                                    University, distance and Distance
                                                                                    Learning (ODL)</option>
                                                                                <option
                                                                                    value="Lovely Professional University Distance Learning">
                                                                                    Lovely
                                                                                    Professional University Distance
                                                                                    Learning</option>
                                                                                <option value="Chandigarh University">
                                                                                    Chandigarh University</option>
                                                                              <!--  <option
                                                                                    value="Indira Gandhi National Open University (IGNOU)">
                                                                                    Indira Gandhi
                                                                                    National Open University (IGNOU)
                                                                                </option>-->
                                                                                <option
                                                                                    value="Welingkar Institute of Management Development & Research">
                                                                                    Welingkar Institute of Management
                                                                                    Development & Research</option>
                                                                                <!--<option value="Manipal University">-->
                                                                                <!--    Manipal University</option>-->
                                                                                <option value="Other">Other</option>
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        <div style="display:none;">
                                                                            <label for="honeypot">Leave this field blank:</label>
                                                                            <input type="text" id="honeypot" name="honeypot">
                                                                        </div>



                                                                        <div
                                                                            class="form-div phoneno-bottom error-div unit">
                                                                            <input class="header-contact-form"
                                                                                type="checkbox" name="tnc" id="tnc"
                                                                                checked="checked"> I agree to get
                                                                            updates from Distance-MBA
                                                                        </div>

                                                                        <!--============= SUCESSS AND FAILURE MESSAGE DISPLAY HERE ========-->
                                                                        <div class="left form-error-top"> <span
                                                                                class="form-success sucessMessage">
                                                                            </span>
                                                                            <span class="form-failure failMessage">
                                                                            </span>
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1"
                                                                            id="verify_id1" style="display:none11;">
                                                                            <!--  <div class="form-group col-md-6">-->
                                                                            <!-- <input type="text" class="form-control form-text" name="verify_otp" id="verify_otp" placeholder="Verify OTP" autocomplete="off">-->
                                                                            <!--</div> -->
                                                                            <!-- <div class="form-group col-md-6">-->
                                                                            <!-- <input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="btnVerifyPhone" id="btnVerifyPhone" value="Verify OTP">-->
                                                                            <!--</div>-->
                                                                        </div>


                                                                        <!-- <div class="form-group col-md-6" id="sendotp_div">-->
                                                                        <!--<input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="sendotp" id="sendotp" value="Send OTP">-->
                                                                        <!--</div> -->


                                                                        <div class="form-group col-md-6"
                                                                            id="form_data_div1" style="display:none1;">
                                                                             <style>
                                                                                @media only screen and (max-width: 767px) {
                                                                                    #btnSubmit {
                                                                                        width: 100%!important;
                                                                                        max-width: 100%!important;
                                                                                        height: 30px!important;
                                                                                        border-radius: 15px!important;
                                                                                        margin: 0px 0px 0px 0px;
                                                                                    }
                                                                                }
                                                                            </style>
                                                                            <input type="submit" class="submit-btn contact-form-submit text-center "
                                                                                style="color:#fff!important; width:100%; height:30px; border-radius:21px;"
                                                                                name="btnSubmit" id="btnSubmit"
                                                                                value="Submit">
                                                                        </div>

                                                                        <span id="loader"></span>
                                                                        <br><br>
                                                                    </div>
                                                                </div>
                                                                <input type="hidden" name="utm_campaign" id="utm_campaign" value="" >
								 
								 <input type="hidden" name="utm_content" id="utm_content" value="" >
								 
								 <input type="hidden" name="SourceIPAddress" id="SourceIPAddress" value="" >
								 
								 <input type="hidden" name="utm_medium" id="utm_medium" value="" >
								 
								 <input type="hidden" name="SourceReferrerURL" id="SourceReferrerURL" value="" >
								 <input type="hidden" name="utm_keyword" id="utm_keyword" value="" >
                                                            </form>
                                                        </div>
</div>
                
                <!--BITS Pilani Distance MBA-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/bits.jpg" class="img-fluid rounded" alt="nmims" />
                                <h3>BIMTECH</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">PGDM with Specialisation in GenAI</h4>
                                    <ul>
                                        <li style="font-size:14px;">Birla Institute of Technology & Science, Pilani is a deemed university. </li>
                                        <li style="font-size:14px;">It is stitutated in  in Pilani, Jhunjhunu district, Rajasthan, India.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">PG Diploma</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">AACSB Accredited</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="10"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="10"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--ICFAI-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/icfai.jpg" class="img-fluid rounded" alt="ICFAI" />
                                <h3>(  ICFAI  ) </h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From ICFAI</h4>
                                    <ul>
                                        <li style="font-size:14px;">The ICFAI University offers various undergraduate and postgraduate programs through Online learning.</li>
                                        <li style="font-size:14px;">Approved by AICTE.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">NAAC A++ Accredited</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="11"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="11"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                
                <!--IMT Center For Distance Learning-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src=" https://mbaonlinecourse.com/images/lp/logos/imt.jpg" class="img-fluid rounded" alt="ICFAI" />
                                <h3>IMT Center For Distance Learning</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">PG Diploma Executive</h4>
                                    <ul>
                                        <li style="font-size:14px;">It is approved by AICTE.</li>
                                        <li style="font-size:14px;">Eligibility: Bachelor’s Degree in any discipline from any recognized University</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">PG Diploma</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">AICTE Approved</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="12"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="12"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--NMIMS SCE Distance-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src=" https://mbaonlinecourse.com/images/lp/logos/nmims.jpg" class="img-fluid rounded" alt="ICFAI" />
                                <h3>NMIMS SCE Distance</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">MBA From  NMIMS</h4>
                                    <ul>
                                        <li style="font-size:14px;">In 2003, NMIMS was declared a deemed-to-be university under section 3 of the UGC Act 1956.</li>
                                        <li style="font-size:14px;">Strong industry linkages at NMIMS have placed it amongst the nation prime centers</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">UGC Entitled </span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="13"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="13"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Welingker WeSchool-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/weschool.jpg" class="img-fluid rounded" alt="weschool" />
                                <h3>  Welingker Weschool</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Online PGDM</h4>
                                    <ul>
                                        <li style="font-size:14px;">Welingkar's offers Post Graduate Diploma in Management (PGDM) of 2 years duration (4 semesters) in Hybrid Online Learning mode with 18 subject specializations to choose from</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">PG Diploma</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">Top Ranked NIRF Ranking</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="14"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="14"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Punjab University Distance MBA-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src=" https://mbaonlinecourse.com/images/lp/logos/pu.jpg" class="img-fluid rounded" alt="weschool" />
                                <h3> Panjab University Distance MBA</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Distance MBA From Panjab University</h4>
                                    <ul>
                                        <li style="font-size:14px;">Punjab University has been well-known by the University Grant Commission that is (UGC). And it is also approved and accredited by the National Assessment and Accreditation Council (NAAC).</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">NAAC A++ Accredited</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="15"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="15"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Anna University-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src=" https://mbaonlinecourse.com/images/lp/logos/annamalai.png" class="img-fluid rounded" alt="weschool" />
                                <h3> Anna University Online</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Distance MBA From Anna University</h4>
                                    <ul>
                                        <li>Anna University follows a dual semester system namely, Even Semester and Odd Semester.</li>
                                        <li>Anna University has 593 affiliated colleges located in different cities of Tamil Nadu.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">Top NIRF Ranking, Recognized by AICTE</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="16"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="16"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Vekanteshwara University Online-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/vu.jpg" class="img-fluid rounded" alt="annamalai" />
                                <h3>Vekanteshwara University Online</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Online MBA From VOU</h4>
                                    <ul>
                                        <li style="font-size:14px;">Fifty-two years as a premier institute of higher learning.</li>
                                        <li style="font-size:14px;">Upgraded as Directorate of Online Education (DDE) in April 1995 as per the UGC norms</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">UGC Appoved</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="17"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="17"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                  <!-Parul university-->
                <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src="/https://mbaonlinecourse.com/images/lp/logos/parul-university.jpg" class="img-fluid rounded" alt="Parul university" />
                                <h3>Parul university</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Distance MBA from Parul University</h4>
                                    <ul>
                                        <li style="font-size:14px;">The ICFAI University offers various undergraduate and postgraduate programs through Online learning.</li>
                                        <li style="font-size:14px;">Approved by AICTE.</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">Master's Degree</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">NAAC A++ Accredited</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                            <button type="button" class="btn rahul" data-rahul="18"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
                                            Get Free Counselling
                                        </button>
                                        </div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton">
                                              <button type="button" class="btn abhi" data-abhishek="18"
                                           style="background-color: #002049!important; color: rgb(255, 255, 255);"
                                            data-toggle="modal" data-id="Download Brochure" data-target="#exampleModal1">
                                            Download Brochure
                                        </button>
                                            </div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
      
                
                <!-MDI-->
            <!--    <div class="col-md-6">
                    <div class="h-card b-shadow">
                        <div class="row cssmobflex">
                            <div class="col-sm-4 my-auto text-center">
                                <img  class="lp-img" src=" https://mbaonlinecourse.com/images/lp/logos/mdi-gurgaon.jpg" class="img-fluid rounded" alt="weschool" />
                                <h3> MDI Gurgaon</h3>
                            </div>
                            <div class="col-sm-8">
                                <div class="lp-ul f-16 mb-20">
                                    <h4 class="feeheader">Online PG Diploma in Management</h4>
                                   <ul>
                                        <li style="font-size:14px;">It is approved by AICTE.</li>
                                        <li style="font-size:14px;">Eligibility: Bachelors Degree in any discipline from any recognized University</li>
                                    </ul>
                                    <div class="ondexk"><div></div></div>
                                    <div class="feetomobile">
                                        <h4 class="feeheader"></h4>
                                            <ul class="custom-list">
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconm"></span>
                                                    <span class="custom-text">PG Diploma</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-iconc"></span>
                                                    <span class="custom-text">24 Months</span>
                                                </li>
                                                <li class="custom-itemmmmm">
                                                    <span class="custom-icons"></span>
                                                    <span class="custom-text">AICTE Approved</span>
                                                </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="col-md-6 col-12"><div class="bothbutton"></div></div>
                                        <div class="col-md-6 col-12"><div class="bothbutton"></div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
                
                
        </div>
        
         <div id="home" style="display:none;" class="header-form-bgimage-lp">
        <div class="container-fluid">
            <div class="row d-flex text-center">
                <div class="vertically-middle">
                <h1>Top Distance / Online MBA Institutes In India</h1>
                <p> Powering Education. Empowering Professionals.</p>
                </div>
            </div>
        </div>
    </div>
    </div>

    
</div>

<!--new-->
<div class="container-fluid" style="background-color:#f5e8f5; padding-top-30px; padding-bottom:30px; margin-bottom:30px;">
    <div class="text-center container">
       <p class="pt-5 " style="font-size:25px; font-weight:700;">Choose From Best Govt. Approved Indian Universities For Online MBA</p>
       <div class="row mt-5 pt-2">
           <div class="col-md-2 col-6"> <img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/Symbiosis.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/Amity.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/NMIMS-1.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/CU.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/DPU.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/OP JIndal.png" ></div>
       </div>
       <div class="row mt-2 ">
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/Jain.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/LPU.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/MUJ.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/Parul.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/online UU.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/SHarda.png" ></div>
       </div>
       
       <div class="row mt-2">
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/GLA.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/Bharati Vidyapeeth Institute (1).png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/SRM.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/Ignou.png" ></div>
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/IIMR.png" ></div>     
            <div class="col-md-2 col-6"><img alt="Online MBA" class="img-fluid mb-3" src="https://mbaonlinecourse.com/images/logosuni/VIgnan.png" ></div>
       </div>
       <button type="button" class="btn rahul mt-4" data-rahul="18"
        style="background-color: #002049!important; color: rgb(255, 255, 255);"
        data-id="Get Free Counselling" data-toggle="modal" data-target="#exampleModal1">
            Enquire Now
        </button>
    </div>
    
</div>

<!--<script-->
<!--      type="text/javascript"-->
<!--      src="https://lsqbot.converse.leadsquared.com/bot-script.js"-->
<!--    ></script>-->
<!--LSQ Chatbot-->
<!--<iframe style="bottom: 15px; right: 10px;     height: 400px;" id="lsq-chatbot" src="https://botweb.converse.leadsquared.com/?botId=786&tenantId=67907&type=WEB&channelId=e534fb4d-4ba5-4499-b215-b31278386607"></iframe>-->

<!--FAQs-->
<div class="container mt-2 mb-4 pb-2">
  <hr>
  <h2 class="mb-4"><Span class="graident-color ">Frequently Asked </Span> Questions</h2>
  
  <div class="faq-item">
    <div class="faq-header">
      <span style="font-size:18px; font-weight:bold;">Is MBA Online worth it?</span>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-content">
        <p class="mt-3 mb-2" style="fonts-size:16px;">Those with an Online MBA often can command higher salaries than those without one. In addition, having an online MBA can give you a competitive edge when applying for jobs. It can also help you advance more quickly in your career once you are hired.</p>
    </div>
  </div>
  
  <div class="faq-item">
    <div class="faq-header">
      <span style="font-size:18px; font-weight:bold;">Is online MBA equal to regular MBA?</span>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-content">
        <p class="mt-3 mb-2" style="fonts-size:16px;">There is essentially no difference in career opportunities when it comes to online MBA vs regular MBA.</p>
    </div>
  </div>
  
  <div class="faq-item">
    <div class="faq-header">
      <span style="font-size:18px; font-weight:bold;">Distance MBA or Online MBA?</span>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-content">
        <p class="mt-3 mb-2" style="fonts-size:16px;">Distance MBA provides a traditional and slower-paced approach, Online MBA offers a more contemporary, interactive, and technologically-driven learning experience.</p>
    </div>
  </div>
  
  <div class="faq-item">
    <div class="faq-header">
      <span style="font-size:18px; font-weight:bold;">Online MBA or Online PGDM?</span>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-content">
        <p class="mt-3 mb-2" style="fonts-size:16px;">An MBA is similar to a PGDM. It equips one with the necessary skills to become a successful manager. However, an online PGDM course is not only beneficial for graduate students but also for working professionals.</p>
    </div>
  </div>
  
  <div class="faq-item">
    <div class="faq-header">
      <span style="font-size:18px; font-weight:bold;">Is Online MBA degree valid?</span>
      <span class="faq-icon">+</span>
    </div>
    <div class="faq-content">
        <p class="mt-3 mb-2" style="fonts-size:16px;">
        Nationally Recognized Degree: Your online MBA will be valid for further education, government jobs, and professional certifications. Enhanced Credibility: Employers recognize accredited online MBAs from reputed universities, adding value to your resume.
        </p>
       
    </div>
  </div>
  
</div>



 <div id="home" class="header-form-bgimage-lp">
        <div class="container-fluid">
            <div class="row d-flex text-left">
                <div class="vertically-middle">
                <h1 style="font-size:32px;">Top Distance / Online MBA Institutes In India</h1>
                <p> Powering Education. Empowering Professionals.</p>
                 <button type="button" class=" abhi btn-custom btn-custom4" data-abhishek="1"  data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        Apply Now
                </button>    
                </div>
            </div>
        </div>
    </div>

<!---->


<div class="containter-fluid" style="background-color: #B70606; display:none;">
      
            <div class="row text-center">
                <div class="col-sm-12 mt-40 mb-40">
                    <h2 class="text-white" style="transform: translateY(30px);">Still Not Sure About Programs?</h2>
                    <p class="text-white mt-20 mb-20" style="transform: translateY(30px);">Contact Our Counselling Experts & Get Free Counselling</p>
                    <div style="    transform: translateY(30px);>
                  
                    <button type="button" class=" abhi btn-custom btn-custom3" data-abhishek="1"  data-id="Request Callback" data-toggle="modal" data-target="#exampleModal1">
                        Request a Callback
                    </button>
                </div>
                </div>
            </div>
        
</div>

 <!--Footer  -->
                                                                                                                                                                                                                                                                                                                                                                                           
<style>
   #exampleModal1 .modal-body{padding:0px;}
</style>

 <!--Footer  -->
      <footer class="light-footer skin-light-footer style-2 sticky-stopper pt-30" style="background-color: rgb(243, 240, 240);">
        <div class="footer-bottom">
            <!-- Footer -->
            <footer class=" text-lg-start bg-light text-muted" style="padding:30px;">


                <!-- Section: Links  -->
                <section class="">
                    <div class="container  text-md-start mt-5">
                        <!-- Grid row -->
                        <div class="row mt-3">
                            <!-- Grid column -->
                            <div class="col-md-3 col-lg-3 col-xl-3 ">
                                <!-- Content -->

                                <div style="padding-top: 10px; margin-bottom: 10px;">
                                    <img src="https://mbaonlinecourse.com/images/main site logo.png" height="30px" width="auto%" alt="logo" srcset="">
                                </div>
                                <p  style="font-size: 14px!important; text-align: justify;">
                                    Welcome to the MBA Online Course. Our website is more than just a resource; it’s a gateway to transforming your career. Our goal is to empower you to make informed decisions and achieve your professional aspirations through an exceptional online MBA experience.

                                </p>

                            </div>
                            <!-- Grid column -->

                            <!-- Grid column -->
                            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4">
                                <!-- Links -->
                                <h5 style="font-weight: 600!important; color: #000; padding-left: 40px;"
                                    class="text-uppercase fw-bold mb-4 mt-4 leftpaddmob">
                                    Top B-Schools
                                </h5>
                                <ul style="color:black">
                                    
                                    <li class="mobleftmar"><a></a>Amity Online University</li>
                                    <li class="mobleftmar">Manipal Online</li>
                                    <li class="mobleftmar">Jain Online </li>
                                    <li class="mobleftmar">DY Patil Online</li>
                                    <li class="mobleftmar">O.P Jindal Global University</li>
                                </ul>
                            </div>
                            <!-- Grid column -->

                            <!-- Grid column -->
                            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-4">
                                <!-- Links -->
                                <h5 style="font-weight: 600!important; color: #777777; padding-left: 40px; display:none;"
                                class="text-uppercase fw-bold mb-4 leftpaddmob">
                                Colleges
                            </h5>
                            <ul style="color:black;">
                                                               <li class="mobleftmar">NMIMS Online</li>

                               <li class="mobleftmar">LPU Online</li>
                               <li class="mobleftmar">Sharda University</li>
                               <li class="mobleftmar">Symbiosis Centre of Distance Learning</li>
                               <li class="mobleftmar">Chandigarh University</li>
                               <li class="mobleftmar">Uttranchal Univeristy</li>
                               
                            </ul>
                            
                            

                            </div>
                            <!-- Grid column -->

                            <!-- Grid column -->
                            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4" style="display:none;">
                                
                                <!-- Grid column -->
                            
                                <!-- Links -->
                                <h5 style="font-weight: 600!important; color: #000; padding-left: 40px;"
                                class="text-uppercase fw-bold mb-4 leftpaddmob">
                               Navigation
                            </h5>
                            <ul style="color:black;">
                               <li class="mobleftmar"><a href="https://distancemba.co.in/blog.php">Blogs</a></li>
                               
                            </ul>
                                <!-- Links -->
                                <section style="display: none;"
                                    class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
                                    <!-- Left -->
                                    <div class="me-5 d-none d-lg-block">
                                        <span>Get connected with us on social networks:</span>
                                    </div>
                                    <!-- Left -->

                                    <!-- Right -->
                                    <div>
                                        <a href="" class="me-4 text-reset">
                                            <i class="fa fa-facebook-f fa-2x" style="color: #3b5998 ;"></i>
                                        </a>

                                        </a>
                                        <a href="" class="me-4 text-reset">
                                            <i class="fa fa-instagram fa-2x" style="background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%);
                          -webkit-background-clip: text;
                                  /* Also define standard property for compatibility */
                                  background-clip: text;
                          -webkit-text-fill-color: transparent;"></i>
                                        </a>
                                        <a href="" class="me-4 text-reset">
                                            <i class="fa fa-linkedin fa-2x" style="color: #0072b1 ;"></i>
                                        </a>

                                    </div>
                                    <!-- Right -->
                                </section>
                           
                            <!-- Grid column -->
                        </div>
                        <!-- Grid row -->
                    </div>
                    </div>
                </section>
                <!-- Section: Links  -->

                <!-- Copyright -->

                <!-- Copyright -->
            </footer>
            <!-- Footer -->
            <div class="container-fluid">

                <div class="row align-items-center" style="background-color: rgb(240, 237, 237);">
                    <div class="col-lg-12 col-md-12 text-center">
                        <h5 style="text-align: center"> Copyright &copy;
                            2024 MBA Online Course
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="modal" id="mymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="margin: 0px 90px 0 70px;">
            <div class="modal-header">
                <img src="images/main site logo.png" height="50px" width="auto" alt="distance-mba">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="contact-div header-contact-form header-contact-bg padding-top-xs" id="get_free_counselling">
                    <form class="contact-form1" method="POST" action="lp-verify_mob.php" name="frmid" enctype="multipart/form-data" onsubmit="return validateForm();">
                        <input type="hidden" name="pageurl" id="pageurl" value='https://distancemba.co.in/online-mba/index.php'>
                        <input type="hidden" name="entryform" id="entryform" value>
                        <div class="clearfix">
                            <div class="header-contact-bg-pad"><br>
                                <h3 id="heading" class="text-left" style="padding-left:16px;text-align: center;"></h3>
                                <br>
                                <div class="form-row">
                                    <div class="form-group col-md-12 col-12 unit">
                                        <input style="border-radius:10px!important; width: 100%;" class="form-control" type="text" name="fname" id="fname" placeholder="Full Name*" required>
                                        <span class="errormsg" id="errname"></span>
                                    </div>
                                </div>
                                <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                    <div class="form-group col-md-12 col-12 unit">
                                        <input style="border-radius:10px!important;" class="form-control form-text phoneno" name="phoneno" id="phoneno" placeholder="Mobile Number*" autocomplete="off" type="text" maxlength="10" onkeydown="return valid_entry_num(event.key)" required>
                                        <span class="errormsg" id="errp"></span>
                                    </div>
                                </div>
                                <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                    <div class="form-group col-md-12 col-12 unit">
                                        <input style="border-radius:10px!important; width: 100%;" class="form-control form-text" type="email" name="email" id="email" placeholder="Email*" required >
                                        <span class="errormsg" id="erre"></span>
                                    </div>
                                    <div class="form-group col-md-12 unit">
                                        <input style="border-radius:10px!important; width: 100%;" class="form-control form-text" type="text" name="city" id="city" placeholder="City*" onkeydown="return valid_entry_char(event.key)" required>
                                        <span class="errormsg" id="errc"></span>
                                    </div>
                                </div>
                                <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                    <select style="border-radius: 10px !important; margin: 6px -16px; width: 107%;" class="form-control selectcls" name="university" id="university" required>
                                        <option value="">Select University</option>
                                        <option value="Amity University">Amity University</option>
                                        <option value="Manipal University">Manipal University</option>
                                        <option value="O.P. Jindal Global University">O.P. Jindal Global University</option>
                                        <option value="Jain University">Jain University</option>
                                        <option value="Dr. DY. Patil Vidyapeeth University">Dr. DY. Patil Vidyapeeth University</option>
                                        <option value="Lovely Professional University">Lovely Professional University</option>
                                        <option value="Uttaranchal University">Uttaranchal University</option>
                                        <option value="Symbiosis Centre of Distance Learning (SCDL)">Symbiosis Centre of Distance Learning (SCDL)</option>
                                        <option value="Institute of Management Technology, Ghaziabad">Institute of Management Technology, Ghaziabad (IMT)</option>
                                        <option value="Sharda University">Sharda University</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                                <div style="display:none;">
                                    <label for="honeypot">Leave this field blank:</label>
                                    <input type="text" id="honeypot" name="honeypot">
                                </div>
                                <div class="form-div phoneno-bottom error-div unit">
                                    <input class="header-contact-form" type="checkbox" name="tnc" id="tnc" checked="checked"> I agree to get updates from counsellor
                                </div>
                                <div class="left form-error-top"> 
                                    <span class="form-success sucessMessage"></span>
                                    <span class="form-failure failMessage"></span>
                                </div>
                                <div class="form-group col-md-6" id="form_data_div1" style="display:none1;">
                                    <input type="submit" class="submit-btn contact-form-submit text-center" style="color:#fff!important; height: 46px !important;border-radius: 35px !important;" name="btnSubmit" id="btnSubmit" value="Submit">
                                </div>
                                <span id="loader"></span>
                                <br>
                            </div>
                        </div>
                         <input type="hidden" name="utm_campaign" id="utm_campaign" value="" >
						<input type="hidden" name="utm_content" id="utm_content" value="" >
						<input type="hidden" name="SourceIPAddress" id="SourceIPAddress" value="" >
                        <input type="hidden" name="utm_medium" id="utm_medium" value="" >
                        <input type="hidden" name="SourceReferrerURL" id="SourceReferrerURL" value="" >
                        <input type="hidden" name="utm_keyword" id="utm_keyword" value="" >
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--<button class="round-button" type="button" data-toggle="modal" data-target="#mymodal">Apply <br>Now</button>-->

    <script
      type="text/javascript"
      src="https://lsqbot.converse.leadsquared.com/bot-script.js"
    ></script>
<!--LSQ Chatbot-->
<iframe style="bottom: 15px; right: 10px;     height: 400px;" id="lsq-chatbot" src="https://botweb.converse.leadsquared.com/?botId=786&tenantId=67907&type=WEB&channelId=e534fb4d-4ba5-4499-b215-b31278386607"></iframe>

    
</body>
</html>


     <!-- JQUERY LIBRARY -->
    <script type="text/javascript" src="CDNFILESjs/jquery.min.js"></script>
    <!-- BOOTSTRAP -->
    <script type="text/javascript" src="CDNFILESjs/bootstrap.min.js"></script>
    
    
    <!-- SUBSCRIBE MAILCHIMP -->
    <script type="text/javascript" src="CDNFILESjs/subscribe_validate.js"></script>

    <!-- VALIDATION  -->
    <script type="text/javascript" src="CDNFILESjs/jquery.validate.min.js"></script>
    <!-- PHONE_NUMBER VALIDATION JS -->
    <script type="text/javascript" src="CDNFILESjs/phone_number.js"></script>

    <!-- STYLE SWITCHER JS -->
    <script type="text/javascript" src="CDNFILESjs/jquery-template.js"></script>
    <script type="text/javascript" src="CDNFILESjs/settings.js"></script>

    <!-- THEME JS -->
    <script type="text/javascript" src="CDNFILESjs/custom.js"></script>
    
      <!-- THEME JS -->
    <script type="text/javascript" src="CDNFILESjs/lozad.min.js"></script>
	
	<script type="text/javascript" src="CDNFILESjs/additional-methods.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
  $(document).ready(function () {
    $('.faq-header').click(function () {
      var content = $(this).next('.faq-content');
      var icon = $(this).find('.faq-icon');
      if (content.is(':visible')) {
        content.slideUp();
        icon.text('+');
      } else {
        $('.faq-content').slideUp();
        $('.faq-icon').text('+');
        content.slideDown();
        icon.text('-');
      }
    });
  });
</script>




<script>

jQuery(document).ready(function() { 
   
   var val="false";
     jQuery(window).scroll(function() {
          
     var winheight = jQuery(window).height();
     var docheight = jQuery(document).height();
     var scrollTop = jQuery(window).scrollTop();
     var trackLength = docheight - winheight;
     var pctScrolled = Math.floor(scrollTop/trackLength * 100); // gets percentage scrolled 
       
       if(val=="false"){
        if (pctScrolled >= '50') {
            
       val="true";
    /*    jQuery('#exampleModal1').popmake('open'); in the 'put enquire now or other heading you want to put'*/
    document.getElementById('heading').innerHTML='';
       
        jQuery('#exampleModal1').modal('show');
         document.getElementById('entryform').value="Half Scroll Popup";
      jQuery('-webkit-scrollbar').hide();

       }else{
     }}
    });
 });

</script>

<script>
jQuery( document ).ready(function() {
 
 const mediaQuery = window.matchMedia('(min-width: 768px)');
  if (mediaQuery.matches) {
  var $sticky = $('.sticky');
  var $stickyrStopper = $('.sticky-stopper');
  if (!!$sticky.offset()) { // make sure ".sticky" element exists

    var generalSidebarHeight = $sticky.innerHeight();
    var stickyTop = $sticky.offset().top;
    var stickOffset = 0;
    var stickyStopperPosition = $stickyrStopper.offset().top;
    var stopPoint = stickyStopperPosition - generalSidebarHeight - stickOffset;
    var diff = stopPoint + stickOffset;

    $(window).scroll(function(){ // scroll event
      var windowTop = $(window).scrollTop(); // returns number

      if (stopPoint < windowTop) {
          $sticky.css({ position: 'absolute', top: diff, right: '30px' });
      } else if (stickyTop < windowTop+stickOffset) {
          $sticky.css({ position: 'fixed', top: stickOffset, right: '30px' });
      } else {
          $sticky.css({position: 'absolute', top: 'initial', right: '30px'  });
      }
    });

  }
  }
});
</script>
<script>
 jQuery("button#download").on("click", function() {
     let id = $(this).attr('data-id');
     
        document.getElementById('heading').innerHTML=id;
        document.getElementById('entryform').value=id;
  });
  jQuery("button#enquire").on("click", function() {
     let id = $(this).attr('data-id');
    
        document.getElementById('heading').innerHTML=id;
        document.getElementById('entryform').value=id;
  });
  jQuery("button#gfc").on("click", function() {
     let id = $(this).attr('data-id');
    
        document.getElementById('heading').innerHTML=id;
        document.getElementById('entryform').value=id;
  });
   jQuery("#lp-enquire-sticky-button").on("click", function() {
       
     let id = $(this).attr('data-id');
    
        document.getElementById('heading').innerHTML=id;
        document.getElementById('entryform').value=id;
  });
  
</script>

<script>
jQuery(document).ready(function() {

	 var $ = jQuery;
	 jQuery.validator.addMethod('onecheck', function(value, ele) {
            return $("input:checked").length >= 1;
        }, 'Please Select Atleast One CheckBox')
  
    var form = $("#frmid");
    form.validate({
        errorClass: 'error-view',
        validClass: 'success-view',
        errorElement: 'span',
        rules: {
            fname: {
                required: true,
                maxlength: 100
            },
			lname: {
                required: true,
                maxlength: 100
            },
            phoneno: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 10
            },
			 email: {
                required: true,
                maxlength: 255
            },
			city: {
                required: true
            },
			mx_Interested_In_Speclization: {
                required: true
            },
			university: {
                required: true
            },
			tnc: "required"
            
        },
        messages: {
            fname: {
                required: 'Please enter first name',
                maxlength: 'Enter max 100 letters'
            },
			lname: {
                required: 'Please enter last name',
                maxlength: 'Enter max 100 letters'
            },
            phoneno: {
                required: 'Please enter mobile no',
                digits: 'Incorrect mobile format',
                maxlength: 'Enter valid mobile digit'
            },
			email: {
                required: 'Please enter email',
                maxlength: 'Enter max 255 letters'
            },
			city: {
                required: 'Please enter city'
            },
			mx_Interested_In_Speclization: {
                required: 'Please select program'
            },
			university: {
                required: 'Please select university'
            },
			
            tnc: "Please accept our policy",
            
        },
        submitHandler: function(form) { 
		     //$("#loader").html('<img src="images/loading.gif"> Loading...');
			// $(':input[type="submit"]').prop('disabled', true);
            var mob = $("#phoneno").val();
			var keyVals = { otpMob : mob}
            var saveData = $.ajax({
				  type: 'POST',
				  url: "api_msg.php",
				  data: keyVals,
				  dataType: "text",
				  success: function(resultData) { 
						//alert(resultData);
                        if(resultData==1){						
							$("#verify_id").show();
							$("#sendotp").hide();
						}else{
							alert('There is some technical issue');
						}
				  }
			});

			 
			 
			 //$("#frmid").submit();
            //return false;
        },
        highlight: function(element, errorClass, validClass) {
            $(element).closest('.input').removeClass(validClass).addClass(errorClass);
            if ($(element).is(':checkbox') || $(element).is(':radio')) {
                $(element).closest('.check').removeClass(validClass).addClass(errorClass);
            }
        },
        unhighlight: function(element, errorClass, validClass) {
            $(element).closest('.input').removeClass(errorClass).addClass(validClass);
            if ($(element).is(':checkbox') || $(element).is(':radio')) {
                $(element).closest('.check').removeClass(errorClass).addClass(validClass);
            }
        },
        errorPlacement: function(error, element) {
            if ($(element).is(':checkbox') || $(element).is(':radio')) {
                $(element).closest('.check').append(error);
            } else {
                $(element).closest('.unit').append(error);
            }
        }
    });	

});	




$("#btnVerifyPhone").click(function (e) {
	    e.preventDefault();
		
		var verifyOtp = $("#verify_otp").val();
		var fname      = $("#fname").val();
// 		var lname      = $("#lname").val();
		var email      = $("#email").val();
		var city       = $("#city").val();
// 		var mx_Interested_in_Specialization  = $("#mx_Interested_in_Specialization").val();
// 		var mx_Course_interested_In     = $("#mx_Course_interested_In").val();
// 		var mx_Budget_for_Course   =$("#mx_Budget_for_Course").val();
		var university = $("#university").val();
		var mx_Whatsapp_Number = $("#mx_Whatsapp_Number").val();
		var phoneNo    = $("#phoneno").val();
		
		var utm_campaign       = $('input[name=utm_campaign]').val();
		var utm_content        = $('input[name=utm_content]').val();
		var SourceIPAddress      = $('input[name=SourceIPAddress]').val();
		var utm_medium           = $('input[name=utm_medium]').val();
		var SourceReferrerURL    = $('input[name=SourceReferrerURL]').val();
		var utm_keyword          = $('input[name=utm_keyword]').val();
		
		if(verifyOtp==''){
		 alert('Please enter otp');
		 return false;
		}
        //alert('asdsa==='+verifyOtp);
		
		
		 $.ajax({
			type: "POST",
			url: "lp-verify_mob.php", 
			data: { fname      : fname, 
			     //   lname      : lname,
			        email      : email,
			        city       : city,
			     //   mx_Interested_in_Specialization : mx_Interested_in_Specialization,
			     //   mx_Course_interested_In : mx_Course_interested_In,
			     //   mx_Budget_for_Course : mx_Budget_for_Course,
			        university : university,
			        mx_Whatsapp_Number : mx_Whatsapp_Number,
			        otpText    : verifyOtp,
			        phoneNo    : phoneNo,
			        utm_campaign       : utm_campaign,
			        utm_content        : utm_content,
			        SourceIPAddress    : SourceIPAddress,
			        utm_medium         : utm_medium,
			        utm_keyword        : utm_keyword,
			        SourceReferrerURL  : SourceReferrerURL
					},
			success: function(data){
				//alert("HI" +data);
				if(data==1){
				
				//$("#form_data_div").show();
				$("#sendotp_div").hide();
				$("#sendotp").hide();
				
				location.href = "lp-verify_mob.php";
				//$('#frmid').submit();
				}
				return false;
			}
			});	
		
		return false;
});	
		
</script>
<script type="text/javascript">
    $(document).ready(function(){

      /*console.log("Reload fired " + idx);
var MAX_RETRIES = 100;
var glob = true;

$.each($("img"), function(index, value){

    if ( this.naturalWidth == 0)
    {
        $(this).attr("src", $(this).attr("src"));
        console.log( $(this).attr('src'));
        glob = false;
    }
} );

if ( !glob && no_of_try < MAX_RETRIES )
    setTimeout(function(){ reload_img(idx + 1, no_of_try + 1); }, 1500); */
    
    $.getScript("https://lsqbot.converse.leadsquared.com/bot-script.js");     
   
});

</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Modal -->
    <div class="modal" id="mymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content" style="margin: 0px 90px 0 70px;">
                <div class="modal-header">
                    <img src="images/main site logo.png" height="50px" width="auto" alt="distance-mba">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="contact-div header-contact-form header-contact-bg padding-top-xs" id="get_free_counselling">
                        <form class="contact-form1" method="POST" action="lp-verify_mob.php" name="frmid" enctype="multipart/form-data" onsubmit="return validateForm();">
                            <input type="hidden" name="pageurl" id="pageurl" value='https://distancemba.co.in/online-mba/index.php'>
                            <input type="hidden" name="entryform" id="entryform" value>
                            <div class="clearfix">
                                <div class="header-contact-bg-pad"><br>
                                    <h3 id="heading" class="text-left" style="padding-left:16px;text-align: center;"></h3>
                                    <br>
                                    <div class="form-row">
                                        <div class="form-group col-md-12 col-12 unit">
                                            <input style="border-radius:10px!important; width: 100%;" class="form-control" type="text" name="fname" id="fname" placeholder="Full Name*" required>
                                            <span class="errormsg" id="errname"></span>
                                        </div>
                                    </div>
                                    <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                        <div class="form-group col-md-12 col-12 unit">
                                            <input style="border-radius:10px!important;" class="form-control form-text phoneno" name="phoneno" id="phoneno" placeholder="Mobile Number*" autocomplete="off" type="text" maxlength="10" onkeydown="return valid_entry_num(event.key)" required>
                                            <span class="errormsg" id="errp"></span>
                                        </div>
                                    </div>
                                    <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                        <div class="form-group col-md-12 col-12 unit">
                                            <input style="border-radius:10px!important; width: 100%;" class="form-control form-text" type="email" name="email" id="email" placeholder="Email*" required >
                                            <span class="errormsg" id="erre"></span>
                                        </div>
                                        <div class="form-group col-md-12 unit">
                                            <input style="border-radius:10px!important; width: 100%;" class="form-control form-text" type="text" name="city" id="city" placeholder="City*" onkeydown="return valid_entry_char(event.key)" required>
                                            <span class="errormsg" id="errc"></span>
                                        </div>
                                    </div>
                                    <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                        <select style="border-radius: 10px !important; margin: 6px -16px; width: 107%;" class="form-control selectcls" name="university" id="university" required>
                                            <option value="">Select University</option>
                                            <option value="Amity University">Amity University</option>
                                            <option value="Manipal University">Manipal University</option>
                                            <option value="O.P. Jindal Global University">O.P. Jindal Global University</option>
                                            <option value="Jain University">Jain University</option>
                                            <option value="Dr. DY. Patil Vidyapeeth University">Dr. DY. Patil Vidyapeeth University</option>
                                            <option value="Lovely Professional University">Lovely Professional University</option>
                                            <option value="Uttaranchal University">Uttaranchal University</option>
                                            <option value="Symbiosis Centre of Distance Learning (SCDL)">Symbiosis Centre of Distance Learning (SCDL)</option>
                                            <option value="Institute of Management Technology, Ghaziabad">Institute of Management Technology, Ghaziabad (IMT)</option>
                                            <option value="Sharda University">Sharda University</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>
                                    <div style="display:none;">
                                        <label for="honeypot">Leave this field blank:</label>
                                        <input type="text" id="honeypot" name="honeypot">
                                    </div>
                                    <div class="form-div phoneno-bottom error-div unit">
                                        <input class="header-contact-form" type="checkbox" name="tnc" id="tnc" checked="checked"> I agree to get updates from counsellor
                                    </div>
                                    <div class="left form-error-top"> 
                                        <span class="form-success sucessMessage"></span>
                                        <span class="form-failure failMessage"></span>
                                    </div>
                                    <div class="form-group col-md-6" id="form_data_div1" style="display:none1;">
                                        <input type="submit" class="submit-btn contact-form-submit text-center" style="color:#fff!important; height: 46px !important;border-radius: 35px !important;" name="btnSubmit" id="btnSubmit" value="Submit">
                                    </div>
                                    <span id="loader"></span>
                                    <br>
                                </div>
                            </div>
                             <input type="hidden" name="utm_campaign" id="utm_campaign" value="" >
							<input type="hidden" name="utm_content" id="utm_content" value="" >
							<input type="hidden" name="SourceIPAddress" id="SourceIPAddress" value="" >
                            <input type="hidden" name="utm_medium" id="utm_medium" value="" >
                            <input type="hidden" name="SourceReferrerURL" id="SourceReferrerURL" value="" >
                            <input type="hidden" name="utm_keyword" id="utm_keyword" value="" >
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script>
        $(document).ready(function(){
            setTimeout(function(){
                $('#mymodal').modal('show');
            }, 60000);
        });
    </script>


<script>
$(document).ready(function(){
   $('#enquire').click(function(){
      $('#mymodel').show(); 
   }); 
   
   $('#enquire1').click(function(){
      $('#mymodel').show(); 
   });
   
   $('#gfc').click(function(){
      $('#mymodel').show(); 
   });
   
   $('#enquire3').click(function(){
      $('#mymodel').show(); 
   });
   
  // Add click event listener to close button inside the modal
   $('.close').click(function(){
      $('#mymodel').hide(); 
   });
});
</script>


<script>
$(document).ready(function()
{
    $('.rahul').click(function(){
     $('#mymodel').show(); 
    });
     $('.abhi').click(function(){
     $('#mymodel').show(); 
    });
    
});
</script>









</script>