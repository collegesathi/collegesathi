<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v19.3 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - distancemba.co.in</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - distancemba.co.in" />
	<meta property="og:site_name" content="distancemba.co.in" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://distancemba.co.in/#organization","name":"Distance MBA College","url":"https://distancemba.co.in/","sameAs":[],"logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://distancemba.co.in/#/schema/logo/image/","url":"https://distancembacollege.com/wp-content/uploads/2022/07/Logo-1.png","contentUrl":"https://distancembacollege.com/wp-content/uploads/2022/07/Logo-1.png","width":500,"height":111,"caption":"Distance MBA College"},"image":{"@id":"https://distancemba.co.in/#/schema/logo/image/"}},{"@type":"WebSite","@id":"https://distancemba.co.in/#website","url":"https://distancemba.co.in/","name":"distancemba.co.in","description":"Advance Your Career from Anywhere","publisher":{"@id":"https://distancemba.co.in/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://distancemba.co.in/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel="alternate" type="application/rss+xml" title="distancemba.co.in &raquo; Feed" href="https://distancemba.co.in/feed/" />
<link rel="alternate" type="application/rss+xml" title="distancemba.co.in &raquo; Comments Feed" href="https://distancemba.co.in/comments/feed/" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
<meta name="theme-color" content="#f5f5f5">
<meta property="og:title" content="Page not found - distancemba.co.in">
<meta property="og:url" content="https://distancemba.co.in/online-mba/CDNFILESjs/settings.js">
<meta property="og:locale" content="en_US">
<meta property="og:site_name" content="distancemba.co.in">
<meta property="og:type" content="website">
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/distancemba.co.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.6.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<link rel='stylesheet' id='us-theme-css' href='https://distancemba.co.in/wp-content/uploads/us-assets/distancemba.co.in.css?ver=835b6314' media='all' />
<link rel='stylesheet' id='theme-style-css' href='https://distancemba.co.in/wp-content/themes/Impreza-child/style.css?ver=8.8.2' media='all' />
<!--n2css--><link rel="https://api.w.org/" href="https://distancemba.co.in/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://distancemba.co.in/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.6.1" />
		<script>
			if ( ! /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test( navigator.userAgent ) ) {
				var root = document.getElementsByTagName( 'html' )[ 0 ]
				root.className += " no-touch";
			}
		</script>
		<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="icon" href="https://distancemba.co.in/wp-content/uploads/2024/05/fav-150x150.png" sizes="32x32" />
<link rel="icon" href="https://distancemba.co.in/wp-content/uploads/2024/05/fav.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://distancemba.co.in/wp-content/uploads/2024/05/fav.png" />
<meta name="msapplication-TileImage" content="https://distancemba.co.in/wp-content/uploads/2024/05/fav.png" />
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>		<style id="us-icon-fonts">@font-face{font-display:block;font-style:normal;font-family:"fontawesome";font-weight:900;src:url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-solid-900.woff2?ver=8.8.2") format("woff2"),url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-solid-900.woff?ver=8.8.2") format("woff")}.fas{font-family:"fontawesome";font-weight:900}@font-face{font-display:block;font-style:normal;font-family:"fontawesome";font-weight:400;src:url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-regular-400.woff2?ver=8.8.2") format("woff2"),url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-regular-400.woff?ver=8.8.2") format("woff")}.far{font-family:"fontawesome";font-weight:400}@font-face{font-display:block;font-style:normal;font-family:"fontawesome";font-weight:300;src:url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-light-300.woff2?ver=8.8.2") format("woff2"),url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-light-300.woff?ver=8.8.2") format("woff")}.fal{font-family:"fontawesome";font-weight:300}@font-face{font-display:block;font-style:normal;font-family:"Font Awesome 5 Duotone";font-weight:900;src:url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-duotone-900.woff2?ver=8.8.2") format("woff2"),url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-duotone-900.woff?ver=8.8.2") format("woff")}.fad{font-family:"Font Awesome 5 Duotone";font-weight:900}.fad{position:relative}.fad:before{position:absolute}.fad:after{opacity:0.4}@font-face{font-display:block;font-style:normal;font-family:"Font Awesome 5 Brands";font-weight:400;src:url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-brands-400.woff2?ver=8.8.2") format("woff2"),url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/fa-brands-400.woff?ver=8.8.2") format("woff")}.fab{font-family:"Font Awesome 5 Brands";font-weight:400}@font-face{font-display:block;font-style:normal;font-family:"Material Icons";font-weight:400;src:url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/material-icons.woff2?ver=8.8.2") format("woff2"),url("https://distancemba.co.in/wp-content/themes/Impreza/fonts/material-icons.woff?ver=8.8.2") format("woff")}.material-icons{font-family:"Material Icons";font-weight:400}</style>
				<style id="us-header-css"> .l-subheader.at_middle,.l-subheader.at_middle .w-dropdown-list,.l-subheader.at_middle .type_mobile .w-nav-list.level_1{background:var(--color-header-middle-bg);color:var(--color-header-middle-text)}.no-touch .l-subheader.at_middle a:hover,.no-touch .l-header.bg_transparent .l-subheader.at_middle .w-dropdown.opened a:hover{color:var(--color-header-middle-text-hover)}.l-header.bg_transparent:not(.sticky) .l-subheader.at_middle{background:var(--color-header-transparent-bg);color:var(--color-header-transparent-text)}.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-cart-link:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-text a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-html a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-nav>a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-menu a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-search>a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .w-dropdown a:hover,.no-touch .l-header.bg_transparent:not(.sticky) .at_middle .type_desktop .menu-item.level_1:hover>a{color:var(--color-header-transparent-text-hover)}.header_ver .l-header{background:var(--color-header-middle-bg);color:var(--color-header-middle-text)}@media (min-width:1281px){.hidden_for_default{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:0.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.header_hor .l-header.sticky_auto_hide{transition:transform 0.3s cubic-bezier(.78,.13,.15,.86) 0.1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:80px;--header-sticky-height:50px}.l-header:before{content:'80'}.l-header.sticky:before{content:'50'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:0px;height:0px;overflow:hidden}.l-subheader.at_middle{line-height:80px;height:80px}.l-header.sticky .l-subheader.at_middle{line-height:50px;height:50px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}.headerinpos_above .l-header.pos_fixed{overflow:hidden;transition:transform 0.3s;transform:translate3d(0,-100%,0)}.headerinpos_above .l-header.pos_fixed.sticky{overflow:visible;transform:none}.headerinpos_above .l-header.pos_fixed~.l-section>.l-section-h,.headerinpos_above .l-header.pos_fixed~.l-main .l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed:not(.sticky){position:absolute;top:100%}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:100vh}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:nth-of-type(2)>.l-section-h{padding-top:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky){position:absolute;top:100vh}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-bottom:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed.bg_transparent~.l-main .l-section.valign_center:not(.height_auto):first-of-type>.l-section-h{top:calc( var(--header-height) / 2 )}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-cart-dropdown,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_2{bottom:100%;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_mobile.m_layout_dropdown .w-nav-list.level_1{top:auto;bottom:100%;box-shadow:var(--box-shadow-up)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_3,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_4{top:auto;bottom:0;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-dropdown-list{top:auto;bottom:-0.4em;padding-top:0.4em;padding-bottom:2.4em}.admin-bar .l-header.pos_static.bg_solid~.l-main .l-section.full_height:first-of-type{min-height:calc( 100vh - var(--header-height) - 32px )}.admin-bar .l-header.pos_fixed:not(.sticky_auto_hide)~.l-main .l-section.full_height:not(:first-of-type){min-height:calc( 100vh - var(--header-sticky-height) - 32px )}.admin-bar.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:calc(100vh - 32px)}}@media (min-width:1025px) and (max-width:1280px){.hidden_for_default{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:0.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.header_hor .l-header.sticky_auto_hide{transition:transform 0.3s cubic-bezier(.78,.13,.15,.86) 0.1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:80px;--header-sticky-height:50px}.l-header:before{content:'80'}.l-header.sticky:before{content:'50'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:0px;height:0px;overflow:hidden}.l-subheader.at_middle{line-height:80px;height:80px}.l-header.sticky .l-subheader.at_middle{line-height:50px;height:50px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}.headerinpos_above .l-header.pos_fixed{overflow:hidden;transition:transform 0.3s;transform:translate3d(0,-100%,0)}.headerinpos_above .l-header.pos_fixed.sticky{overflow:visible;transform:none}.headerinpos_above .l-header.pos_fixed~.l-section>.l-section-h,.headerinpos_above .l-header.pos_fixed~.l-main .l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed:not(.sticky){position:absolute;top:100%}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:100vh}.headerinpos_below .l-header.pos_fixed~.l-main>.l-section:nth-of-type(2)>.l-section-h{padding-top:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky){position:absolute;top:100vh}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-top:0!important}.headerinpos_bottom .l-header.pos_fixed~.l-main>.l-section:first-of-type>.l-section-h{padding-bottom:var(--header-height)}.headerinpos_bottom .l-header.pos_fixed.bg_transparent~.l-main .l-section.valign_center:not(.height_auto):first-of-type>.l-section-h{top:calc( var(--header-height) / 2 )}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-cart-dropdown,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_2{bottom:100%;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_mobile.m_layout_dropdown .w-nav-list.level_1{top:auto;bottom:100%;box-shadow:var(--box-shadow-up)}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_3,.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-nav.type_desktop .w-nav-list.level_4{top:auto;bottom:0;transform-origin:0 100%}.headerinpos_bottom .l-header.pos_fixed:not(.sticky) .w-dropdown-list{top:auto;bottom:-0.4em;padding-top:0.4em;padding-bottom:2.4em}.admin-bar .l-header.pos_static.bg_solid~.l-main .l-section.full_height:first-of-type{min-height:calc( 100vh - var(--header-height) - 32px )}.admin-bar .l-header.pos_fixed:not(.sticky_auto_hide)~.l-main .l-section.full_height:not(:first-of-type){min-height:calc( 100vh - var(--header-sticky-height) - 32px )}.admin-bar.headerinpos_below .l-header.pos_fixed~.l-main .l-section.full_height:nth-of-type(2){min-height:calc(100vh - 32px)}}@media (min-width:601px) and (max-width:1024px){.hidden_for_default{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:0.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.header_hor .l-header.sticky_auto_hide{transition:transform 0.3s cubic-bezier(.78,.13,.15,.86) 0.1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:80px;--header-sticky-height:50px}.l-header:before{content:'80'}.l-header.sticky:before{content:'50'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:0px;height:0px;overflow:hidden}.l-subheader.at_middle{line-height:80px;height:80px}.l-header.sticky .l-subheader.at_middle{line-height:50px;height:50px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}}@media (max-width:600px){.hidden_for_default{display:none!important}.l-subheader.at_top{display:none}.l-subheader.at_bottom{display:none}.l-header{position:relative;z-index:111;width:100%}.l-subheader{margin:0 auto}.l-subheader.width_full{padding-left:1.5rem;padding-right:1.5rem}.l-subheader-h{display:flex;align-items:center;position:relative;margin:0 auto;height:inherit}.w-header-show{display:none}.l-header.pos_fixed{position:fixed;left:0}.l-header.pos_fixed:not(.notransition) .l-subheader{transition-property:transform,background,box-shadow,line-height,height;transition-duration:0.3s;transition-timing-function:cubic-bezier(.78,.13,.15,.86)}.header_hor .l-header.sticky_auto_hide{transition:transform 0.3s cubic-bezier(.78,.13,.15,.86) 0.1s}.header_hor .l-header.sticky_auto_hide.down{transform:translateY(-110%)}.l-header.bg_transparent:not(.sticky) .l-subheader{box-shadow:none!important;background:none}.l-header.bg_transparent~.l-main .l-section.width_full.height_auto:first-of-type>.l-section-h{padding-top:0!important;padding-bottom:0!important}.l-header.pos_static.bg_transparent{position:absolute;left:0}.l-subheader.width_full .l-subheader-h{max-width:none!important}.l-header.shadow_thin .l-subheader.at_middle,.l-header.shadow_thin .l-subheader.at_bottom{box-shadow:0 1px 0 rgba(0,0,0,0.08)}.l-header.shadow_wide .l-subheader.at_middle,.l-header.shadow_wide .l-subheader.at_bottom{box-shadow:0 3px 5px -1px rgba(0,0,0,0.1),0 2px 1px -1px rgba(0,0,0,0.05)}.header_hor .l-subheader-cell>.w-cart{margin-left:0;margin-right:0}:root{--header-height:60px;--header-sticky-height:60px}.l-header:before{content:'60'}.l-header.sticky:before{content:'60'}.l-subheader.at_top{line-height:40px;height:40px}.l-header.sticky .l-subheader.at_top{line-height:0px;height:0px;overflow:hidden}.l-subheader.at_middle{line-height:60px;height:60px}.l-header.sticky .l-subheader.at_middle{line-height:60px;height:60px}.l-subheader.at_bottom{line-height:50px;height:50px}.l-header.sticky .l-subheader.at_bottom{line-height:50px;height:50px}}@media (min-width:1281px){.ush_image_1{height:50px!important}.l-header.sticky .ush_image_1{height:40px!important}}@media (min-width:1025px) and (max-width:1280px){.ush_image_1{height:50px!important}.l-header.sticky .ush_image_1{height:40px!important}}@media (min-width:601px) and (max-width:1024px){.ush_image_1{height:50px!important}.l-header.sticky .ush_image_1{height:40px!important}}@media (max-width:600px){.ush_image_1{height:50px!important}.l-header.sticky .ush_image_1{height:40px!important}}.ush_socials_1 .w-socials-list{margin:-0em}.ush_socials_1 .w-socials-item{padding:0em}</style>
		<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11110381042"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11110381042');
</script></head>
<body class="error404 l-body Impreza_8.8.2 us-core_8.8.2 header_hor headerinpos_top state_default wpb-js-composer js-comp-ver-6.9.0 vc_responsive" itemscope itemtype="https://schema.org/WebPage">

<div class="l-canvas type_wide">
	<header id="page-header" class="l-header pos_fixed shadow_thin bg_solid id_5932" itemscope itemtype="https://schema.org/WPHeader"><div class="l-subheader at_top"><div class="l-subheader-h"><div class="l-subheader-cell at_left"><div class="w-text ush_text_2 nowrap icon_atleft"><a href="tel:+91 8669661004" class="w-text-h"><i class="fas fa-phone"></i><span class="w-text-value">+91 8669661004</span></a></div><div class="w-text ush_text_3 nowrap icon_atleft"><a href="mailto:info@distancemba.co.in" class="w-text-h"><i class="fas fa-envelope"></i><span class="w-text-value">info@distancemba.co.in</span></a></div></div><div class="l-subheader-cell at_center"></div><div class="l-subheader-cell at_right"><div class="w-socials hide-for-sticky hide-for-not-sticky ush_socials_1 color_brand shape_square style_default hover_fade"><div class="w-socials-list"><div class="w-socials-item facebook"><a class="w-socials-item-link" href="#" target="_blank" rel="noopener nofollow" title="Facebook" aria-label="Facebook"><span class="w-socials-item-link-hover"></span><i class="fab fa-facebook"></i></a></div><div class="w-socials-item twitter"><a class="w-socials-item-link" href="#" target="_blank" rel="noopener nofollow" title="Twitter" aria-label="Twitter"><span class="w-socials-item-link-hover"></span><i class="fab fa-twitter"></i></a></div><div class="w-socials-item google"><a class="w-socials-item-link" href="#" target="_blank" rel="noopener nofollow" title="Google" aria-label="Google"><span class="w-socials-item-link-hover"></span><i class="fab fa-google"></i></a></div><div class="w-socials-item linkedin"><a class="w-socials-item-link" href="#" target="_blank" rel="noopener nofollow" title="LinkedIn" aria-label="LinkedIn"><span class="w-socials-item-link-hover"></span><i class="fab fa-linkedin"></i></a></div><div class="w-socials-item youtube"><a class="w-socials-item-link" href="#" target="_blank" rel="noopener nofollow" title="YouTube" aria-label="YouTube"><span class="w-socials-item-link-hover"></span><i class="fab fa-youtube"></i></a></div></div></div></div></div></div><div class="l-subheader at_middle"><div class="l-subheader-h"><div class="l-subheader-cell at_left"><div class="w-image ush_image_1"><a href="https://distancemba.co.in/" aria-label="Link" class="w-image-h"><img width="578" height="169" src="https://distancemba.co.in/wp-content/uploads/2024/05/web-logo.png" class="attachment-full size-full" alt="" decoding="async" fetchpriority="high" srcset="https://distancemba.co.in/wp-content/uploads/2024/05/web-logo.png 578w, https://distancemba.co.in/wp-content/uploads/2024/05/web-logo-300x88.png 300w, https://distancemba.co.in/wp-content/uploads/2024/05/web-logo-400x117.png 400w" sizes="(max-width: 578px) 100vw, 578px" /></a></div></div><div class="l-subheader-cell at_center"></div><div class="l-subheader-cell at_right"><button class="w-btn us-btn-style_15 ush_btn_1 custom_form_click"><span class="w-btn-label">Get Free Counceling</span></button></div></div></div><div class="l-subheader for_hidden hidden"></div></header>	<main id="page-content" class="l-main" itemprop="mainContentOfPage">

		<section class="l-section wpb_row height_medium full_height valign_center"><div class="l-section-h i-cf"><div class="g-cols vc_row via_grid cols_1 laptops-cols_inherit tablets-cols_inherit mobiles-cols_1 valign_middle type_default stacking_default"><div class="wpb_column vc_column_container"><div class="vc_column-inner"><div class="w-iconbox iconpos_top style_circle color_custom align_center no_text"><div class="w-iconbox-icon" style="font-size:6rem;background:#f6a438;color:#023356;"><i class="far fa-map-marked-alt"></i></div><div class="w-iconbox-meta"><h2 class="w-iconbox-title">This is “404 error” page</h2></div></div><div class="w-separator size_small"></div><div class="w-btn-wrapper align_center"><a class="w-btn us-btn-style_18 icon_atleft" href="https://distancemba.co.in/"><i class="material-icons">home</i><span class="w-btn-label">Home Page</span></a></div></div></div></div></div></section>

	</main>
	<html>
<style>
#mySizeChartModal input:not([type="submit"]), #mySizeChartModal textarea, #mySizeChartModal select,
.mySizeChartModal1 input:not([type="submit"]), .mySizeChartModal1 textarea, .mySizeChartModal1 select{font-size: 14px;
    width: 100%;
    border-radius: 5px;
    margin-bottom: 10px;
    border: 1px solid #999;
    padding: 10px;}
#mySizeChartModal input[type=email], #mySizeChartModal input[type=tel],#mySizeChartModal input[type=number], #mySizeChartModal  input[type=text], #mySizeChartModal  select,
.mySizeChartModal1 input[type=email], .mySizeChartModal1 input[type=tel],.mySizeChartModal1 input[type=number], .mySizeChartModal1  input[type=text], .mySizeChartModal1  select{height:40px;}
.phpbtn{background: #07107a !important;border-radius: 30px!important;}
.phpbtndiv a{background: #2a2a48;text-transform: none;letter-spacing: 1px;border-radius: 50px;padding: 2px 31px;font-family: 'Poppins';font-size: 14px;text-shadow: 0px 0px 2px black !important;text-decoration:none;}
.phpsubmit-btn {
    background-color: #05375b !important;
    border: 0 !important;
    color: #fff !important;
    height: 50px !important;
    font-size: 18px !important;
    font-weight: 700 !important;
    letter-spacing: 1px !important;
    margin-bottom: 0 !important;
    transition: 300ms ease-in !important;
    width: 50%;
}
.submit-btn{ margin-top:10px;}
</style>
<!--<div class="phpbtndiv" style="text-align:center;padding:30px"><a style="color:#fff" class="phpbtn" id="top_enquire"  aria-label="Enquire Now" data-id="Enquire Now" href="#exampleModal1" >Enquire Now</a></div>-->
<style>
@media screen and (max-width: 767px){
    .ebcf_modal-content{width:90%!important;}
}
.errormsg{color:#ff0000;font-weight:bold; font-size:14px;}
.otprow{display:none;}
.error{ text-align: center;
    font-weight: bolder;
    color: #ff0000;}
.success{text-align: center;
    font-weight: bolder;
    color: #008000;}
.ebcf_modal { display: none;   position: fixed;    z-index: 125;     left: 0; top: 0; width: 100%;   height: 100%;    overflow: auto;   background-color: rgb(0,0,0);  background-color: rgba(0,0,0,0.4);  }
.ebcf_modal-content {background-color: #f6faff;margin: 30px auto;padding: 20px;border: 1px solid #888;width: 30%;position:relative;top:10%;    border-radius: 14px;    box-shadow: 0 5px 15px rgba(0,0,0,.5);}
.ebcf_close {color: #aaaaaa;float: right;font-size: 28px;font-weight: bold;}
.ebcf_close:hover,
.ebcf_close:focus {color: #000;text-decoration: none;cursor: pointer;}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">-->
<body>
   <!-- <div class="modal fade" id="exampleModal1" data-backdrop="false" tabindex="-1" role="dialog"  aria-labelledby="exampleModalLabel" aria-hidden="true" style="overflow:auto; background-color: rgba(10,10,10,0.45);">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <a class="popup__close" href="#" data-dismiss="modal" style="font-size: 20px;z-index:9;color:#05375b!important;position: absolute;right: 20px;">X</a>-->
                    <div id="mySizeChartModal" class="ebcf_modal">
                        <div class="ebcf_modal-content">
                            <span id="ebcf_btn_close" class="ebcf_close" >&times;</span>
                        <div class="row">
                            <div class="col-sm-12">
                              
                                         <form class="contact-form1" method="POST"
                                                                action="https://distancemba.co.in/custom-form/modal_save.php" name="frmid"
                                                                enctype="multipart/form-data" onsubmit="return validateForm();">
                                                                <input type="hidden" name="pageurl" id="pageurl">
                                                                <input type="hidden" name="entryform" id="entryform" value="Enquire Now">
                                                                <div class="clearfix">
                                                                    <div class="header-contact-bg-pad">
                                                                        <h3 id="heading" style="text-align:center;margin-bottom:15px;">Enquire Now</h3>
                                                                       
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important; width: 100%;" class="form-control" type="text"
                                                                                    name="fname" id="fname"
                                                                                    placeholder="Full Name*"
                                                                                    required>
                                                                                    <span class="errormsg" id="errname"></span>
                                                                            </div>
                                                                            <!--<div class="form-group col-md-6 col-12 unit">-->
                                                                            <!--    <input style="border-radius:10px!important;" class="form-control" type="text"-->
                                                                            <!--        name="lname" id="lname"-->
                                                                            <!--        placeholder="Last Name*"-->
                                                                            <!--        required>-->
                                                                            <!--</div>-->
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="phoneno" id="phoneno"
                                                                                    placeholder="Mobile Number*"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10" minlength="10"  onkeydown="return valid_entry_num(event.key)" required>
                                                                            <span class="errormsg" id="errp"></span>
                                                                            </div>
                                                                        </div>


                                                                        <div class="form-row form-div form-bottom-1" style="margin-bottom:0px;">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important; width: 100%;" class="form-control form-text"
                                                                                    type="email" name="email" id="email"
                                                                                    placeholder="Email*" required >
                                                                            <span class="errormsg" id="erre"></span>
                                                                            </div>
                                                                            <div class="form-group col-md-12 unit">
                                                                                <input style="border-radius:10px!important; width: 100%;" class="form-control form-text"
                                                                                    type="text" name="city" id="city"
                                                                                    placeholder="City*" onkeydown="return valid_entry_char(event.key)"
                                                                                    required>
                                                                                     <span class="errormsg" id="errc"></span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <!-- <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls" id="mx_Course_interested_In" name="mx_Course_interested_In" onchange="updateSpecialization()">
                                                                                <option value="">Select a Program</option>
                                                                                <option value="MBA">Online MBA</option>
                                                                                <option value="Master">Master Program</option>
                                                                                <option value="Bachelor">Bachelor's</option>
                                                                                <option value="Certificate">Certificate</option>
                                                                                <option value="Executive">Executive MBA</option>
                                                                            </select>
                                                                        </div>
    
                                                                         <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
										                                    <select style="border-radius:10px!important;" class="form-control selectcls" name="mx_Interested_in_Specialization" id="mx_Interested_in_Specialization" required>
                                                                                <option value="">Select a Course</option>
                                                                            </select>
                                                                                <script>
                                                                                    
                                                                                    const specializations = {
                                                                                        "MBA": ["MBA"],
                                                                                        "Master": ["Select a Course", "MA", "M.Com", "MSC", "MCA", "Master of Journalism and Mass Communication (MJMC)"],
                                                                                        "Bachelor" : ["Select a Course", "BA", "B.Com", "BCA", "BBA", "Bachelor of Journalism and Mass Communication (BJMC)"],
                                                                                        "Certificate": ["Select a Course", "Data Analyst", "Digital Marketing", "Hospital & Health Care"],
                                                                                        "Executive" : ["Select a Course", "1 Year Executive MBA", "15 Months Executive MBA"]
                                                                                    };
                                                                            
                                                                                    
                                                                                    function updateSpecialization() {
                                                                                         
                                                                                        const courseSelect = document.getElementById("mx_Course_interested_In");
                                                                                        const selectedCourse = courseSelect.value;
                                                                            
                                                                                        
                                                                                        const specializationSelect = document.getElementById("mx_Interested_in_Specialization");
                                                                            
                                                                                         
                                                                                        specializationSelect.innerHTML = "";
                                                                            
                                                                                         
                                                                                        if (selectedCourse in specializations) {
                                                                                            
                                                                                            specializations[selectedCourse].forEach(function(specialization) {
                                                                                                const option = document.createElement("option");
                                                                                                option.value = specialization;
                                                                                                option.textContent = specialization;
                                                                                                specializationSelect.appendChild(option);
                                                                                            });
                                                                                        }
                                                                                    }
                                                                                </script>
                                                                        </div>-->
                                                                        
                                                                    
                                                                        <div class="col-12 form-group form-div form-bottom-1 form-bottom-2 unit">
                                                                            <select style="border-radius:10px!important;" class="form-control selectcls"
                                                                                name="university" id="university" required>
                                                                                <option value="">Select University
                                                                                </option>
                                                                                
                                                                                <!--Symbiosis-->
                                                                                <option value="Symbiosis University"> 
                                                                                    Symbiosis University
                                                                                </option>
                                                                                
                                                                                <!--Amity-->
                                                                                <option value="Amity University, distance and Distance Learning (ODL)">
                                                                                    Amity University, distance and Distance Learning (ODL)
                                                                                </option>
                                                                                
                                                                                <!--Manipal-->
                                                                                <option value="Manipal University">
                                                                                    Manipal University
                                                                                </option>
                                                                                
                                                                                <!--Dy Patil-->
                                                                                <option value="Dr. D. Y. Patil Vidyapeeth University">
                                                                                    Dr. D. Y. Patil Vidyapeeth University
                                                                                </option>
                                                                                
                                                                                <!--Jain-->
                                                                                <option value="Jain University">
                                                                                    Jain University
                                                                                </option>

                                                                                <!--LPU-->
                                                                                <option value="Lovely Professional University Distance Learning">
                                                                                    Lovely Professional University Distance Learning
                                                                                </option>
                                                                                
                                                                                <!--Utaranchal University-->
                                                                                <option value="Utaranchal University">
                                                                                    Utaranchal University
                                                                                </option>
                                                                                
                                                                                <!--Institute of Management Technology, Ghaziabad-->
                                                                                <option value="Institute of Management Technology, Ghaziabad">
                                                                                    Institute of Management Technology, Ghaziabad (IMT)
                                                                                </option>
                                                                                
                                                                                <!--Chandigarh University-->
                                                                                <option value="Chandigarh University">
                                                                                    Chandigarh University
                                                                                </option>
                                                                                
                                                                                <!--IGNOU-->
                                                                                <option value="Indira Gandhi National Open University (IGNOU)">
                                                                                    Indira Gandhi National Open University (IGNOU)
                                                                                </option>
                                                                                
                                                                                <option value="Others">
                                                                                   Others
                                                                                </option>
                                                                                
                                                                            </select>
                                                                        </div>
                                                                        
                                                                        
                                                                        <!--Whatsapp number-->
                                                                        <div class="form-row form-div form-bottom-1" style="display:none;">
                                                                            <div class="form-group col-md-12 col-12 unit">
                                                                                <input style="border-radius:10px!important;"
                                                                                    class="form-control form-text phoneno"
                                                                                    name="mx_Whatsapp_Number" id="mx_Whatsapp_Number"
                                                                                    placeholder="WhatsApp Number Optional"
                                                                                    autocomplete="off" type="text"
                                                                                    maxlength="10" onkeydown="return valid_entry_numw(event.key)">
                                                                           <span class="errormsg" id="errw"></span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        <div style="display:none;">
                                                                            <label for="honeypot">Leave this field blank:</label>
                                                                            <input type="text" id="honeypot" name="honeypot">
                                                                        </div>



                                                                        <div
                                                                            class="form-div phoneno-bottom error-div unit">
                                                                            <input class="header-contact-form"
                                                                                type="checkbox" name="tnc" id="tnc"
                                                                                checked="checked"> I agree to get updates from counsellor
                                                                        </div>

                                                                        <!--============= SUCESSS AND FAILURE MESSAGE DISPLAY HERE ========-->
                                                                        <div class="left form-error-top"> <span
                                                                                class="form-success sucessMessage">
                                                                            </span>
                                                                            <span class="form-failure failMessage">
                                                                            </span>
                                                                        </div>

                                                                        <div class="form-row form-div form-bottom-1"
                                                                            id="verify_id1" style="display:none11;">
                                                                            <!--  <div class="form-group col-md-6">-->
                                                                            <!-- <input type="text" class="form-control form-text" name="verify_otp" id="verify_otp" placeholder="Verify OTP" autocomplete="off">-->
                                                                            <!--</div> -->
                                                                            <!-- <div class="form-group col-md-6">-->
                                                                            <!-- <input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="btnVerifyPhone" id="btnVerifyPhone" value="Verify OTP">-->
                                                                            <!--</div>-->
                                                                        </div>


                                                                        <!-- <div class="form-group col-md-6" id="sendotp_div">-->
                                                                        <!--<input type="submit" class="submit-btn contact-form-submit" style="color:#fff!important; width:100%; height:30px" name="sendotp" id="sendotp" value="Send OTP">-->
                                                                        <!--</div> -->


                                                                        <div class="form-group col-md-6"
                                                                            id="form_data_div1" style="display:none1;">
                                                                             
                                                                            <input type="submit" class="submit-btn contact-form-submit text-center "
                                                                                style="color:#fff!important; height: 46px !important;border-radius: 35px !important;width:100%;"
                                                                                name="btnSubmit" id="btnSubmit"
                                                                                value="Submit">
                                                                        </div>

                                                                        <span id="loader"></span>
                                                                        <br>
                                                                        <!--<br>-->
                                                                    </div>
                                                                </div>
                                                                 <input type="hidden" name="entryform" id="entryform" value="Enquire Now">
    								 	        <input type="hidden" name="utm_content" id="utm_content" >
                								<input type="hidden" name="utm_medium" id="utm_medium">
                								<input type="hidden" name="utm_campaign" id="utm_campaign">
                								<input type="hidden" name="utm_keyword" id="utm_keyword">

                							
                                                            </form>
                                    </div>
                                </div>
                            </div>
                    </div>
    </body>
</html>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script>
function validateForm() {
jQuery("#btnSubmit").css("pointer-events","none");
 var x=jQuery('#fname').val().trim();
 if(x=="")
 {
  
    jQuery('#errname').text("Enter Valid Name");
    
    jQuery('#fname').focus();
    jQuery("#btnSubmit").css("pointer-events","all");
    return false;
 }
 
 
var x= jQuery('#email').val().trim();

 var validRegex = /\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (validRegex.test(x)) {
  }
  else
  {
     
      jQuery('#erre').text("Enter Valid Email Address");
      jQuery("#btnSubmit").css("pointer-events","all");
       return false;
   
  }
 var x=jQuery('#city').val().trim();
 if(x=="")
 {
    jQuery('#errc').text("Enter Valid City");
    jQuery("#btnSubmit").css("pointer-events","all");
     return false;
    
 }
 
  var x= jQuery('#phoneno').val().trim();
  if (x.length<10) {
      jQuery('#errp').text("Enter Valid Contact Details");
      jQuery("#btnSubmit").css("pointer-events","all");
       return false;
  }
 jQuery("#btnSubmit").css("pointer-events","none");
      return true;
 
}

 

  

</script>
<script>        
 function valid_entry_num(key) {
var plen =jQuery("#phoneno").val();


  if (plen.length <=10)
  {
  return (key >= '0' && key <= '9') || key == '+' ||  key == '-' ||
   key == 'ArrowLeft' || key == 'ArrowRight'  || key == 'Tab' || key == 'Delete' || key == 'Backspace';
  }
  else
    {return false; }
}
 function valid_entry_numw(key) {
 var plen = jQuery("#mx_Whatsapp_Number").val();

 
  if (plen.length <=15)
  {
  return (key >= '0' && key <= '9') || key == '+' ||  key == '-' ||
   key == 'ArrowLeft' || key == 'ArrowRight'  || key == 'Tab' || key == 'Delete' || key == 'Backspace';
  }
  else
    {return false; }
}
function valid_entry_char(key) {
  var plen = document.getElementById("city1");
    return (key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z') || key == ' ' ||
    key == 'ArrowLeft' || key == 'ArrowRight' || key == 'Delete' || key == 'Backspace';

}
</script>
<script>
function validateForm1() {
    jQuery("#btnSubmit1").css("pointer-events","none");
 var x=jQuery('#fname1').val().trim();
 if(x=="")
 {
  
     jQuery('#errname1').text("Enter Valid Name");
     jQuery('#errname1').val="";
     jQuery('#fname1').focus();
         jQuery("#btnSubmit1").css("pointer-events","all");
    return false;
 }
 
 var x= jQuery('#email1').val().trim();

 var validRegex = /\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (validRegex.test(x)) {
  }
  else
  {
     
      jQuery('#erre1').text("Enter Valid Email Address");
             jQuery("#btnSubmit1").css("pointer-events","all");
       return false;
   
  } 
 var x=jQuery('#city1').val().trim();
 if(x=="")
 {
    jQuery('#errc1').text("Enter Valid City");
           jQuery("#btnSubmit1").css("pointer-events","all");
     return false;
    
 }
 
  var x= jQuery('#phoneno1').val().trim();
  if ( (x.length>=10)  &&  (x.length<=15)) {
  }
  else
      {
      jQuery('#errp1').text("Enter Valid Contact Details");
             jQuery("#btnSubmit1").css("pointer-events","all");
       return false;
    
  }
 jQuery("#btnSubmit1").css("pointer-events","none");
      return true;
 
}

 

  

</script>
<script>        
 function valid_entry_num1(key) {

var plen =jQuery("#phoneno1").val();


  if (plen.length <=10)
  {
  return (key >= '0' && key <= '9') || key == '+' ||  key == '-' ||
   key == 'ArrowLeft' || key == 'ArrowRight'  || key == 'Tab' || key == 'Delete' || key == 'Backspace';
  }
  else
    {return false; }
}
 function valid_entry_numw(key) {
 var plen = jQuery("#mx_Whatsapp_Number1").val();

 
  if (plen.length <=15)
  {
  return (key >= '0' && key <= '9') || key == '+' ||  key == '-' ||
   key == 'ArrowLeft' || key == 'ArrowRight'  || key == 'Tab' || key == 'Delete' || key == 'Backspace';
  }
  else
    {return false; }
}
function valid_entry_char(key) {
  var plen = document.getElementById("city1");
    return (key >= 'a' && key <= 'z') || (key >= 'A' && key <= 'Z') || key == ' ' ||
    key == 'ArrowLeft' || key == 'ArrowRight' || key == 'Delete' || key == 'Backspace';

}
</script>
<script>
    // Get the modal
var ebModal = document.getElementById('mySizeChartModal');

// Get the button that opens the modal
/*var ebBtn = document.getElementById("top_enquire");*/

// Get the <span> element that closes the modal
/*var ebSpan = document.getElementById("ebcf_btn_close");*/
jQuery("#ebcf_btn_close").click(function(){
     ebModal.style.display = "none";
});

// When the user clicks the button, open the modal 
/*ebBtn.onclick = function() {
    ebModal.style.display = "block";
}*/

// When the user clicks on <span> (x), close the modal
/*ebSpan.onclick = function() {
    ebModal.style.display = "none";
}*/

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == ebModal) {
        ebModal.style.display = "none";
    }
}
</script>
<script>
function myFunction(event) {
  		const currentlyVisible = document.querySelector('.popup .show');
  		var popup = event.currentTarget.querySelector('.popuptext');
  		if(currentlyVisible!=null) {
   			popup.classList.toggle("show");
  		}
  		else{
  		var popup = event.currentTarget.querySelector('.popuptext');
  		popup.classList.toggle("show");}
		}
if(document.querySelector("#pageurl1")){
var x = window.location.href;
document.getElementById("pageurl1").value = x;
}
</script></div>
	<footer id="page-footer" class="l-footer" itemscope itemtype="https://schema.org/WPFooter">
			</footer>
	<a class="w-toplink pos_right w-btn us-btn-style_28" href="#" title="Back to top" aria-label="Back to top"><span></span></a>	<button id="w-header-show" class="w-header-show" aria-label="Menu"><span>Menu</span></button>
	<div class="w-header-overlay"></div>
		<script>
		// Store some global theme options used in JS
		if ( window.$us === undefined ) {
			window.$us = {};
		}
		$us.canvasOptions = ( $us.canvasOptions || {} );
		$us.canvasOptions.disableEffectsWidth = 900;
		$us.canvasOptions.columnsStackingWidth = 900;
		$us.canvasOptions.backToTopDisplay = 100;
		$us.canvasOptions.scrollDuration = 1000;

		$us.langOptions = ( $us.langOptions || {} );
		$us.langOptions.magnificPopup = ( $us.langOptions.magnificPopup || {} );
		$us.langOptions.magnificPopup.tPrev = 'Previous (Left arrow key)';
		$us.langOptions.magnificPopup.tNext = 'Next (Right arrow key)';
		$us.langOptions.magnificPopup.tCounter = '%curr% of %total%';

		$us.navOptions = ( $us.navOptions || {} );
		$us.navOptions.mobileWidth = 1111;
		$us.navOptions.togglable = true;
		$us.ajaxLoadJs = true;
		$us.templateDirectoryUri = 'https://distancemba.co.in/wp-content/themes/Impreza';
	</script>
	<script>if ( window.$us === undefined ) window.$us = {};$us.headerSettings = {"default":{"options":{"custom_breakpoint":false,"breakpoint":"","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":false,"width":"300px","elm_align":"center","shadow":"thin","top_show":"","top_height":"40px","top_sticky_height":"0px","top_fullwidth":false,"top_centering":false,"top_bg_color":"linear-gradient(45deg,#333233,#023356)","top_text_color":"#ffffff","top_text_hover_color":"#ead1b1","top_transparent_bg_color":"#000000","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"80px","middle_sticky_height":"50px","middle_fullwidth":false,"middle_centering":false,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":true,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":false,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":false,"bottom_centering":false,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":["text:2","text:3"],"top_center":[],"top_right":["socials:1"],"middle_left":["image:1"],"middle_center":[],"middle_right":["btn:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":[]}},"laptops":{"options":{"custom_breakpoint":false,"breakpoint":"1280px","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":false,"width":"300px","elm_align":"center","shadow":"thin","top_show":"","top_height":"40px","top_sticky_height":"0px","top_fullwidth":false,"top_centering":"","top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"80px","middle_sticky_height":"50px","middle_fullwidth":false,"middle_centering":false,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":true,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":false,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":false,"bottom_centering":false,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":["text:2","text:3"],"top_center":[],"top_right":["socials:1"],"middle_left":["image:1"],"middle_center":[],"middle_right":["btn:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":[]}},"tablets":{"options":{"custom_breakpoint":false,"breakpoint":"1024px","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":false,"width":"300px","elm_align":"center","shadow":"thin","top_show":"","top_height":"40px","top_sticky_height":"0px","top_fullwidth":false,"top_centering":false,"top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"80px","middle_sticky_height":"50px","middle_fullwidth":false,"middle_centering":false,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":true,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":false,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":false,"bottom_centering":false,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":["text:2","text:3"],"top_center":[],"top_right":["socials:1"],"middle_left":["image:1"],"middle_center":[],"middle_right":["btn:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":[]}},"mobiles":{"options":{"custom_breakpoint":false,"breakpoint":"600px","orientation":"hor","sticky":true,"sticky_auto_hide":false,"scroll_breakpoint":"1px","transparent":false,"width":"300px","elm_align":"center","shadow":"thin","top_show":false,"top_height":"40px","top_sticky_height":"0px","top_fullwidth":false,"top_centering":false,"top_bg_color":"_header_top_bg","top_text_color":"_header_top_text","top_text_hover_color":"_header_top_text_hover","top_transparent_bg_color":"_header_top_transparent_bg","top_transparent_text_color":"_header_top_transparent_text","top_transparent_text_hover_color":"_header_top_transparent_text_hover","middle_height":"60px","middle_sticky_height":"60px","middle_fullwidth":false,"middle_centering":false,"elm_valign":"top","bg_img":"","bg_img_wrapper_start":"","bg_img_size":"cover","bg_img_repeat":"repeat","bg_img_position":"top left","bg_img_attachment":true,"bg_img_wrapper_end":"","middle_bg_color":"_header_middle_bg","middle_text_color":"_header_middle_text","middle_text_hover_color":"_header_middle_text_hover","middle_transparent_bg_color":"_header_transparent_bg","middle_transparent_text_color":"_header_transparent_text","middle_transparent_text_hover_color":"_header_transparent_text_hover","bottom_show":false,"bottom_height":"50px","bottom_sticky_height":"50px","bottom_fullwidth":false,"bottom_centering":false,"bottom_bg_color":"_header_middle_bg","bottom_text_color":"_header_middle_text","bottom_text_hover_color":"_header_middle_text_hover","bottom_transparent_bg_color":"_header_transparent_bg","bottom_transparent_text_color":"_header_transparent_text","bottom_transparent_text_hover_color":"_header_transparent_text_hover"},"layout":{"top_left":["text:2","text:3"],"top_center":[],"top_right":["socials:1"],"middle_left":["image:1"],"middle_center":[],"middle_right":["btn:1"],"bottom_left":[],"bottom_center":[],"bottom_right":[],"hidden":[]}},"header_id":5932};</script><script src="https://distancemba.co.in/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://distancemba.co.in/wp-content/uploads/us-assets/distancemba.co.in.js?ver=ab4e05d6" id="us-core-js"></script>
</body>
</html>
<script>
jQuery(document).ready(function(){

	

	
	if(jQuery('#pageurl').val()==''){
jQuery('#pageurl').val(document.location.href);}

   
         var val="false";
             jQuery(window).scroll(function() {
                
                   var winheight = jQuery(window).height();
                  var docheight = jQuery(document).height();
                 var scrollTop = jQuery(window).scrollTop();
                 var trackLength = docheight - winheight;
                 var pctScrolled = Math.floor(scrollTop/trackLength * 100); 
              
         var $thankyou = jQuery("body").hasClass("page-id-7899");
				
       if(val=="false" && $thankyou==false ){
                if (pctScrolled == '50') {
                val="true";
                document.getElementById('mySizeChartModal').style.display = "block";
                                      
                    } 
      }
       });
 jQuery(".custom_form_click").click(function(){
  document.getElementById('mySizeChartModal').style.display = "block";
 });
	
	 jQuery(".slider-button.custom_form_click a.n2-ow").click(function(){
  document.getElementById('mySizeChartModal').style.display = "block";
 });
	
 
 jQuery("#ebcf_btn_close").click(function(){
  document.getElementById('mySizeChartModal').style.display = "none";
 });
});
</script>
<script>
jQuery(document).ready(function(){
    function getCookie(cname) {
          let name = cname + "=";
          let decodedCookie = decodeURIComponent(document.cookie);
          let ca = decodedCookie.split(';');
          for(let i = 0; i <ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') {
              c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
              return c.substring(name.length, c.length);
            }
          }
          return "";
        }
 function getParameterByName(name) {
            
            let currenturl = window.location.search;
            currenturl = currenturl.replaceAll('&amp;', '&');
	 currenturl = currenturl.replaceAll('&amp%3B', '&');
            var match = RegExp('[?&]' + name + '=([^&]*)').exec(currenturl);
            return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
        }
         var today = new Date();
         var expiry = new Date(today.getTime() + 30 * 24 * 3600 * 1000); 
        
        function hasQueryParams(url) {
          return url.includes('?');
        }
       
        
        var querystringpresent = hasQueryParams(window.location.href);
        
        if(querystringpresent===true){
			
			
        var content = getParameterByName('SourceContent');
        var medium = getParameterByName('SourceMedium');
        var campaign = getParameterByName('SourceCampaign');
        var keyword = getParameterByName('utm_keyword');
       
          document.cookie= "SourceContent=" +content+" ; path=/; domain=distancemba.co.in; expires=" + expiry.toGMTString();
         document.cookie= "SourceMedium=" +medium+" ; path=/; domain=distancemba.co.in; expires=" + expiry.toGMTString();
         document.cookie= "SourceCampaign=" +campaign+" ; path=/; domain=distancemba.co.in; expires=" + expiry.toGMTString();
         document.cookie= "utm_keyword=" +keyword+" ; path=/; domain=distancemba.co.in; expires=" + expiry.toGMTString();
         
        document.querySelector("input[name='utm_content']").value = getCookie("SourceContent");
        document.querySelector("input[name='utm_medium']").value = getCookie("SourceMedium");
        document.querySelector("input[name='utm_campaign']").value = getCookie("SourceCampaign");
       document.querySelector("input[name='utm_keyword']").value = getCookie("utm_keyword");
        }
        
    });
</script>

