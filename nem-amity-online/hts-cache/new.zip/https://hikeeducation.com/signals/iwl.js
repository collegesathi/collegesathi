<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="facebook-domain-verification" content="6b69rloh1eo3njn4f3ge9pe7fmymim" />
<!-- 	Googke search console -->
<meta name="google-site-verification" content="cN7kSRT9lKOplcqquh8qRJwP7f2pToEjPMxE2rctNV4" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
		<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v23.2 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found -</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found -" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://hikeeducation.com/#website","url":"https://hikeeducation.com/","name":"","description":"Hike Education","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://hikeeducation.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="https://hikeeducation.com/feed/" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="https://hikeeducation.com/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/hikeeducation.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.5"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='premium-addons-css' href='https://hikeeducation.com/wp-content/plugins/premium-addons-for-elementor/assets/frontend/min-css/premium-addons.min.css?ver=4.10.39' type='text/css' media='all' />
<link rel='stylesheet' id='jkit-elements-main-css' href='https://hikeeducation.com/wp-content/plugins/jeg-elementor-kit/assets/css/elements/main.css?ver=2.6.7' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='slick-style-css' href='https://hikeeducation.com/wp-content/plugins/blog-designer-pack/assets/css/slick.css?ver=3.4.7' type='text/css' media='all' />
<link rel='stylesheet' id='bdp-public-style-css' href='https://hikeeducation.com/wp-content/plugins/blog-designer-pack/assets/css/bdp-public.css?ver=3.4.7' type='text/css' media='all' />
<link rel='stylesheet' id='pure-css-css' href='https://hikeeducation.com/wp-content/plugins/cf7-views/assets/css/pure-min.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='pure-grid-css-css' href='https://hikeeducation.com/wp-content/plugins/cf7-views/assets/css/grids-responsive-min.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='cf7-views-front-css' href='https://hikeeducation.com/wp-content/plugins/cf7-views/assets/css/cf7-views-display.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://hikeeducation.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.8' type='text/css' media='all' />
<style id='contact-form-7-inline-css' type='text/css'>
.wpcf7 .wpcf7-recaptcha iframe {margin-bottom: 0;}.wpcf7 .wpcf7-recaptcha[data-align="center"] > div {margin: 0 auto;}.wpcf7 .wpcf7-recaptcha[data-align="right"] > div {margin: 0 0 0 auto;}
</style>
<link rel='stylesheet' id='htbbootstrap-css' href='https://hikeeducation.com/wp-content/plugins/ht-mega-for-elementor/assets/css/htbbootstrap.css?ver=2.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='htmega-animation-css' href='https://hikeeducation.com/wp-content/plugins/ht-mega-for-elementor/assets/css/animation.css?ver=2.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='htmega-keyframes-css' href='https://hikeeducation.com/wp-content/plugins/ht-mega-for-elementor/assets/css/htmega-keyframes.css?ver=2.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.30.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://hikeeducation.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.23.4' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-2795-css' href='https://hikeeducation.com/wp-content/uploads/elementor/css/post-2795.css?ver=1723637713' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=4.10.39' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.23.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://hikeeducation.com/wp-content/uploads/elementor/css/global.css?ver=1723637721' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css' href='https://hikeeducation.com/wp-content/themes/lt-university/genericons/genericons.css?ver=3.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='ltheme-style-css' href='https://hikeeducation.com/wp-content/themes/lt-university/style.css?ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='ltheme-block-style-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/blocks.css?ver=20181230' type='text/css' media='all' />
<!--[if lt IE 10]>
<link rel='stylesheet' id='ltheme-ie-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/ie.css?ver=20160816' type='text/css' media='all' />
<![endif]-->
<!--[if lt IE 9]>
<link rel='stylesheet' id='ltheme-ie8-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/ie8.css?ver=20160816' type='text/css' media='all' />
<![endif]-->
<!--[if lt IE 8]>
<link rel='stylesheet' id='ltheme-ie7-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/ie7.css?ver=20160816' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='ltheme-woocommerce-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/woocommerce.css?ver=20160816' type='text/css' media='all' />
<link rel='stylesheet' id='ltheme-fontawesome-css' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css?ver=20160816' type='text/css' media='all' />
<link rel='stylesheet' id='ltheme-custom-layout-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/custom-layout.css?ver=20160816' type='text/css' media='all' />
<link rel='stylesheet' id='ltheme-custom-css' href='https://hikeeducation.com/wp-content/themes/lt-university/css/custom.css?ver=20160816' type='text/css' media='all' />
<link rel='stylesheet' id='tablepress-default-css' href='https://hikeeducation.com/wp-content/tablepress-combined.min.css?ver=15' type='text/css' media='all' />
<link rel='stylesheet' id='popup-maker-site-css' href='//hikeeducation.com/wp-content/uploads/pum/pum-site-styles.css?generated=1721028609&#038;ver=1.19.0' type='text/css' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://hikeeducation.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=6.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-add-custom-css-css' href='https://hikeeducation.com?display_custom_css=css&#038;ver=6.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Lato%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.5.5' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><!--n2css--><script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.23.4" id="font-awesome-4-shim-js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/themes/lt-university/js/html5.js?ver=3.7.3" id="ltheme-html5-js"></script>
<![endif]-->
<link rel="https://api.w.org/" href="https://hikeeducation.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://hikeeducation.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.5" />
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href='https://fonts.googleapis.com/css2?display=swap&family=Poppins:wght@300;500;600;700' rel='stylesheet'>
	<style type="text/css">
		
		body {
			background-color: ;
		}

		.top-head {
			background-color: #ffffff;
		}
		.top-head,
		.top-head ul li,
		.top-head ul li i,
		.top-head p,
		.top-head .textwidget {
			color: #0fa89d;
		}
		.top-head a {
			color: #848484;
		}

		.top-head a:hover {
			color: ;
		}


		header.site-header {
			background-color: #071e33;
		}

		header.site-header.is-sticky {
			background-color: #ffffff;
		}

		.main-navigation .primary-menu {
			color: #000000;
		}

		.main-navigation .primary-menu > li > a {
			color: #ffffff;
		}
		
		.main-navigation .primary-menu li li a {
			color: #333333;
		}

		.main-navigation ul ul.sub-menu {
			background-color: #ffffff;
		}

		#site-header-menu.toggled-on {
			background-color: #071e33;
		}


		body .main-navigation li:hover > a, 
		body .main-navigation li.focus > a, 
		body .main-navigation li.current-menu-item > a, 
		body .main-navigation li.current-menu-parent > a {
			color: #0fa89d;
		}

		.main-footer,
		.main-footer h2,
		.main-footer p,
		.main-footer .textwidget,
		.main-footer ul li {
			color: #ffffff;
		}
		.main-footer a {
			color: #0fa89d;
		}

		.main-footer a:hover {
			color: #ffffff;
		}

		.main-footer {
			background-color: #171717;
		}


		.site-footer,
		.site-footer p {
			color: #66c7c0;
		}
		.site-footer a {
			color: #ffffff;
		}

		.site-footer a:hover {
			color: #66c7c0;
		}

		.site-footer {
			background-color: #171717;
		}

	</style>

<meta name="generator" content="Elementor 3.23.4; features: additional_custom_breakpoints, e_lazyload; settings: css_print_method-external, google_font-enabled, font_display-auto">
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://hikeeducation.com/wp-content/uploads/2023/01/cropped-ezgif.com-gif-maker-46-7-32x32.webp" sizes="32x32" />
<link rel="icon" href="https://hikeeducation.com/wp-content/uploads/2023/01/cropped-ezgif.com-gif-maker-46-7-192x192.webp" sizes="192x192" />
<link rel="apple-touch-icon" href="https://hikeeducation.com/wp-content/uploads/2023/01/cropped-ezgif.com-gif-maker-46-7-180x180.webp" />
<meta name="msapplication-TileImage" content="https://hikeeducation.com/wp-content/uploads/2023/01/cropped-ezgif.com-gif-maker-46-7-270x270.webp" />
		<style type="text/css" id="wp-custom-css">
			.wpcf7 select{
	width:100%;
	height:35px;
}
.prev.page-numbers, .next.page-numbers {
    display: none;
}
		</style>
			<style id="egf-frontend-styles" type="text/css">
		p {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 300;} h1 {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 700;} h2 {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 700;} h3 {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 600;} h4 {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 600;} h5 {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 500;} h6 {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 500;} a, link, li, main-navigation, label, button, select, comment-reply-title, input, dt, th, td, span, form, div {font-family: 'Poppins', sans-serif;font-style: normal;font-weight: 500;} 	</style>
		<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H3JJF79LJX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H3JJF79LJX');
</script>
<!-- Global site tag (gtag.js) - Google Ads: 10884911885 -->
<!--<script async src="https://www.googletagmanager.com/gtag/js?id=AW-10884911885"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-10884911885');
</script>-->
	<!--Add By MWITS-->
<!-- Google tag (gtag.js) -->

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11121534560"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11121534560');
</script>



<!-- Event snippet for Submit Lead Form conversion page -->
<!-- Event snippet for Lead Form Submission conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-11121534560/OZCYCI7LzZMYEODMlLcp'});
</script>



<!--End Add By MWITS-->
<!--<script>
  window.addEventListener('load', function(){
    if(window.location.pathname == "/thanks/"){
  gtag('event', 'conversion', {'send_to': 'AW-10884911885/uaFICMmkurcDEI2mqsYo'});*/
   
    }
  });
</script>-->
<!-- linkedin-->
	<script type="text/javascript">
_linkedin_partner_id = "5002545";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(l) {
if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
window.lintrk.q=[]}
var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
s.parentNode.insertBefore(b, s);})(window.lintrk);
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=5002545&fmt=gif" />
</noscript>

<!-- lined in ends 	 -->
<!--LeadSquared Tracking Code Start-->
<script type="text/javascript" src="https://web-in21.mxradon.com/t/Tracker.js"></script>
<script type="text/javascript">
      pidTracker('55601');
</script>
<!--LeadSquared Tracking Code End-->
<!-- Google Analytics  -->
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-X9D3285H75"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-X9D3285H75');
</script>
<!-- Google Analytics ends -->

	<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '5556654331052421');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=5556654331052421&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<style>
@media screen and (max-width: 768px) {
    body {
        overflow-x: hidden!important;
    }
}
</style>
<!-- Chatbot Code 26-02-2024 -->
<style>
      #lsq-chatbot {
        position: fixed;
        z-index: 99999;
        border: none;
		float: left!important;
      }
      .chatbot-opened {
        height: min(85vh, 586px) !important;
      }
/*       @media only screen and (max-width: 768px) {
        .chatbot-opened {
            width: 100%;
			height: 100%;
			bottom: 0px;
			background: rgb(255, 255, 255);
			display: flex;
			flex-direction: column;
			border-radius: 0px;
			right: 0px;
			left: auto;
			max-height: none;
        } */
		 @media only screen and (max-width: 768px) {
        .chatbot-opened {
/*           position: fixed;
          height: 100% !important;
          width: 100% !important;
          max-width: 100% !important;
			
			
          bottom: 0 !important;
          right: 0 !important;
          left: 0 !important;
          top: 0 !important;
		  float: left!important; */
			position: fixed;
        height: 52% !important;
        width: 81% !important;
        max-width: 100% !important;
        bottom: 0 !important;
        right: 0px !important;
        left: 53px !important;
        top: 343px !important;
        }  
      }
	
    </style>
    <script
      type="text/javascript"
      src="https://lsqbot.converse.leadsquared.com/bot-script.js"
    ></script>
	
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MSG8G2Z');</script>
<!-- End Google Tag Manager -->
	
</head>

<body class="error404 wp-custom-logo wp-embed-responsive jkit-color-scheme hfeed elementor-default elementor-kit-2795">
	
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MSG8G2Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<div id="page" class="site">
	<!-- Top menu -->
	
		 <div id="header-widget-area" class="top-head chw-widget-area widget-area" role="complementary">

			 <div class="container">

			 	<div class="widget_text top-head-widget"><div class="textwidget custom-html-widget"><div class="top-header-right">
	<!--<a class="lt-btn" href="https://hike.hforhealthcare.com/contact-us/">Get a Quote</a>-->
</div></div></div>
			 </div>

		 </div>

		<!-- End Top menu -->
	<header id="masthead" class="site-header" role="banner">



			<div class="site-header-main">
				<div class="site-branding">
					<a href="https://hikeeducation.com/" class="custom-logo-link" rel="home"><img width="200" height="50" src="https://hikeeducation.com/wp-content/uploads/2021/12/hike-edu-logo.jpg" class="custom-logo" alt="" decoding="async" /></a>
											<p class="site-title"><a href="https://hikeeducation.com/" rel="home"></a></p>
										
				</div><!-- .site-branding -->

									<button  id="menu-toggle" class="menu-toggle">Menu</button>

					<div id="site-header-menu" class="site-header-menu">
													<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="Primary Menu">
								<div class="menu-main-menu-container"><ul id="menu-main-menu" class="primary-menu"><li id="menu-item-1502" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1502"><a href="http://hikeeducation.com">Home</a></li>
<li id="menu-item-16472" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16472"><a href="https://hikeeducation.com/our-program/">Our Programs</a></li>
<li id="menu-item-1998" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1998"><a href="https://hikeeducation.com/career/">Career</a></li>
<li id="menu-item-2047" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2047"><a href="https://hikeeducation.com/life-at-hike/">Life at Hike</a></li>
<li id="menu-item-5540" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5540"><a href="https://hikeeducation.com/blog/">Blog</a></li>
<li id="menu-item-521" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-521"><a href="https://hikeeducation.com/contact-us/">Contact Us</a></li>
</ul></div>							</nav><!-- .main-navigation -->
						
											</div><!-- .site-header-menu -->
							</div><!-- .site-header-main -->
		</header><!-- .site-header -->
	<div class="site-inner">
		
		<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
					
		<div id="content" class="site-content">
			

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try a search?</p>

					
<form role="search" method="get" class="search-form" action="https://hikeeducation.com/">
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
	</label>
	<button type="submit" class="search-submit"><span class="screen-reader-text">Search</span></button>
</form>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- .site-main -->

		
	</div><!-- .content-area -->





	<aside id="sidebar-right-blog" class="sidebar widget-area sidebar-right-blog sidebar-right" role="complementary">
		<section id="calendar-2" class="widget widget_calendar"><div id="calendar_wrap" class="calendar_wrap"><table id="wp-calendar" class="wp-calendar-table">
	<caption>September 2024</caption>
	<thead>
	<tr>
		<th scope="col" title="Monday">M</th>
		<th scope="col" title="Tuesday">T</th>
		<th scope="col" title="Wednesday">W</th>
		<th scope="col" title="Thursday">T</th>
		<th scope="col" title="Friday">F</th>
		<th scope="col" title="Saturday">S</th>
		<th scope="col" title="Sunday">S</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td colspan="6" class="pad">&nbsp;</td><td>1</td>
	</tr>
	<tr>
		<td id="today"><a href="https://hikeeducation.com/2024/09/02/" aria-label="Posts published on September 2, 2024">2</a></td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td>
	</tr>
	<tr>
		<td>9</td><td>10</td><td>11</td><td>12</td><td>13</td><td>14</td><td>15</td>
	</tr>
	<tr>
		<td>16</td><td>17</td><td>18</td><td>19</td><td>20</td><td>21</td><td>22</td>
	</tr>
	<tr>
		<td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td><td>29</td>
	</tr>
	<tr>
		<td>30</td>
		<td class="pad" colspan="6">&nbsp;</td>
	</tr>
	</tbody>
	</table><nav aria-label="Previous and next months" class="wp-calendar-nav">
		<span class="wp-calendar-nav-prev"><a href="https://hikeeducation.com/2024/08/">&laquo; Aug</a></span>
		<span class="pad">&nbsp;</span>
		<span class="wp-calendar-nav-next">&nbsp;</span>
	</nav></div></section><section id="categories-3" class="widget widget_categories"><h2 class="widget-title">Categories</h2>
			<ul>
					<li class="cat-item cat-item-1"><a href="https://hikeeducation.com/category/blog/">Blog</a>
</li>
			</ul>

			</section>
		<section id="recent-posts-2" class="widget widget_recent_entries">
		<h2 class="widget-title">Recent Posts</h2>
		<ul>
											<li>
					<a href="https://hikeeducation.com/blog/mba-admission-2024/">MBA Admission 2024: Everything You Need to Know</a>
									</li>
											<li>
					<a href="https://hikeeducation.com/blog/online-mba-from-lpu/">Online MBA From LPU: Understanding Eligibility Criteria, Fee Structure, Specialisation and More</a>
									</li>
											<li>
					<a href="https://hikeeducation.com/blog/top-10-mba-colleges-in-india-with-fee-structure/">Top 10 MBA Colleges in India with Fee Structure: Complete Guide</a>
									</li>
											<li>
					<a href="https://hikeeducation.com/blog/mba-equivalent-courses/">MBA Equivalent Courses: Exploring Alternatives to Traditional MBA Programmes</a>
									</li>
											<li>
					<a href="https://hikeeducation.com/blog/scope-of-hrm-in-mba/">Scope of HRM in MBA: Understanding its Key Functions and Career Opportunities</a>
									</li>
					</ul>

		</section><section id="recent-comments-3" class="widget widget_recent_comments"><h2 class="widget-title">Recent Comments</h2><ul id="recentcomments"></ul></section>	</aside><!-- .sidebar .widget-area -->










<!-- LSQ Chatbot -->
<iframe style="bottom: 15px; right: 10px;" id="lsq-chatbot" src="https://botweb.converse.leadsquared.com/?botId=787&tenantId=67907&type=WEB&channelId=564e1551-5b2b-4a35-865e-619f2f2e897a"></iframe>

<style>
.main-footer {
background: rgb(8,35,69);
background: linear-gradient(180deg, rgba(8,35,69,1) 100%, rgba(8,35,69,1) 100%);!important;

	color:#fff !important;
	
}
.main-footer, .main-footer h2, .main-footer p, .main-footer .textwidget, .main-footer ul li {
  color: #212529 !important; 
		color:#fff !important;
	text-align:left !important;
}
.main-footer a {
  color: #212529 !important;
		color:#fff !important;
}
.site-footer {
/*   background-color: #00A8F1 !important; */
	background: rgb(0,168,241);
background: linear-gradient(90deg, rgba(0,168,241,0.3561799719887955) 35%, rgba(0,212,255,1) 100%);
		color:#fff !important;
}
.site-footer, .site-footer p {
  color: #212529 !important;
		color:#fff !important;
}
	@media only screen and (max-width: 600px) {
		.pp{
			display:flex;
		}
		
		.center{
		 	display: flex;
  justify-content: center;
  align-items: center;
			
			text-align:center;
			color:red;
			
		}
		
		.bb{
			margin-top:15px!important;
		}
		}
	}

	
	.row {
  display: flex;
}

/* Create two equal columns that sits next to each other */
.column {
  flex: 50%;
}
	.ll{
		float:left;
	}
</style>

<style>
 .mainn-footer {
            background-image: url(https://hikeeducation.com/wp-content/uploads/2023/10/Maskgroup40.png);
            /* Add your background image path */
            background-size: cover;
          color:#fff;
            padding: 100px 0;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            align-items: flex-start;
            flex-wrap: wrap;
        }

        .logo-section img {
            width: 100%;
            height: auto;
            /* Adjust the max-width as needed */
        }

        .logo-section .logoos {
            width: 100%;
            height: auto;
            padding-left: 10px;
        }

        .social-media-section {
            display: flex;
			margin-top:30px;
        }

        .social-icon {
            margin: 0 10px;
        }

        .site-maps-section ul {
            list-style: none;
            padding: 0;
           
        }

        .site-maps-section li {
            margin-bottom: 10px;
			margin-top:15px;
          
        }

        .site-maps-section a{
            color: #fff;
            text-decoration: none;
        }

        .timing-section p {
            margin: 0;
        }

        @media screen and (max-width: 768px) {
            .footer-container {
/*                 flex-direction: column;
                text-align: center;
                align-items: center; */
				        flex-direction: column;
        text-align: left;
        align-items: left;
        padding-left: 17px;
            }

            .social-media-section {
                margin-top: 30px;
            }
			.site-maps-section{
				margin-top:10px;
			}
        }

</style>

<div id="mainn-footer" class="mainn-footer">

        <div class="footer-container">
            <div class="logo-section">
                <img src="http://hikeeducation.com/wp-content/themes/lt-university/page_template/images/Group (11).png"
                    alt="Your Logo">
                <div class="social-media-section">
					<h3>Follow Us</h3>
                    <!-- Add your social media icons here -->
                    <a href="https://www.instagram.com/hike_education?igsh=dTB2MHFxMnlpYmx4&utm_source=qr" class="social-icon"><img class="logoos" src="https://hikeeducation.com/wp-content/uploads/2022/04/Group (11).png" alt="Facebook"></a>
                    <a href="https://www.linkedin.com/company/hikeeducation/" class="social-icon"><img class="logoos" src="https://hikeeducation.com/wp-content/uploads/2022/04/Group 959.png" alt="Twitter"></a>
                    <a href="https://api.whatsapp.com/send?phone=919205692942" class="social-icon"><img class="logoos" src="https://hikeeducation.com/wp-content/uploads/2022/04/Group 960 (1).png" alt="Instagram"></a>
					<a href="https://www.facebook.com/HikeEducation?mibextid=LQQJ4d" class="social-icon"><img class="logoos" src="https://hikeeducation.com/wp-content/uploads/2022/04/fbbbb.png" style="width:30px;" alt="Instagram"></a>
                    <a href="https://youtube.com/@hikeeducation?si=IVYkFK7rv55CFHBp" class="social-icon"><img class="logoos" src="https://hikeeducation.com/wp-content/uploads/2022/04/Group 961.png" alt="Instagram"></a>
                </div>
            </div>
            
            <div class="site-maps-section">
            </div>
            <div class="site-maps-section">
            </div>

            <div class="site-maps-section">
                <!-- Add your site maps and quick links here -->
               
                <ul>
                    <h3>Site Map</h3>
					
                    <li ><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            
            <div class="site-maps-section ">
                <ul>
                    <h3>Opening Hours</h3>
					
                    <li><a href="#">10:00 AM - 7:00 PM</a></li>
                    <li><a href="#">Monday - Saturday</a></li>
                    <li><a href="#">info@hikeedu.in</a></li>
                   
                </ul>
               
            </div>
            <div class="site-maps-section">
                <!-- Add your site maps and quick links here -->
                <ul>
                    <h3>Quick Links</h3>
					
                    <li><a href="/blog/">Blog</a></li>
                    <li><a href="/privacy-policy/">Privacy Policy</a></li>
                </ul>
            </div>
			<div class="site-maps-section">
            </div>
			<div class="site-maps-section">
            </div>
        </div>

</div>


</div><!-- .site-content -->

</div><!-- .site-inner -->
	    <!-- footer -->
		
		
<div id="main-footer" class="main-footer" style="display:none;">
	

    	<div class="container">

	        <!-- 1/4 -->
	        <div class="four columns footer1">
				<div>
					<img class="ll" loading="lazy" src="http://hikeeducation.com/wp-content/themes/lt-university/page_template/images/hike-edu-						logo.png" alt="" class="wp-image-1352" >

				<section class="p-10 text-center w-100" style="padding-top:100px;">
				<!-- Facebook -->
				<a href="https://www.facebook.com/HikeEducation/">
				<img src="https://hikeeducation.com/wp-content/uploads/2022/04/fb-icon.png" style="width:35px;">
				<!--<i class="fab fa-facebook-f fa-2x me-3" style="margin-left:10p"></i> -->
				</a> &nbsp;&nbsp;&nbsp;

				<!-- Youtube -->
				<a href="https://www.youtube.com/channel/UCgAYM89Fmm-eyp_cOttHt6w">
				<!--<i class="fab fa-youtube fa-2x me-3" style="color: #e11e1e;  margin:10p"></i>-->
				<img src="https://hikeeducation.com/wp-content/uploads/2022/04/youtube-icon.png" style="width:35px;">
				</a>&nbsp;&nbsp;&nbsp;
                  <!-- Instagram -->
				<a href="https://www.instagram.com/hike_education/">
				<!--<i class="fab fa-instagram fa-2x me-3" style="color: #ac2bac;  margin:10p"></i>-->
				<img src="https://hikeeducation.com/wp-content/uploads/2022/04/insta-icon.png" style="width:35px;">
				</a>&nbsp;&nbsp;&nbsp;

				<!-- Linkedin -->
				<a href="https://in.linkedin.com/company/hikeeducation">
					<!--<i class="fab fa-linkedin-in fa-2x me-3" style="color: #0082ca; margin:10p"></i>-->
					<img src="https://hikeeducation.com/wp-content/uploads/2022/04/linkedin-icon.png" style="width:35px;">
				</a>&nbsp;&nbsp;&nbsp;
				</section>
				</div>
	       
						
	        </div>
	        <!-- /End 1/4 -->
	        <!-- 2/4 -->
	        <div class="four columns footer3">
	            
								<h2 class="center bb">Quick Links</h2>
				<ul>
					 <li class="center"><a href="/blog/">Blog</a></li>
					<!--<li class="center"><a href="/FAQ/">FAQ</a></li> -->
				 	<li class="center"><a href="/privacy-policy/">Privacy Policy</a></li>
				</ul>

			</div>
	        <!-- /End 2/4 -->
				
	        <!-- 3/4 -->
	        <div class="four columns footer4">
				
	            				<h2 class="center bb">Opening Hours</h2>
				<ul>
					<li class="center">
				 	<a href="#">10:00 Am - 07:00 Pm,<br> Monday-Saturday</a></li>
					<li class="center">Contact Us</li>
				
					<li class="center">info@hikeedu.in</li>
				</ul>
	
	        </div>
	        <!-- /End 3/4 -->
				
	        <!-- 4/4 -->
	        <div class="four columns footer">
				
				
				<h2 class="center">Site Map</h2>
				<ul>
				 <li ><a class="center" href="/">Home</a></li>
				 <!--<li ><a class="center" href="/programs-details/">Programs Details</a></li> -->
				 <li ><a class="center" href="/career/">Career</a></li>
				 <li ><a class="center" href="/life-at-hike/">Life at Hike</a></li>
				 <li ><a class="center" href="/contact-us/">Contact Us</a></li>
	        
				
				
	        </div>
	        <!-- /End 4/4 -->
	    </div> <!-- /End container -->

    </div>
    <!-- /End Footer -->


<!-- 		<footer id="colophon" class="site-footer" role="contentinfo">


			
							<div class="footer-custom-code">
						
							
				</div>
			
							
			<div class="site-info container">
							
				<div class="row">
                  <div class="column ">
    <img class="ll" loading="lazy" src="http://hikeeducation.com/wp-content/themes/lt-university/page_template/images/hike-edu-logo.png" alt="" class="wp-image-1352">
  </div>
           <div class="column" >
    <div class="widget_text top-head-widget"><div class="textwidget custom-html-widget"><p>Copyright ©2022 All Rights Reserved
</p></div></div>  </div>
</div>
				
			

			</div>
		</footer> -->

<div id="pum-29530" class="pum pum-overlay pum-theme-6161 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:29530,&quot;slug&quot;:&quot;blogform&quot;,&quot;theme_id&quot;:6161,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;tiny&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-modal="false"
								   >

	<div id="popmake-29530" class="pum-container popmake theme-6161 pum-responsive pum-responsive-tiny responsive size-tiny">

				

				

		

				<div class="pum-content popmake-content" tabindex="0">
			
<div class="wpcf7 no-js" id="wpcf7-f22174-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f22174-o1" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="22174" />
<input type="hidden" name="_wpcf7_version" value="5.9.8" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f22174-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<style>

.wpcf7 input[type="text"],
.wpcf7 input[type="email"],
.wpcf7 input[type="tel"] {
 font-weight: 600 !important;
}
.wpcf7 select {
 font-weight: 900 !important;
}

.consent-text {
 text-align: center;
 margin-bottom: 10px;
 font-size: 1px;
 color: #555;
}
.consent-text p{
font-weight: 500;
}
</style>
<div>
	<h4>Get Free Counselling
	</h4>
	<p><span class="wpcf7-form-control-wrap" data-name="full-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name*" value="" type="text" name="full-name" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email*" value="" type="email" name="your-email" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="PhoneNumber"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Phone Number*" value="" type="tel" name="PhoneNumber" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="education"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="education"><option value="Qualification">Qualification</option><option value="High School">High School</option><option value="Bachelor&#039;s Degree">Bachelor&#039;s Degree</option><option value="Master&#039;s Degree">Master&#039;s Degree</option><option value="PhD">PhD</option><option value="Other">Other</option></select></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="experience"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="experience"><option value="Experience">Experience</option><option value="0-1 years">0-1 years</option><option value="1-3 years">1-3 years</option><option value="3-5 years">3-5 years</option><option value="5+ years">5+ years</option></select></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="City"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="City*" value="" type="text" name="City" /></span>
	</p>
	<div class="consent-text">
		<p>I agree to Hike Education's Terms and Conditions and provide consent to be<br />
contacted via WhatsApp, SMS, Mail, etc.
		</p>
	</div>
<input class="wpcf7-form-control wpcf7-hidden" value="blog" type="hidden" name="source" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_campaign" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_source" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_medium" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_term" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_content" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="gclid" />
	<p><input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Submit" />
	</p>
</div><p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_1" name="_wpcf7_ak_js" value="157"/><script>document.getElementById( "ak_js_1" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

		</div>


				

							<button type="button" class="pum-close popmake-close" aria-label="Close">
			×			</button>
		
	</div>

</div>
<div id="pum-25830" class="pum pum-overlay pum-theme-6161 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:25830,&quot;slug&quot;:&quot;university-popup&quot;,&quot;theme_id&quot;:6161,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;tiny&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;80%&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;85%&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-modal="false"
								   >

	<div id="popmake-25830" class="pum-container popmake theme-6161 pum-responsive pum-responsive-tiny responsive size-tiny">

				

				

		

				<div class="pum-content popmake-content" tabindex="0">
			
<div class="wpcf7 no-js" id="wpcf7-f25626-o2" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f25626-o2" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="25626" />
<input type="hidden" name="_wpcf7_version" value="5.9.8" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f25626-o2" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<style>
.wpcf7 input[type="text"],
.wpcf7 input[type="email"],
.wpcf7 input[type="tel"],
.wpcf7 select {
 font-weight: 600 !important;
 height: 40px;
 background-color: white;
 color: black;
 border: 1px solid #ccc;
 padding: 5px;
 box-sizing: border-box;
 margin-bottom: 10px;
 width: 100%; /* Default width for all fields */
}

.wpcf7 select {
 font-weight: 500 !important;
}

.wpcf7 input[type="submit"] {
 width: auto;
 background-color: red !important; /* Ensuring background color is red */
 color: white !important; /* Ensuring text color is white */
 font-weight: 700 !important; /* Ensuring font-weight is applied */
 text-align: center !important; /* Ensuring text is centered */
 border: none !important; /* Ensuring no border */
 cursor: pointer !important; /* Ensuring pointer cursor */
 padding: 10px 20px !important; /* Ensuring padding */
 display: block !important; /* Ensuring block display */
 margin: 0 auto !important; /* Ensuring margin auto */
 border-radius: 15px !important; /* Ensuring border-radius */
}

.wpcf7 input[type="submit"]:hover {
 background-color: red;
}

.flex-container {
 display: flex;
 gap: 10px;
}

.flex-container .wpcf7-select {
 flex: 1;
 margin-bottom: 10px; /* Maintain space below the row */
}

.consent-text {
 text-align: center;
 margin-bottom: 10px;
 font-size: 14px;
 color: #555;
}
.consent-text p{
font-weight: 500;
}
div h4{
margin-top: -7px;
 font-size: 18px;
 margin-bottom: 19px;
text-align: center;
}
</style>
<div>
	<h4>Please Enter Your Details
	</h4>
	<p><span class="wpcf7-form-control-wrap" data-name="full-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name*" value="" type="text" name="full-name" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email*" value="" type="email" name="your-email" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="PhoneNumber"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Phone Number*" value="" type="tel" name="PhoneNumber" /></span>
	</p>
	<div class="flex-container">
		<div class="wpcf7-select">
			<p><span class="wpcf7-form-control-wrap" data-name="education"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="education"><option value="Qualification">Qualification</option><option value="Bachelor&#039;s Degree">Bachelor&#039;s Degree</option><option value="Master&#039;s Degree">Master&#039;s Degree</option><option value="PhD">PhD</option><option value="Other">Other</option></select></span>
			</p>
		</div>
		<div class="wpcf7-select">
			<p><span class="wpcf7-form-control-wrap" data-name="experience"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="experience"><option value="Experience">Experience</option><option value="0-1 years">0-1 years</option><option value="1-3 years">1-3 years</option><option value="3-5 years">3-5 years</option><option value="5+ years">5+ years</option></select></span>
			</p>
		</div>
	</div>
	<p><span class="wpcf7-form-control-wrap" data-name="City"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="City*" value="" type="text" name="City" /></span>
	</p>
	<div class="consent-text">
		<p>I agree to Hike Education's Terms and Conditions and provide consent to be contacted via WhatsApp, SMS, Mail, etc.
		</p>
	</div>
<input class="wpcf7-form-control wpcf7-hidden" value="BrandCourse" type="hidden" name="source" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_campaign" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_source" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_medium" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_term" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_content" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="gclid" />
	<p><input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Download Brochure" />
	</p>
</div><p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_2" name="_wpcf7_ak_js" value="4"/><script>document.getElementById( "ak_js_2" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

		</div>


				

							<button type="button" class="pum-close popmake-close" aria-label="Close">
			×			</button>
		
	</div>

</div>
<div id="pum-23407" class="pum pum-overlay pum-theme-6161 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:23407,&quot;slug&quot;:&quot;lp-popups-form&quot;,&quot;theme_id&quot;:6161,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;tiny&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-modal="false"
								   >

	<div id="popmake-23407" class="pum-container popmake theme-6161 pum-responsive pum-responsive-tiny responsive size-tiny">

				

				

		

				<div class="pum-content popmake-content" tabindex="0">
			
<div class="wpcf7 no-js" id="wpcf7-f23406-o3" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f23406-o3" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="23406" />
<input type="hidden" name="_wpcf7_version" value="5.9.8" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f23406-o3" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<style>
.wpcf7 input[type="text"],
.wpcf7 input[type="email"],
.wpcf7 input[type="tel"],
.wpcf7 select {
 font-weight: 600 !important;
 height: 40px;
 background-color: white;
 color: black;
 border: 1px solid #ccc;
 padding: 5px;
 box-sizing: border-box;
 margin-bottom: 10px;
 width: 100%; /* Default width for all fields */
}

.wpcf7 select {
 font-weight: 300 !important;
}

.wpcf7 input[type="submit"] {
 width: auto;
 background: red !important; /* Ensuring background color is red */
 color: white !important; /* Ensuring text color is white */
 font-weight: 700 !important; /* Ensuring font-weight is applied */
 text-align: center !important; /* Ensuring text is centered */
 border: none !important; /* Ensuring no border */
 cursor: pointer !important; /* Ensuring pointer cursor */
 padding: 10px 20px !important; /* Ensuring padding */
 display: block !important; /* Ensuring block display */
 margin: 0 auto !important; /* Ensuring margin auto */
 border-radius: 15px !important; /* Ensuring border-radius */

}

.wpcf7 input[type="submit"]:hover {
 background-color: red;
}

.flex-container {
 display: flex;
 gap: 10px;
}

.flex-container .wpcf7-select {
 flex: 1;
 margin-bottom: 10px; /* Maintain space below the row */
}

.consent-text {
 text-align: center;
 margin-bottom: 10px;
 font-size: 14px;
 color: #555;
}
.consent-text p{
font-weight: 500;
}
div h4{
margin-top: -7px;
 font-size: 18px;
 margin-bottom: 19px;
}
</style>
<div>
	<h4>Please Enter Your Details
	</h4>
	<p><span class="wpcf7-form-control-wrap" data-name="full-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name*" value="" type="text" name="full-name" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email*" value="" type="email" name="your-email" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="PhoneNumber"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Phone Number*" value="" type="tel" name="PhoneNumber" /></span>
	</p>
	<div class="flex-container">
		<div class="wpcf7-select">
			<p><span class="wpcf7-form-control-wrap" data-name="education"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="education"><option value="Qualification*">Qualification*</option><option value="High School">High School</option><option value="Bachelor&#039;s Degree">Bachelor&#039;s Degree</option><option value="Master&#039;s Degree">Master&#039;s Degree</option><option value="PhD">PhD</option><option value="Other">Other</option></select></span>
			</p>
		</div>
		<div class="wpcf7-select">
			<p><span class="wpcf7-form-control-wrap" data-name="experience"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="experience"><option value="Experience*">Experience*</option><option value="0-1 years">0-1 years</option><option value="1-3 years">1-3 years</option><option value="3-5 years">3-5 years</option><option value="5+ years">5+ years</option></select></span>
			</p>
		</div>
	</div>
	<p><span class="wpcf7-form-control-wrap" data-name="City"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="City*" value="" type="text" name="City" /></span>
	</p>
	<p><span class="wpcf7-form-control-wrap" data-name="University"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="University"><option value="University/ Institute of Your Choice*">University/ Institute of Your Choice*</option><option value="Amity University Online">Amity University Online</option><option value="Dr. D.Y. Patil University Online">Dr. D.Y. Patil University Online</option><option value="Manipal Academy of Higher Education(MAHE)">Manipal Academy of Higher Education(MAHE)</option><option value="Manipal University Jaipur">Manipal University Jaipur</option><option value="⁠Jain University Online">⁠Jain University Online</option><option value="⁠Lovely Professional University Online">⁠Lovely Professional University Online</option><option value="⁠Symbiosis 
School For Online &amp; Digital Learning">⁠Symbiosis 
School For Online &amp; Digital Learning</option><option value="Symbiosis Centre for Distance Learning (SCDL)">Symbiosis Centre for Distance Learning (SCDL)</option><option value="O.P. Jindal Global University (OPJ)">O.P. Jindal Global University (OPJ)</option><option value="Birla Institute of Technology and Science (BITS, Pilani)">Birla Institute of Technology and Science (BITS, Pilani)</option><option value="Others">Others</option></select></span>
	</p>
	<div class="consent-text">
		<p>I agree to Hike Education's Terms and Conditions and provide consent to be<br />
contacted via WhatsApp, SMS, Mail, etc.
		</p>
	</div>
<input class="wpcf7-form-control wpcf7-hidden" value="Course" type="hidden" name="source" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_campaign" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_source" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_medium" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_term" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="utm_content" />
<input class="wpcf7-form-control wpcf7-hidden" value="" type="hidden" name="gclid" />
	<p><input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Download Brochure" />
	</p>
</div><p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_3" name="_wpcf7_ak_js" value="98"/><script>document.getElementById( "ak_js_3" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

		</div>


				

							<button type="button" class="pum-close popmake-close" aria-label="Close">
			×			</button>
		
	</div>

</div>
<div id="pum-16377" class="pum pum-overlay pum-theme-6161 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:16377,&quot;slug&quot;:&quot;our-program&quot;,&quot;theme_id&quot;:6161,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;small&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-modal="false"
								   	aria-labelledby="pum_popup_title_16377">

	<div id="popmake-16377" class="pum-container popmake theme-6161 pum-responsive pum-responsive-small responsive size-small">

				

							<div id="pum_popup_title_16377" class="pum-title popmake-title">
				Our Program			</div>
		

		

				<div class="pum-content popmake-content" tabindex="0">
			
<div class="wpcf7 no-js" id="wpcf7-f16331-o4" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f16331-o4" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="16331" />
<input type="hidden" name="_wpcf7_version" value="5.9.8" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f16331-o4" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<p><label><br />
<span class="wpcf7-form-control-wrap" data-name="your-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name" value="" type="text" name="your-name" /></span> </label>
</p>
<p><label><br />
<span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email" value="" type="email" name="your-email" /></span> </label>
</p>
<p><label><br />
<span class="wpcf7-form-control-wrap" data-name="tel-956"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Mobile No" value="" type="tel" name="tel-956" /></span></label>
</p>
<p><label><br />
<span class="wpcf7-form-control-wrap" data-name="text-848"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Location" value="" type="text" name="text-848" /></span></label>
</p>
<p><span class="wpcf7-form-control-wrap" data-name="Specialization"><select class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false" name="Specialization"><option value="MBA">MBA</option><option value="MCA">MCA</option></select></span>
</p>
<p><label><br />
</label>
</p>
<div style="font-size:10px;">
	<p><span class="wpcf7-form-control-wrap" data-name="checkbox-885"><span class="wpcf7-form-control wpcf7-checkbox wpcf7-validates-as-required"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-885[]" value="I agree to get updates from Hike Education" /><span class="wpcf7-list-item-label">I agree to get updates from Hike Education</span></span></span></span>
	</p>
</div>
<p><input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Send" />
</p><p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_4" name="_wpcf7_ak_js" value="37"/><script>document.getElementById( "ak_js_4" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

		</div>


				

							<button type="button" class="pum-close popmake-close" aria-label="Close">
			×			</button>
		
	</div>

</div>
<div id="pum-6270" class="pum pum-overlay pum-theme-6161 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:6270,&quot;slug&quot;:&quot;program-enquiry&quot;,&quot;theme_id&quot;:6161,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;small&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-modal="false"
								   	aria-labelledby="pum_popup_title_6270">

	<div id="popmake-6270" class="pum-container popmake theme-6161 pum-responsive pum-responsive-small responsive size-small">

				

							<div id="pum_popup_title_6270" class="pum-title popmake-title">
				Program Enquiry			</div>
		

		

				<div class="pum-content popmake-content" tabindex="0">
			
<div class="wpcf7 no-js" id="wpcf7-f6271-o5" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f6271-o5" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="6271" />
<input type="hidden" name="_wpcf7_version" value="5.9.8" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f6271-o5" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<p><span class="wpcf7-form-control-wrap" data-name="your-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name" value="" type="text" name="your-name" /></span>
</p>
<p><span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email" value="" type="email" name="your-email" /></span>
</p>
<p><span class="wpcf7-form-control-wrap" data-name="tel-443"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Phone Number" value="" type="tel" name="tel-443" /></span>
</p>
<p><span class="wpcf7-form-control-wrap" data-name="text-523"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Enter Your City" value="" type="text" name="text-523" /></span>
</p>
<center >
	<p><input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Submit" />
	</p>
</center><p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_5" name="_wpcf7_ak_js" value="246"/><script>document.getElementById( "ak_js_5" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

		</div>


				

							<button type="button" class="pum-close popmake-close" aria-label="Close">
			×			</button>
		
	</div>

</div>
<div id="pum-6208" class="pum pum-overlay pum-theme-6161 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:6208,&quot;slug&quot;:&quot;free-counselling&quot;,&quot;theme_id&quot;:6161,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;medium&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:&quot;1&quot;,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-modal="false"
								   	aria-labelledby="pum_popup_title_6208">

	<div id="popmake-6208" class="pum-container popmake theme-6161 pum-responsive pum-responsive-medium responsive size-medium">

				

							<div id="pum_popup_title_6208" class="pum-title popmake-title">
				Free Counselling			</div>
		

		

				<div class="pum-content popmake-content" tabindex="0">
			
<div class="wpcf7 no-js" id="wpcf7-f6172-o6" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f6172-o6" method="post" class="wpcf7-form init wpcf7-acceptance-as-validation" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="6172" />
<input type="hidden" name="_wpcf7_version" value="5.9.8" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f6172-o6" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<div>
	<p><span class="wpcf7-form-control-wrap" data-name="your-name"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name" value="" type="text" name="your-name" /></span>
	</p>
</div>
<div>
	<p><span class="wpcf7-form-control-wrap" data-name="your-email"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email" value="" type="email" name="your-email" /></span>
	</p>
</div>
<div>
	<p><span class="wpcf7-form-control-wrap" data-name="tel-443"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Phone Number" value="" type="tel" name="tel-443" /></span>
	</p>
</div>
<div>
	<p><span class="wpcf7-form-control-wrap" data-name="text-523"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Enter Your City" value="" type="text" name="text-523" /></span>
	</p>
</div>
<div>
	<p><span class="wpcf7-form-control-wrap" data-name="placeholder"><input size="40" maxlength="400" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" value="Higher Qualification" type="text" name="placeholder" /></span>
	</p>
</div>
<div>
	<p><span class="wpcf7-form-control-wrap" data-name="acceptance-135"><span class="wpcf7-form-control wpcf7-acceptance optional"><span class="wpcf7-list-item"><input type="checkbox" name="acceptance-135" value="1" aria-invalid="false" /></span></span></span><span style="font-size:12px">I agree to the <span style="color:#D51E22"> Terms </span> & <span style="color:#D51E22"> Privacy Policy</span></span>
	</p>
</div>
<p><input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Submit" />
</p><p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_6" name="_wpcf7_ak_js" value="173"/><script>document.getElementById( "ak_js_6" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>

		</div>


				

							<button type="button" class="pum-close popmake-close" aria-label="Close">
			×			</button>
		
	</div>

</div>
			<script type='text/javascript'>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='jeg-dynamic-style-css' href='https://hikeeducation.com/wp-content/plugins/jeg-elementor-kit/lib/jeg-framework/assets/css/jeg-dynamic-styles.css?ver=1.3.0' type='text/css' media='all' />
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.8" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
var wpcf7 = {"api":{"root":"https:\/\/hikeeducation.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.8" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/ht-mega-for-elementor/assets/js/popper.min.js?ver=2.6.0" id="htmega-popper-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/ht-mega-for-elementor/assets/js/htbbootstrap.js?ver=2.6.0" id="htbbootstrap-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/ht-mega-for-elementor/assets/js/waypoints.js?ver=2.6.0" id="waypoints-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/themes/lt-university/js/skip-link-focus-fix.js?ver=20160816" id="ltheme-skip-link-focus-fix-js"></script>
<script type="text/javascript" id="ltheme-script-js-extra">
/* <![CDATA[ */
var screenReaderText = {"expand":"expand child menu","collapse":"collapse child menu"};
/* ]]> */
</script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/themes/lt-university/js/functions.js?ver=20181230" id="ltheme-script-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/themes/lt-university/js/custom.js?ver=20181230" id="ltheme-custom-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="popup-maker-site-js-extra">
/* <![CDATA[ */
var pum_vars = {"version":"1.19.0","pm_dir_url":"https:\/\/hikeeducation.com\/wp-content\/plugins\/popup-maker\/","ajaxurl":"https:\/\/hikeeducation.com\/wp-admin\/admin-ajax.php","restapi":"https:\/\/hikeeducation.com\/wp-json\/pum\/v1","rest_nonce":null,"default_theme":"6160","debug_mode":"","disable_tracking":"","home_url":"\/","message_position":"top","core_sub_forms_enabled":"1","popups":[],"cookie_domain":"","analytics_route":"analytics","analytics_api":"https:\/\/hikeeducation.com\/wp-json\/pum\/v1"};
var pum_sub_vars = {"ajaxurl":"https:\/\/hikeeducation.com\/wp-admin\/admin-ajax.php","message_position":"top"};
var pum_popups = {"pum-29530":{"triggers":[],"cookies":[],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"6161","size":"tiny","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height_auto":false,"custom_height":"380px","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"0","fi_promotion":null,"close_on_form_submission":false,"close_on_form_submission_delay":"0","close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":29530,"slug":"blogform"},"pum-25830":{"triggers":[],"cookies":[],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"6161","size":"tiny","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"80%","custom_height_auto":false,"custom_height":"85%","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"0","fi_promotion":null,"close_on_form_submission":false,"close_on_form_submission_delay":"0","close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":25830,"slug":"university-popup"},"pum-23407":{"triggers":[],"cookies":[],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"6161","size":"tiny","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height_auto":false,"custom_height":"380px","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"0","fi_promotion":null,"close_on_form_submission":false,"close_on_form_submission_delay":"0","close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":23407,"slug":"lp-popups-form"},"pum-16377":{"triggers":[],"cookies":[],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"6161","size":"small","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height_auto":false,"custom_height":"380px","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"0","fi_promotion":null,"close_on_form_submission":true,"close_on_form_submission_delay":"0","close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":16377,"slug":"our-program"},"pum-6270":{"triggers":[],"cookies":[],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"6161","size":"small","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height_auto":false,"custom_height":"380px","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"0","fi_promotion":null,"close_on_form_submission":false,"close_on_form_submission_delay":"0","close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":6270,"slug":"program-enquiry"},"pum-6208":{"triggers":[],"cookies":[],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"6161","size":"medium","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height_auto":false,"custom_height":"380px","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"0","fi_promotion":null,"close_on_form_submission":false,"close_on_form_submission_delay":"0","close_on_overlay_click":false,"close_on_esc_press":true,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":6208,"slug":"free-counselling"}};
/* ]]> */
</script>
<script type="text/javascript" src="//hikeeducation.com/wp-content/uploads/pum/pum-site-scripts.js?defer&amp;generated=1721028609&amp;ver=1.19.0" id="popup-maker-site-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.23.4" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.23.4" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.23.4" id="elementor-frontend-js"></script>
<script type="text/javascript" id="elementor-frontend-js-after">
/* <![CDATA[ */
var jkit_ajax_url = "https://hikeeducation.com/?jkit-ajax-request=jkit_elements", jkit_nonce = "0204f0aa28";
/* ]]> */
</script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/jeg-elementor-kit/assets/js/elements/sticky-element.js?ver=2.6.7" id="jkit-sticky-element-js"></script>
<script type="text/javascript" id="eael-general-js-extra">
/* <![CDATA[ */
var localize = {"ajaxurl":"https:\/\/hikeeducation.com\/wp-admin\/admin-ajax.php","nonce":"96d19804de","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"eael_translate_text":{"required_text":"is a required field","invalid_text":"Invalid","billing_text":"Billing","shipping_text":"Shipping","fg_mfp_counter_text":"of"},"page_permalink":"","cart_redirectition":"no","cart_page_url":"","el_breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
/* ]]> */
</script>
<script type="text/javascript" src="https://hikeeducation.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=6.0.0" id="eael-general-js"></script>
<script type="text/javascript">
window.addEventListener("load", function(event) {
jQuery(".cfx_form_main,.wpcf7-form,.wpforms-form,.gform_wrapper form").each(function(){
var form=jQuery(this); 
var screen_width=""; var screen_height="";
 if(screen_width == ""){
 if(screen){
   screen_width=screen.width;  
 }else{
     screen_width=jQuery(window).width();
 }    }  
  if(screen_height == ""){
 if(screen){
   screen_height=screen.height;  
 }else{
     screen_height=jQuery(window).height();
 }    }
form.append('<input type="hidden" name="vx_width" value="'+screen_width+'">');
form.append('<input type="hidden" name="vx_height" value="'+screen_height+'">');
form.append('<input type="hidden" name="vx_url" value="'+window.location.href+'">');  
}); 

});
</script> 

</div><!-- .site -->
<!-- whatsapp widigit -->
<div id="whatsapp-widget-timelines" style="display:none;" class="ww-right ww-normal">  <a href="https://api.whatsapp.com/send?phone=919205692942" class="ww-text">Need help in choosing the right course?</a>  <div class="ww-icon">    <a href="https://api.whatsapp.com/send?phone=919205692942">      <svg xmlns="https://api.whatsapp.com/send?phone=919205692942" viewBox="0 0 32 32">        <path d=" M19.11 17.205c-.372 0-1.088 1.39-1.518 1.39a.63.63 0 0 1-.315-.1c-.802-.402-1.504-.817-2.163-1.447-.545-.516-1.146-1.29-1.46-1.963a.426.426 0 0 1-.073-.215c0-.33.99-.945.99-1.49 0-.143-.73-2.09-.832-2.335-.143-.372-.214-.487-.6-.487-.187 0-.36-.043-.53-.043-.302 0-.53.115-.746.315-.688.645-1.032 1.318-1.06 2.264v.114c-.015.99.472 1.977 1.017 2.78 1.23 1.82 2.506 3.41 4.554 4.34.616.287 2.035.888 2.722.888.817 0 2.15-.515 2.478-1.318.13-.33.244-.73.244-1.088 0-.058 0-.144-.03-.215-.1-.172-2.434-1.39-2.678-1.39zm-2.908 7.593c-1.747 0-3.48-.53-4.942-1.49L7.793 24.41l1.132-3.337a8.955 8.955 0 0 1-1.72-5.272c0-4.955 4.04-8.995 8.997-8.995S25.2 10.845 25.2 15.8c0 4.958-4.04 8.998-8.998 8.998zm0-19.798c-5.96 0-10.8 4.842-10.8 10.8 0 1.964.53 3.898 1.546 5.574L5 27.176l5.974-1.92a10.807 10.807 0 0 0 16.03-9.455c0-5.958-4.842-10.8-10.802-10.8z" fill-rule="evenodd"></path>      </svg>    </a>    <a class="ww-link" type="link" href="https://timelines.ai">Timelines.ai</a>  </div></div>
<!-- <style>  #whatsapp-widget-timelines {    position: fixed;    bottom: 20px;    height: max-content;    display: flex;    align-items: center;    gap: 2rem;    z-index: 99999999;  }  #whatsapp-widget-timelines .ww-icon {    display: flex;    flex-direction: column;    justify-content: center;    align-items: center;    gap: 5px;  width: 50px;}  #whatsapp-widget-timelines .ww-link {    opacity: 1;    display: block;    position:  absolute;    bottom: -15px;    text-align: center;    white-space: nowrap;    text-decoration: none;    width: 60px;    font-family: Roboto, "Helvetica Neue", sans-serif;    font-size: 11px;    line-height: 11px;    border: 0px;    max-width: inherit;    color: rgb(175, 175, 175) !important;  }  #whatsapp-widget-timelines .ww-link:hover {    border: 0px;    text-decoration: underline !important;    color: rgb(175, 175, 175) !important;  }  #whatsapp-widget-timelines .ww-text {    border-radius: 8px;    border: 1px solid #e2e2e2;    min-height: 56px;    width: 200px;    cursor: pointer;    word-break: break-word;    background: white;    padding: 1rem;    position: relative;    box-shadow: 2px 2px 15px 2px rgb(0 0 0 / 17%);  }  #whatsapp-widget-timelines .ww-text::after {    content: "";    position: absolute;    top: 50%;    width: 20px;    height: 20px;    border-right: 1px solid #e2e2e2;    border-bottom: 1px solid #e2e2e2;    background-color: white;  }  #whatsapp-widget-timelines svg {    fill: rgb(255, 255, 255);    z-index: 1;    border-radius: 50px;    background-color: rgb(77, 194, 71);    box-shadow: rgb(0 0 0 / 40%) 2px 2px 6px;    cursor: pointer;  }  #whatsapp-widget-timelines.ww-right .ww-text::after {    right: -10px;    transform: translateY(-50%) rotate(-45deg);  }  #whatsapp-widget-timelines.ww-left .ww-text::after {    left: -10px;    transform: translateY(-50%) rotate(135deg)  }  #whatsapp-widget-timelines.ww-left {    left: 20px;    flex-direction: row-reverse;  }  #whatsapp-widget-timelines.ww-right {    right: 20px;    flex-direction: row;  }  #whatsapp-widget-timelines.ww-big svg {    height: 75px;    width: 75px;  }  #whatsapp-widget-timelines.ww-medium svg {    height: 65px;    width: 65px;  }  @media(max-width: 768px){    #whatsapp-widget-timelines{      gap:1rem;    }    #whatsapp-widget-timelines svg{      width: 50px!important;      height: 50px!important;    }    #whatsapp-widget-timelines .ww-text{      padding: 0.5rem  1rem;      min-height: 35px;    }  }</style> -->
<style>  
#whatsapp-widget-timelines {    position: fixed;    bottom: 20px;    height: max-content;    display: flex;    align-items: center;    gap: 2rem;    z-index: 99999999;  }
#whatsapp-widget-timelines .ww-icon {    display: flex;    flex-direction: column;    justify-content: center;    align-items: center;    gap: 5px;  width: 50px;}  #whatsapp-widget-timelines .ww-link {    opacity: 1;    display: block;    position:  absolute;    bottom: -15px;    text-align: center;    white-space: nowrap;    text-decoration: none;    width: 60px;    font-family: Roboto, "Helvetica Neue", sans-serif;    font-size: 11px;    line-height: 11px;    border: 0px;    max-width: inherit;    color: rgb(175, 175, 175) !important;  }  #whatsapp-widget-timelines .ww-link:hover {    border: 0px;    text-decoration: underline !important;    color: rgb(175, 175, 175) !important;  }  #whatsapp-widget-timelines .ww-text {    border-radius: 8px;    border: 1px solid #e2e2e2;    min-height: 56px;    width: 200px;    cursor: pointer;    word-break: break-word;    background: white;    padding: 1rem;    position: relative;    box-shadow: 2px 2px 15px 2px rgb(0 0 0 / 17%);  }  #whatsapp-widget-timelines .ww-text::after {    content: "";    position: absolute;    top: 50%;    width: 20px;    height: 20px;    border-right: 1px solid #e2e2e2;    border-bottom: 1px solid #e2e2e2;    background-color: white;  }  #whatsapp-widget-timelines svg {    fill: rgb(255, 255, 255);    z-index: 1;    border-radius: 50px;    background-color: rgb(77, 194, 71);    box-shadow: rgb(0 0 0 / 40%) 2px 2px 6px;    cursor: pointer;  }  #whatsapp-widget-timelines.ww-right .ww-text::after {    right: -10px;    transform: translateY(-50%) rotate(-45deg);  }  #whatsapp-widget-timelines.ww-left .ww-text::after {    left: -10px;    transform: translateY(-50%) rotate(135deg)  }  #whatsapp-widget-timelines.ww-left {    left: 20px;    flex-direction: row-reverse;  }  #whatsapp-widget-timelines.ww-right {    right: 20px;    flex-direction: row;  }  #whatsapp-widget-timelines.ww-big svg {    height: 75px;    width: 75px;  }  #whatsapp-widget-timelines.ww-medium svg {    height: 65px;    width: 65px;  }  @media(max-width: 768px){    #whatsapp-widget-timelines{      gap:1rem;    }    #whatsapp-widget-timelines svg{      width: 50px!important;      height: 50px!important;    }    #whatsapp-widget-timelines .ww-text{      padding: 0.5rem  1rem;      min-height: 35px;    }  }

/* Extra small devices (phones, 600px and down) */
@media only screen and (max-width: 600px) {
    #whatsapp-widget-timelines svg {
    width: 50px!important;
    height: 50px!important;
}
}

/* Small devices (portrait tablets and large phones, 600px and up) */
@media only screen and (min-width: 600px) {
    #whatsapp-widget-timelines svg {
    width: 50px!important;
    height: 50px!important;
    z-index: 99999999;;
}
}

/* Medium devices (landscape tablets, 768px and up) */
@media only screen and (min-width: 768px) {
        #whatsapp-widget-timelines svg {
    width: 50px!important;
    height: 50px!important;
    z-index: 99999999;;
}
}

/* Large devices (laptops/desktops, 992px and up) */
@media only screen and (min-width: 992px) {
        #whatsapp-widget-timelines svg {
    width: 50px!important;
    height: 50px!important;
    z-index: 99999999;;
}
}

/* Extra large devices (large laptops and desktops, 1200px and up) */
@media only screen and (min-width: 1200px) {
    
        #whatsapp-widget-timelines svg {
    width: 50px!important;
    height: 50px!important;
    z-index: 99999999;;
}
}


</style>

<script>
  window.addEventListener('load', function(){
    if(window.location.pathname == "/thanks/"){
  gtag('event', 'conversion', {'send_to': 'AW-10884911885/uaFICMmkurcDEI2mqsYo'});

    }
  });
</script>
<!-- linkedin  -->
<script type="text/javascript">
_linkedin_partner_id = "5002545";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(l) {
if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
window.lintrk.q=[]}
var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
s.parentNode.insertBefore(b, s);})(window.lintrk);
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=5002545&fmt=gif" />
</noscript>

</body>
</html>
